# Source: https://python.langchain.com/docs/integrations/chat/deepseek/

* [Components](/docs/integrations/components/)
* [Chat models](/docs/integrations/chat/)
* DeepSeek

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/deepseek.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/deepseek.ipynb)

# ChatDeepSeek

This will help you getting started with DeepSeek's hosted [chat models](/docs/concepts/chat_models/). For detailed documentation of all ChatDeepSeek features and configurations head to the [API reference](https://python.langchain.com/api_reference/deepseek/chat_models/langchain_deepseek.chat_models.ChatDeepSeek.html).

tip

DeepSeek's models are open source and can be run locally (e.g. in [Ollama](/docs/integrations/chat/ollama/)) or on other inference providers (e.g. [Fireworks](/docs/integrations/chat/fireworks/), [Together](/docs/integrations/chat/together/)) as well.

## Overview[​](#overview "Direct link to Overview")

### Integration details[​](#integration-details "Direct link to Integration details")

| Class | Package | Local | Serializable | [JS support](https://js.langchain.com/docs/integrations/chat/deepseek) | Package downloads | Package latest |
| --- | --- | --- | --- | --- | --- | --- |
| [ChatDeepSeek](https://python.langchain.com/api_reference/deepseek/chat_models/langchain_deepseek.chat_models.ChatDeepSeek.html) | [langchain-deepseek](https://python.langchain.com/api_reference/deepseek/) | ❌ | beta | ✅ | PyPI - Downloads | PyPI - Version |

### Model features[​](#model-features "Direct link to Model features")

| [Tool calling](/docs/how_to/tool_calling/) | [Structured output](/docs/how_to/structured_output/) | JSON mode | [Image input](/docs/how_to/multimodal_inputs/) | Audio input | Video input | [Token-level streaming](/docs/how_to/chat_streaming/) | Native async | [Token usage](/docs/how_to/chat_token_usage_tracking/) | [Logprobs](/docs/how_to/logprobs/) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ✅ | ✅ | ✅ | ❌ |

note

DeepSeek-R1, specified via `model="deepseek-reasoner"`, does not support tool calling or structured output. Those features [are supported](https://api-docs.deepseek.com/guides/function_calling) by DeepSeek-V3 (specified via `model="deepseek-chat"`).

## Setup[​](#setup "Direct link to Setup")

To access DeepSeek models you'll need to create a/an DeepSeek account, get an API key, and install the `langchain-deepseek` integration package.

### Credentials[​](#credentials "Direct link to Credentials")

Head to [DeepSeek's API Key page](https://platform.deepseek.com/api_keys) to sign up to DeepSeek and generate an API key. Once you've done this set the `DEEPSEEK_API_KEY` environment variable:

```
import getpass  
import os  
  
if not os.getenv("DEEPSEEK_API_KEY"):  
    os.environ["DEEPSEEK_API_KEY"] = getpass.getpass("Enter your DeepSeek API key: ")  

```

To enable automated tracing of your model calls, set your [LangSmith](https://docs.smith.langchain.com/) API key:

```
# os.environ["LANGSMITH_TRACING"] = "true"  
# os.environ["LANGSMITH_API_KEY"] = getpass.getpass("Enter your LangSmith API key: ")  

```

### Installation[​](#installation "Direct link to Installation")

The LangChain DeepSeek integration lives in the `langchain-deepseek` package:

```
%pip install -qU langchain-deepseek  

```

## Instantiation[​](#instantiation "Direct link to Instantiation")

Now we can instantiate our model object and generate chat completions:

```
from langchain_deepseek import ChatDeepSeek  
  
llm = ChatDeepSeek(  
    model="deepseek-chat",  
    temperature=0,  
    max_tokens=None,  
    timeout=None,  
    max_retries=2,  
    # other params...  
)  

```

**API Reference:**[ChatDeepSeek](https://python.langchain.com/api_reference/deepseek/chat_models/langchain_deepseek.chat_models.ChatDeepSeek.html)

## Invocation[​](#invocation "Direct link to Invocation")

```
messages = [  
    (  
        "system",  
        "You are a helpful assistant that translates English to French. Translate the user sentence.",  
    ),  
    ("human", "I love programming."),  
]  
ai_msg = llm.invoke(messages)  
ai_msg.content  

```

## Chaining[​](#chaining "Direct link to Chaining")

We can [chain](/docs/how_to/sequence/) our model with a prompt template like so:

```
from langchain_core.prompts import ChatPromptTemplate  
  
prompt = ChatPromptTemplate(  
    [  
        (  
            "system",  
            "You are a helpful assistant that translates {input_language} to {output_language}.",  
        ),  
        ("human", "{input}"),  
    ]  
)  
  
chain = prompt | llm  
chain.invoke(  
    {  
        "input_language": "English",  
        "output_language": "German",  
        "input": "I love programming.",  
    }  
)  

```

**API Reference:**[ChatPromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.chat.ChatPromptTemplate.html)

## API reference[​](#api-reference "Direct link to API reference")

For detailed documentation of all ChatDeepSeek features and configurations head to the [API Reference](https://python.langchain.com/api_reference/deepseek/chat_models/langchain_deepseek.chat_models.ChatDeepSeek.html).

## Related[​](#related "Direct link to Related")

* Chat model [conceptual guide](/docs/concepts/chat_models/)
* Chat model [how-to guides](/docs/how_to/#chat-models)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/chat/deepseek.ipynb)