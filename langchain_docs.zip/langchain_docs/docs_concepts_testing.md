# Source: https://python.langchain.com/docs/concepts/testing/

* [Conceptual guide](/docs/concepts/)
* Testing

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/concepts/testing.mdx)

# Testing



Testing is a critical part of the development process that ensures your code works as expected and meets the desired quality standards.

In the LangChain ecosystem, we have 2 main types of tests: **unit tests** and **integration tests**.

For integrations that implement standard LangChain abstractions, we have a set of **standard tests** (both unit and integration) that help maintain compatibility between different components and ensure reliability of high-usage ones.

## Unit Tests[​](#unit-tests "Direct link to Unit Tests")

**Definition**: Unit tests are designed to validate the smallest parts of your code—individual functions or methods—ensuring they work as expected in isolation. They do not rely on external systems or integrations.

**Example**: Testing the `convert_langchain_aimessage_to_dict` function to confirm it correctly converts an AI message to a dictionary format:

```
from langchain_core.messages import AIMessage, ToolCall, convert_to_openai_messages  
  
def test_convert_to_openai_messages():  
    ai_message = AIMessage(  
        content="Let me call that tool for you!",  
        tool_calls=[  
            ToolCall(name='parrot_multiply_tool', id='1', args={'a': 2, 'b': 3}),  
        ]  
    )  
      
    result = convert_to_openai_messages(ai_message)  
      
    expected = {  
        "role": "assistant",  
        "tool_calls": [  
            {  
                "type": "function",  
                "id": "1",  
                "function": {  
                    "name": "parrot_multiply_tool",  
                    "arguments": '{"a": 2, "b": 3}',  
                },  
            }  
        ],  
        "content": "Let me call that tool for you!",  
    }  
    assert result == expected  # Ensure conversion matches expected output  

```

**API Reference:**[AIMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.ai.AIMessage.html) | [ToolCall](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.tool.ToolCall.html) | [convert\_to\_openai\_messages](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.utils.convert_to_openai_messages.html)

---

## Integration Tests[​](#integration-tests "Direct link to Integration Tests")

**Definition**: Integration tests validate that multiple components or systems work together as expected. For tools or integrations relying on external services, these tests often ensure end-to-end functionality.

**Example**: Testing `ParrotMultiplyTool` with access to an API service that multiplies two numbers and adds 80:

```
def test_integration_with_service():  
    tool = ParrotMultiplyTool()  
    result = tool.invoke({"a": 2, "b": 3})  
    assert result == 86  

```

---

## Standard Tests[​](#standard-tests "Direct link to Standard Tests")

**Definition**: Standard tests are pre-defined tests provided by LangChain to ensure consistency and reliability across all tools and integrations. They include both unit and integration test templates tailored for LangChain components.

**Example**: Subclassing LangChain's `ToolsUnitTests` or `ToolsIntegrationTests` to automatically run standard tests:

```
from langchain_tests.unit_tests import ToolsUnitTests  
  
class TestParrotMultiplyToolUnit(ToolsUnitTests):  
    @property  
    def tool_constructor(self):  
        return ParrotMultiplyTool  
  
    def tool_invoke_params_example(self):  
        return {"a": 2, "b": 3}  

```

**API Reference:**[ToolsUnitTests](https://python.langchain.com/api_reference/tests/unit_tests/langchain_tests.unit_tests.tools.ToolsUnitTests.html)

To learn more, check out our guide on [how to add standard tests to an integration](/docs/contributing/how_to/integrations/standard_tests/).

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/concepts/testing.mdx)