# Source: https://python.langchain.com/docs/integrations/chat/oci_generative_ai/

* [Components](/docs/integrations/components/)
* [Chat models](/docs/integrations/chat/)
* OCIGenAI

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/oci_generative_ai.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/oci_generative_ai.ipynb)

# ChatOCIGenAI

This notebook provides a quick overview for getting started with OCIGenAI [chat models](/docs/concepts/chat_models/). For detailed documentation of all ChatOCIGenAI features and configurations head to the [API reference](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.oci_generative_ai.ChatOCIGenAI.html).

Oracle Cloud Infrastructure (OCI) Generative AI is a fully managed service that provides a set of state-of-the-art, customizable large language models (LLMs) that cover a wide range of use cases, and which is available through a single API.
Using the OCI Generative AI service you can access ready-to-use pretrained models, or create and host your own fine-tuned custom models based on your own data on dedicated AI clusters. Detailed documentation of the service and API is available **[here](https://docs.oracle.com/en-us/iaas/Content/generative-ai/home.htm)** and **[here](https://docs.oracle.com/en-us/iaas/api/#/en/generative-ai/20231130/)**.

## Overview[​](#overview "Direct link to Overview")

### Integration details[​](#integration-details "Direct link to Integration details")

| Class | Package | Local | Serializable | [JS support](https://js.langchain.com/docs/integrations/chat/oci_generative_ai) |
| --- | --- | --- | --- | --- |
| [ChatOCIGenAI](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.oci_generative_ai.ChatOCIGenAI.html) | [langchain-community](https://python.langchain.com/api_reference/community/index.html) | ❌ | ❌ | ❌ |

### Model features[​](#model-features "Direct link to Model features")

| [Tool calling](/docs/how_to/tool_calling/) | [Structured output](/docs/how_to/structured_output/) | [JSON mode](/docs/how_to/structured_output/#advanced-specifying-the-method-for-structuring-outputs) | [Image input](/docs/how_to/multimodal_inputs/) | Audio input | Video input | [Token-level streaming](/docs/how_to/chat_streaming/) | Native async | [Token usage](/docs/how_to/chat_token_usage_tracking/) | [Logprobs](/docs/how_to/logprobs/) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ✅ | ❌ | ❌ | ❌ |

## Setup[​](#setup "Direct link to Setup")

To access OCIGenAI models you'll need to install the `oci` and `langchain-community` packages.

### Credentials[​](#credentials "Direct link to Credentials")

The credentials and authentication methods supported for this integration are equivalent to those used with other OCI services and follow the **[standard SDK authentication](https://docs.oracle.com/en-us/iaas/Content/API/Concepts/sdk_authentication_methods.htm)** methods, specifically API Key, session token, instance principal, and resource principal.

API key is the default authentication method used in the examples above. The following example demonstrates how to use a different authentication method (session token)

### Installation[​](#installation "Direct link to Installation")

The LangChain OCIGenAI integration lives in the `langchain-community` package and you will also need to install the `oci` package:

```
%pip install -qU langchain-community oci  

```

## Instantiation[​](#instantiation "Direct link to Instantiation")

Now we can instantiate our model object and generate chat completions:

```
from langchain_community.chat_models.oci_generative_ai import ChatOCIGenAI  
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage  
  
chat = ChatOCIGenAI(  
    model_id="cohere.command-r-16k",  
    service_endpoint="https://inference.generativeai.us-chicago-1.oci.oraclecloud.com",  
    compartment_id="MY_OCID",  
    model_kwargs={"temperature": 0.7, "max_tokens": 500},  
)  

```

**API Reference:**[ChatOCIGenAI](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.oci_generative_ai.ChatOCIGenAI.html) | [AIMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.ai.AIMessage.html) | [HumanMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.human.HumanMessage.html) | [SystemMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.system.SystemMessage.html)

## Invocation[​](#invocation "Direct link to Invocation")

```
messages = [  
    SystemMessage(content="your are an AI assistant."),  
    AIMessage(content="Hi there human!"),  
    HumanMessage(content="tell me a joke."),  
]  
response = chat.invoke(messages)  

```

```
print(response.content)  

```

## Chaining[​](#chaining "Direct link to Chaining")

We can [chain](/docs/how_to/sequence/) our model with a prompt template like so:

```
from langchain_core.prompts import ChatPromptTemplate  
  
prompt = ChatPromptTemplate.from_template("Tell me a joke about {topic}")  
chain = prompt | chat  
  
response = chain.invoke({"topic": "dogs"})  
print(response.content)  

```

**API Reference:**[ChatPromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.chat.ChatPromptTemplate.html)

## API reference[​](#api-reference "Direct link to API reference")

For detailed documentation of all ChatOCIGenAI features and configurations head to the API reference: <https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.oci_generative_ai.ChatOCIGenAI.html>

## Related[​](#related "Direct link to Related")

* Chat model [conceptual guide](/docs/concepts/chat_models/)
* Chat model [how-to guides](/docs/how_to/#chat-models)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/chat/oci_generative_ai.ipynb)