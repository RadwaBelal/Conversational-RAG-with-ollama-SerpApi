# Source: https://python.langchain.com/docs/integrations/providers/bibtex/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* BibTeX

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/bibtex.mdx)

# BibTeX

> [BibTeX](https://www.ctan.org/pkg/bibtex) is a file format and reference management system commonly used in conjunction with `LaTeX` typesetting. It serves as a way to organize and store bibliographic information for academic and research documents.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

We have to install the `bibtexparser` and `pymupdf` packages.

```
pip install bibtexparser pymupdf  

```

## Document loader[​](#document-loader "Direct link to Document loader")

See a [usage example](/docs/integrations/document_loaders/bibtex/).

```
from langchain_community.document_loaders import BibtexLoader  

```

**API Reference:**[BibtexLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.bibtex.BibtexLoader.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/bibtex.mdx)