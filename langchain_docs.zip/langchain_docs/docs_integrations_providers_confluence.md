# Source: https://python.langchain.com/docs/integrations/providers/confluence/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Confluence

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/confluence.mdx)

# Confluence

> [Confluence](https://www.atlassian.com/software/confluence) is a wiki collaboration platform that saves and organizes all of the project-related material. `Confluence` is a knowledge base that primarily handles content management activities.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

```
pip install atlassian-python-api  

```

We need to set up `username/api_key` or `Oauth2 login`.
See [instructions](https://support.atlassian.com/atlassian-account/docs/manage-api-tokens-for-your-atlassian-account/).

## Document Loader[​](#document-loader "Direct link to Document Loader")

See a [usage example](/docs/integrations/document_loaders/confluence/).

```
from langchain_community.document_loaders import ConfluenceLoader  

```

**API Reference:**[ConfluenceLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.confluence.ConfluenceLoader.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/confluence.mdx)