# Source: https://python.langchain.com/docs/how_to/streaming/

* [How-to guides](/docs/how_to/)
* How to stream runnables

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/how_to/streaming.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/how_to/streaming.ipynb)

# How to stream runnables

Prerequisites

This guide assumes familiarity with the following concepts:

* [Chat models](/docs/concepts/chat_models/)
* [LangChain Expression Language](/docs/concepts/lcel/)
* [Output parsers](/docs/concepts/output_parsers/)

Streaming is critical in making applications based on LLMs feel responsive to end-users.

Important LangChain primitives like [chat models](/docs/concepts/chat_models/), [output parsers](/docs/concepts/output_parsers/), [prompts](/docs/concepts/prompt_templates/), [retrievers](/docs/concepts/retrievers/), and [agents](/docs/concepts/agents/) implement the LangChain [Runnable Interface](/docs/concepts/runnables/).

This interface provides two general approaches to stream content:

1. sync `stream` and async `astream`: a **default implementation** of streaming that streams the **final output** from the chain.
2. async `astream_events` and async `astream_log`: these provide a way to stream both **intermediate steps** and **final output** from the chain.

Let's take a look at both approaches, and try to understand how to use them.

info

For a higher-level overview of streaming techniques in LangChain, see [this section of the conceptual guide](/docs/concepts/streaming/).

## Using Stream[​](#using-stream "Direct link to Using Stream")

All `Runnable` objects implement a sync method called `stream` and an async variant called `astream`.

These methods are designed to stream the final output in chunks, yielding each chunk as soon as it is available.

Streaming is only possible if all steps in the program know how to process an **input stream**; i.e., process an input chunk one at a time, and yield a corresponding output chunk.

The complexity of this processing can vary, from straightforward tasks like emitting tokens produced by an LLM, to more challenging ones like streaming parts of JSON results before the entire JSON is complete.

The best place to start exploring streaming is with the single most important components in LLMs apps-- the LLMs themselves!

### LLMs and Chat Models[​](#llms-and-chat-models "Direct link to LLMs and Chat Models")

Large language models and their chat variants are the primary bottleneck in LLM based apps.

Large language models can take **several seconds** to generate a complete response to a query. This is far slower than the **~200-300 ms** threshold at which an application feels responsive to an end user.

The key strategy to make the application feel more responsive is to show intermediate progress; viz., to stream the output from the model **token by token**.

We will show examples of streaming using a chat model. Choose one from the options below:

Select [chat model](/docs/integrations/chat/):

OpenAI▾

- [OpenAI](#)
- [Anthropic](#)
- [Azure](#)
- [Google Gemini](#)
- [Google Vertex](#)
- [AWS](#)
- [Groq](#)
- [Cohere](#)
- [NVIDIA](#)
- [Fireworks AI](#)
- [Mistral AI](#)
- [Together AI](#)
- [IBM watsonx](#)
- [Databricks](#)
- [xAI](#)
- [Perplexity](#)

```
pip install -qU "langchain[openai]"  

```

```
import getpass  
import os  
  
if not os.environ.get("OPENAI_API_KEY"):  
  os.environ["OPENAI_API_KEY"] = getpass.getpass("Enter API key for OpenAI: ")  
  
from langchain.chat_models import init_chat_model  
  
model = init_chat_model("gpt-4o-mini", model_provider="openai")  

```

Let's start with the sync `stream` API:

```
chunks = []  
for chunk in model.stream("what color is the sky?"):  
    chunks.append(chunk)  
    print(chunk.content, end="|", flush=True)  

```

```
The| sky| appears| blue| during| the| day|.|  

```

Alternatively, if you're working in an async environment, you may consider using the async `astream` API:

```
chunks = []  
async for chunk in model.astream("what color is the sky?"):  
    chunks.append(chunk)  
    print(chunk.content, end="|", flush=True)  

```

```
The| sky| appears| blue| during| the| day|.|  

```

Let's inspect one of the chunks

```
chunks[0]  

```

```
AIMessageChunk(content='The', id='run-b36bea64-5511-4d7a-b6a3-a07b3db0c8e7')  

```

We got back something called an `AIMessageChunk`. This chunk represents a part of an `AIMessage`.

Message chunks are additive by design -- one can simply add them up to get the state of the response so far!

```
chunks[0] + chunks[1] + chunks[2] + chunks[3] + chunks[4]  

```

```
AIMessageChunk(content='The sky appears blue during', id='run-b36bea64-5511-4d7a-b6a3-a07b3db0c8e7')  

```

### Chains[​](#chains "Direct link to Chains")

Virtually all LLM applications involve more steps than just a call to a language model.

Let's build a simple chain using `LangChain Expression Language` (`LCEL`) that combines a prompt, model and a parser and verify that streaming works.

We will use [`StrOutputParser`](https://python.langchain.com/api_reference/core/output_parsers/langchain_core.output_parsers.string.StrOutputParser.html) to parse the output from the model. This is a simple parser that extracts the `content` field from an `AIMessageChunk`, giving us the `token` returned by the model.

tip

LCEL is a *declarative* way to specify a "program" by chainining together different LangChain primitives. Chains created using LCEL benefit from an automatic implementation of `stream` and `astream` allowing streaming of the final output. In fact, chains created with LCEL implement the entire standard Runnable interface.

```
from langchain_core.output_parsers import StrOutputParser  
from langchain_core.prompts import ChatPromptTemplate  
  
prompt = ChatPromptTemplate.from_template("tell me a joke about {topic}")  
parser = StrOutputParser()  
chain = prompt | model | parser  
  
async for chunk in chain.astream({"topic": "parrot"}):  
    print(chunk, end="|", flush=True)  

```

**API Reference:**[StrOutputParser](https://python.langchain.com/api_reference/core/output_parsers/langchain_core.output_parsers.string.StrOutputParser.html) | [ChatPromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.chat.ChatPromptTemplate.html)

```
Here|'s| a| joke| about| a| par|rot|:|  
  
A man| goes| to| a| pet| shop| to| buy| a| par|rot|.| The| shop| owner| shows| him| two| stunning| pa|rr|ots| with| beautiful| pl|um|age|.|  
  
"|There|'s| a| talking| par|rot| an|d a| non|-|talking| par|rot|,"| the| owner| says|.| "|The| talking| par|rot| costs| $|100|,| an|d the| non|-|talking| par|rot| is| $|20|."|  
  
The| man| says|,| "|I|'ll| take| the| non|-|talking| par|rot| at| $|20|."|  
  
He| pays| an|d leaves| with| the| par|rot|.| As| he|'s| walking| down| the| street|,| the| par|rot| looks| up| at| him| an|d says|,| "|You| know|,| you| really| are| a| stupi|d man|!"|  
  
The| man| is| stun|ne|d an|d looks| at| the| par|rot| in| dis|bel|ief|.| The| par|rot| continues|,| "|Yes|,| you| got| r|ippe|d off| big| time|!| I| can| talk| just| as| well| as| that| other| par|rot|,| an|d you| only| pai|d $|20| |for| me|!"|  

```

Note that we're getting streaming output even though we're using `parser` at the end of the chain above. The `parser` operates on each streaming chunk individidually. Many of the [LCEL primitives](/docs/how_to/#langchain-expression-language-lcel) also support this kind of transform-style passthrough streaming, which can be very convenient when constructing apps.

Custom functions can be [designed to return generators](/docs/how_to/functions/#streaming), which are able to operate on streams.

Certain runnables, like [prompt templates](/docs/how_to/#prompt-templates) and [chat models](/docs/how_to/#chat-models), cannot process individual chunks and instead aggregate all previous steps. Such runnables can interrupt the streaming process.

note

The LangChain Expression language allows you to separate the construction of a chain from the mode in which it is used (e.g., sync/async, batch/streaming etc.). If this is not relevant to what you're building, you can also rely on a standard **imperative** programming approach by
caling `invoke`, `batch` or `stream` on each component individually, assigning the results to variables and then using them downstream as you see fit.

### Working with Input Streams[​](#working-with-input-streams "Direct link to Working with Input Streams")

What if you wanted to stream JSON from the output as it was being generated?

If you were to rely on `json.loads` to parse the partial json, the parsing would fail as the partial json wouldn't be valid json.

You'd likely be at a complete loss of what to do and claim that it wasn't possible to stream JSON.

Well, turns out there is a way to do it -- the parser needs to operate on the **input stream**, and attempt to "auto-complete" the partial json into a valid state.

Let's see such a parser in action to understand what this means.

```
from langchain_core.output_parsers import JsonOutputParser  
  
chain = (  
    model | JsonOutputParser()  
)  # Due to a bug in older versions of Langchain, JsonOutputParser did not stream results from some models  
async for text in chain.astream(  
    "output a list of the countries france, spain and japan and their populations in JSON format. "  
    'Use a dict with an outer key of "countries" which contains a list of countries. '  
    "Each country should have the key `name` and `population`"  
):  
    print(text, flush=True)  

```

**API Reference:**[JsonOutputParser](https://python.langchain.com/api_reference/core/output_parsers/langchain_core.output_parsers.json.JsonOutputParser.html)

```
{}  
{'countries': []}  
{'countries': [{}]}  
{'countries': [{'name': ''}]}  
{'countries': [{'name': 'France'}]}  
{'countries': [{'name': 'France', 'population': 67}]}  
{'countries': [{'name': 'France', 'population': 67413}]}  
{'countries': [{'name': 'France', 'population': 67413000}]}  
{'countries': [{'name': 'France', 'population': 67413000}, {}]}  
{'countries': [{'name': 'France', 'population': 67413000}, {'name': ''}]}  
{'countries': [{'name': 'France', 'population': 67413000}, {'name': 'Spain'}]}  
{'countries': [{'name': 'France', 'population': 67413000}, {'name': 'Spain', 'population': 47}]}  
{'countries': [{'name': 'France', 'population': 67413000}, {'name': 'Spain', 'population': 47351}]}  
{'countries': [{'name': 'France', 'population': 67413000}, {'name': 'Spain', 'population': 47351567}]}  
{'countries': [{'name': 'France', 'population': 67413000}, {'name': 'Spain', 'population': 47351567}, {}]}  
{'countries': [{'name': 'France', 'population': 67413000}, {'name': 'Spain', 'population': 47351567}, {'name': ''}]}  
{'countries': [{'name': 'France', 'population': 67413000}, {'name': 'Spain', 'population': 47351567}, {'name': 'Japan'}]}  
{'countries': [{'name': 'France', 'population': 67413000}, {'name': 'Spain', 'population': 47351567}, {'name': 'Japan', 'population': 125}]}  
{'countries': [{'name': 'France', 'population': 67413000}, {'name': 'Spain', 'population': 47351567}, {'name': 'Japan', 'population': 125584}]}  
{'countries': [{'name': 'France', 'population': 67413000}, {'name': 'Spain', 'population': 47351567}, {'name': 'Japan', 'population': 125584000}]}  

```

Now, let's **break** streaming. We'll use the previous example and append an extraction function at the end that extracts the country names from the finalized JSON.

warning

Any steps in the chain that operate on **finalized inputs** rather than on **input streams** can break streaming functionality via `stream` or `astream`.

tip

Later, we will discuss the `astream_events` API which streams results from intermediate steps. This API will stream results from intermediate steps even if the chain contains steps that only operate on **finalized inputs**.

```
from langchain_core.output_parsers import (  
    JsonOutputParser,  
)  
  
  
# A function that operates on finalized inputs  
# rather than on an input_stream  
def _extract_country_names(inputs):  
    """A function that does not operates on input streams and breaks streaming."""  
    if not isinstance(inputs, dict):  
        return ""  
  
    if "countries" not in inputs:  
        return ""  
  
    countries = inputs["countries"]  
  
    if not isinstance(countries, list):  
        return ""  
  
    country_names = [  
        country.get("name") for country in countries if isinstance(country, dict)  
    ]  
    return country_names  
  
  
chain = model | JsonOutputParser() | _extract_country_names  
  
async for text in chain.astream(  
    "output a list of the countries france, spain and japan and their populations in JSON format. "  
    'Use a dict with an outer key of "countries" which contains a list of countries. '  
    "Each country should have the key `name` and `population`"  
):  
    print(text, end="|", flush=True)  

```

**API Reference:**[JsonOutputParser](https://python.langchain.com/api_reference/core/output_parsers/langchain_core.output_parsers.json.JsonOutputParser.html)

```
['France', 'Spain', 'Japan']|  

```

#### Generator Functions[​](#generator-functions "Direct link to Generator Functions")

Let's fix the streaming using a generator function that can operate on the **input stream**.

tip

A generator function (a function that uses `yield`) allows writing code that operates on **input streams**

```
from langchain_core.output_parsers import JsonOutputParser  
  
  
async def _extract_country_names_streaming(input_stream):  
    """A function that operates on input streams."""  
    country_names_so_far = set()  
  
    async for input in input_stream:  
        if not isinstance(input, dict):  
            continue  
  
        if "countries" not in input:  
            continue  
  
        countries = input["countries"]  
  
        if not isinstance(countries, list):  
            continue  
  
        for country in countries:  
            name = country.get("name")  
            if not name:  
                continue  
            if name not in country_names_so_far:  
                yield name  
                country_names_so_far.add(name)  
  
  
chain = model | JsonOutputParser() | _extract_country_names_streaming  
  
async for text in chain.astream(  
    "output a list of the countries france, spain and japan and their populations in JSON format. "  
    'Use a dict with an outer key of "countries" which contains a list of countries. '  
    "Each country should have the key `name` and `population`",  
):  
    print(text, end="|", flush=True)  

```

**API Reference:**[JsonOutputParser](https://python.langchain.com/api_reference/core/output_parsers/langchain_core.output_parsers.json.JsonOutputParser.html)

```
France|Spain|Japan|  

```

note

Because the code above is relying on JSON auto-completion, you may see partial names of countries (e.g., `Sp` and `Spain`), which is not what one would want for an extraction result!

We're focusing on streaming concepts, not necessarily the results of the chains.

### Non-streaming components[​](#non-streaming-components "Direct link to Non-streaming components")

Some built-in components like Retrievers do not offer any `streaming`. What happens if we try to `stream` them? 🤨

```
from langchain_community.vectorstores import FAISS  
from langchain_core.output_parsers import StrOutputParser  
from langchain_core.prompts import ChatPromptTemplate  
from langchain_core.runnables import RunnablePassthrough  
from langchain_openai import OpenAIEmbeddings  
  
template = """Answer the question based only on the following context:  
{context}  
  
Question: {question}  
"""  
prompt = ChatPromptTemplate.from_template(template)  
  
vectorstore = FAISS.from_texts(  
    ["harrison worked at kensho", "harrison likes spicy food"],  
    embedding=OpenAIEmbeddings(),  
)  
retriever = vectorstore.as_retriever()  
  
chunks = [chunk for chunk in retriever.stream("where did harrison work?")]  
chunks  

```

**API Reference:**[FAISS](https://python.langchain.com/api_reference/community/vectorstores/langchain_community.vectorstores.faiss.FAISS.html) | [StrOutputParser](https://python.langchain.com/api_reference/core/output_parsers/langchain_core.output_parsers.string.StrOutputParser.html) | [ChatPromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.chat.ChatPromptTemplate.html) | [RunnablePassthrough](https://python.langchain.com/api_reference/core/runnables/langchain_core.runnables.passthrough.RunnablePassthrough.html) | [OpenAIEmbeddings](https://python.langchain.com/api_reference/openai/embeddings/langchain_openai.embeddings.base.OpenAIEmbeddings.html)

```
[[Document(page_content='harrison worked at kensho'),  
  Document(page_content='harrison likes spicy food')]]  

```

Stream just yielded the final result from that component.

This is OK 🥹! Not all components have to implement streaming -- in some cases streaming is either unnecessary, difficult or just doesn't make sense.

tip

An LCEL chain constructed using non-streaming components, will still be able to stream in a lot of cases, with streaming of partial output starting after the last non-streaming step in the chain.

```
retrieval_chain = (  
    {  
        "context": retriever.with_config(run_name="Docs"),  
        "question": RunnablePassthrough(),  
    }  
    | prompt  
    | model  
    | StrOutputParser()  
)  

```

```
for chunk in retrieval_chain.stream(  
    "Where did harrison work? " "Write 3 made up sentences about this place."  
):  
    print(chunk, end="|", flush=True)  

```

```
Base|d on| the| given| context|,| Harrison| worke|d at| K|ens|ho|.|  
  
Here| are| |3| |made| up| sentences| about| this| place|:|  
  
1|.| K|ens|ho| was| a| cutting|-|edge| technology| company| known| for| its| innovative| solutions| in| artificial| intelligence| an|d data| analytics|.|  
  
2|.| The| modern| office| space| at| K|ens|ho| feature|d open| floor| plans|,| collaborative| work|sp|aces|,| an|d a| vib|rant| atmosphere| that| fos|tere|d creativity| an|d team|work|.|  
  
3|.| With| its| prime| location| in| the| heart| of| the| city|,| K|ens|ho| attracte|d top| talent| from| aroun|d the| worl|d,| creating| a| diverse| an|d dynamic| work| environment|.|  

```

Now that we've seen how `stream` and `astream` work, let's venture into the world of streaming events. 🏞️

## Using Stream Events[​](#using-stream-events "Direct link to Using Stream Events")

Event Streaming is a **beta** API. This API may change a bit based on feedback.

note

This guide demonstrates the `V2` API and requires langchain-core >= 0.2. For the `V1` API compatible with older versions of LangChain, see [here](https://python.langchain.com/v0.1/docs/expression_language/streaming/#using-stream-events).

```
import langchain_core  
  
langchain_core.__version__  

```

For the `astream_events` API to work properly:

* Use `async` throughout the code to the extent possible (e.g., async tools etc)
* Propagate callbacks if defining custom functions / runnables
* Whenever using runnables without LCEL, make sure to call `.astream()` on LLMs rather than `.ainvoke` to force the LLM to stream tokens.
* Let us know if anything doesn't work as expected! :)

### Event Reference[​](#event-reference "Direct link to Event Reference")

Below is a reference table that shows some events that might be emitted by the various Runnable objects.

note

When streaming is implemented properly, the inputs to a runnable will not be known until after the input stream has been entirely consumed. This means that `inputs` will often be included only for `end` events and rather than for `start` events.

| event | name | chunk | input | output |
| --- | --- | --- | --- | --- |
| on\_chat\_model\_start | [model name] |  | {"messages": [[SystemMessage, HumanMessage]]} |  |
| on\_chat\_model\_stream | [model name] | AIMessageChunk(content="hello") |  |  |
| on\_chat\_model\_end | [model name] |  | {"messages": [[SystemMessage, HumanMessage]]} | AIMessageChunk(content="hello world") |
| on\_llm\_start | [model name] |  | {'input': 'hello'} |  |
| on\_llm\_stream | [model name] | 'Hello' |  |  |
| on\_llm\_end | [model name] |  | 'Hello human!' |  |
| on\_chain\_start | format\_docs |  |  |  |
| on\_chain\_stream | format\_docs | "hello world!, goodbye world!" |  |  |
| on\_chain\_end | format\_docs |  | [Document(...)] | "hello world!, goodbye world!" |
| on\_tool\_start | some\_tool |  | {"x": 1, "y": "2"} |  |
| on\_tool\_end | some\_tool |  |  | {"x": 1, "y": "2"} |
| on\_retriever\_start | [retriever name] |  | {"query": "hello"} |  |
| on\_retriever\_end | [retriever name] |  | {"query": "hello"} | [Document(...), ..] |
| on\_prompt\_start | [template\_name] |  | {"question": "hello"} |  |
| on\_prompt\_end | [template\_name] |  | {"question": "hello"} | ChatPromptValue(messages: [SystemMessage, ...]) |

### Chat Model[​](#chat-model "Direct link to Chat Model")

Let's start off by looking at the events produced by a chat model.

```
events = []  
async for event in model.astream_events("hello"):  
    events.append(event)  

```

note

For `langchain-core<0.3.37`, set the `version` kwarg explicitly (e.g., `model.astream_events("hello", version="v2")`).

Let's take a look at the few of the start event and a few of the end events.

```
events[:3]  

```

```
[{'event': 'on_chat_model_start',  
  'data': {'input': 'hello'},  
  'name': 'ChatAnthropic',  
  'tags': [],  
  'run_id': 'b18d016d-8b9b-49e7-a555-44db498fcf66',  
  'metadata': {'ls_provider': 'anthropic',  
   'ls_model_name': 'claude-3-sonnet-20240229',  
   'ls_model_type': 'chat',  
   'ls_temperature': 0.0,  
   'ls_max_tokens': 1024},  
  'parent_ids': []},  
 {'event': 'on_chat_model_stream',  
  'run_id': 'b18d016d-8b9b-49e7-a555-44db498fcf66',  
  'name': 'ChatAnthropic',  
  'tags': [],  
  'metadata': {'ls_provider': 'anthropic',  
   'ls_model_name': 'claude-3-sonnet-20240229',  
   'ls_model_type': 'chat',  
   'ls_temperature': 0.0,  
   'ls_max_tokens': 1024},  
  'data': {'chunk': AIMessageChunk(content='', additional_kwargs={}, response_metadata={}, id='run-b18d016d-8b9b-49e7-a555-44db498fcf66', usage_metadata={'input_tokens': 8, 'output_tokens': 4, 'total_tokens': 12, 'input_token_details': {'cache_creation': 0, 'cache_read': 0}})},  
  'parent_ids': []},  
 {'event': 'on_chat_model_stream',  
  'run_id': 'b18d016d-8b9b-49e7-a555-44db498fcf66',  
  'name': 'ChatAnthropic',  
  'tags': [],  
  'metadata': {'ls_provider': 'anthropic',  
   'ls_model_name': 'claude-3-sonnet-20240229',  
   'ls_model_type': 'chat',  
   'ls_temperature': 0.0,  
   'ls_max_tokens': 1024},  
  'data': {'chunk': AIMessageChunk(content='Hello! How can', additional_kwargs={}, response_metadata={}, id='run-b18d016d-8b9b-49e7-a555-44db498fcf66')},  
  'parent_ids': []}]  

```

```
events[-2:]  

```

```
[{'event': 'on_chat_model_stream',  
  'run_id': 'b18d016d-8b9b-49e7-a555-44db498fcf66',  
  'name': 'ChatAnthropic',  
  'tags': [],  
  'metadata': {'ls_provider': 'anthropic',  
   'ls_model_name': 'claude-3-sonnet-20240229',  
   'ls_model_type': 'chat',  
   'ls_temperature': 0.0,  
   'ls_max_tokens': 1024},  
  'data': {'chunk': AIMessageChunk(content='', additional_kwargs={}, response_metadata={'stop_reason': 'end_turn', 'stop_sequence': None}, id='run-b18d016d-8b9b-49e7-a555-44db498fcf66', usage_metadata={'input_tokens': 0, 'output_tokens': 12, 'total_tokens': 12, 'input_token_details': {}})},  
  'parent_ids': []},  
 {'event': 'on_chat_model_end',  
  'data': {'output': AIMessageChunk(content='Hello! How can I assist you today?', additional_kwargs={}, response_metadata={'stop_reason': 'end_turn', 'stop_sequence': None}, id='run-b18d016d-8b9b-49e7-a555-44db498fcf66', usage_metadata={'input_tokens': 8, 'output_tokens': 16, 'total_tokens': 24, 'input_token_details': {'cache_creation': 0, 'cache_read': 0}})},  
  'run_id': 'b18d016d-8b9b-49e7-a555-44db498fcf66',  
  'name': 'ChatAnthropic',  
  'tags': [],  
  'metadata': {'ls_provider': 'anthropic',  
   'ls_model_name': 'claude-3-sonnet-20240229',  
   'ls_model_type': 'chat',  
   'ls_temperature': 0.0,  
   'ls_max_tokens': 1024},  
  'parent_ids': []}]  

```

### Chain[​](#chain "Direct link to Chain")

Let's revisit the example chain that parsed streaming JSON to explore the streaming events API.

```
chain = (  
    model | JsonOutputParser()  
)  # Due to a bug in older versions of Langchain, JsonOutputParser did not stream results from some models  
  
events = [  
    event  
    async for event in chain.astream_events(  
        "output a list of the countries france, spain and japan and their populations in JSON format. "  
        'Use a dict with an outer key of "countries" which contains a list of countries. '  
        "Each country should have the key `name` and `population`",  
    )  
]  

```

If you examine at the first few events, you'll notice that there are **3** different start events rather than **2** start events.

The three start events correspond to:

1. The chain (model + parser)
2. The model
3. The parser

```
events[:3]  

```

```
[{'event': 'on_chain_start',  
  'data': {'input': 'output a list of the countries france, spain and japan and their populations in JSON format. Use a dict with an outer key of "countries" which contains a list of countries. Each country should have the key `name` and `population`'},  
  'name': 'RunnableSequence',  
  'tags': [],  
  'run_id': '4765006b-16e2-4b1d-a523-edd9fd64cb92',  
  'metadata': {}},  
 {'event': 'on_chat_model_start',  
  'data': {'input': {'messages': [[HumanMessage(content='output a list of the countries france, spain and japan and their populations in JSON format. Use a dict with an outer key of "countries" which contains a list of countries. Each country should have the key `name` and `population`')]]}},  
  'name': 'ChatAnthropic',  
  'tags': ['seq:step:1'],  
  'run_id': '0320c234-7b52-4a14-ae4e-5f100949e589',  
  'metadata': {}},  
 {'event': 'on_chat_model_stream',  
  'data': {'chunk': AIMessageChunk(content='{', id='run-0320c234-7b52-4a14-ae4e-5f100949e589')},  
  'run_id': '0320c234-7b52-4a14-ae4e-5f100949e589',  
  'name': 'ChatAnthropic',  
  'tags': ['seq:step:1'],  
  'metadata': {}}]  

```

What do you think you'd see if you looked at the last 3 events? what about the middle?

Let's use this API to take output the stream events from the model and the parser. We're ignoring start events, end events and events from the chain.

```
num_events = 0  
  
async for event in chain.astream_events(  
    "output a list of the countries france, spain and japan and their populations in JSON format. "  
    'Use a dict with an outer key of "countries" which contains a list of countries. '  
    "Each country should have the key `name` and `population`",  
):  
    kind = event["event"]  
    if kind == "on_chat_model_stream":  
        print(  
            f"Chat model chunk: {repr(event['data']['chunk'].content)}",  
            flush=True,  
        )  
    if kind == "on_parser_stream":  
        print(f"Parser chunk: {event['data']['chunk']}", flush=True)  
    num_events += 1  
    if num_events > 30:  
        # Truncate the output  
        print("...")  
        break  

```

```
Chat model chunk: ''  
Chat model chunk: '{'  
Parser chunk: {}  
Chat model chunk: '\n  "countries'  
Chat model chunk: '": [\n    '  
Parser chunk: {'countries': []}  
Chat model chunk: '{\n      "'  
Parser chunk: {'countries': [{}]}  
Chat model chunk: 'name": "France'  
Parser chunk: {'countries': [{'name': 'France'}]}  
Chat model chunk: '",\n      "'  
Chat model chunk: 'population": 67'  
Parser chunk: {'countries': [{'name': 'France', 'population': 67}]}  
Chat model chunk: '413'  
Parser chunk: {'countries': [{'name': 'France', 'population': 67413}]}  
Chat model chunk: '000\n    },'  
Parser chunk: {'countries': [{'name': 'France', 'population': 67413000}]}  
Chat model chunk: '\n    {'  
Parser chunk: {'countries': [{'name': 'France', 'population': 67413000}, {}]}  
Chat model chunk: '\n      "name":'  
...  

```

Because both the model and the parser support streaming, we see streaming events from both components in real time! Kind of cool isn't it? 🦜

### Filtering Events[​](#filtering-events "Direct link to Filtering Events")

Because this API produces so many events, it is useful to be able to filter on events.

You can filter by either component `name`, component `tags` or component `type`.

#### By Name[​](#by-name "Direct link to By Name")

```
chain = model.with_config({"run_name": "model"}) | JsonOutputParser().with_config(  
    {"run_name": "my_parser"}  
)  
  
max_events = 0  
async for event in chain.astream_events(  
    "output a list of the countries france, spain and japan and their populations in JSON format. "  
    'Use a dict with an outer key of "countries" which contains a list of countries. '  
    "Each country should have the key `name` and `population`",  
    include_names=["my_parser"],  
):  
    print(event)  
    max_events += 1  
    if max_events > 10:  
        # Truncate output  
        print("...")  
        break  

```

```
{'event': 'on_parser_start', 'data': {'input': 'output a list of the countries france, spain and japan and their populations in JSON format. Use a dict with an outer key of "countries" which contains a list of countries. Each country should have the key `name` and `population`'}, 'name': 'my_parser', 'tags': ['seq:step:2'], 'run_id': '37ee9e85-481c-415e-863b-c9e132d24948', 'metadata': {}, 'parent_ids': ['5a0bc625-09fd-4bdf-9932-54909a9a8c29']}  
{'event': 'on_parser_stream', 'run_id': '37ee9e85-481c-415e-863b-c9e132d24948', 'name': 'my_parser', 'tags': ['seq:step:2'], 'metadata': {}, 'data': {'chunk': {}}, 'parent_ids': ['5a0bc625-09fd-4bdf-9932-54909a9a8c29']}  
{'event': 'on_parser_stream', 'run_id': '37ee9e85-481c-415e-863b-c9e132d24948', 'name': 'my_parser', 'tags': ['seq:step:2'], 'metadata': {}, 'data': {'chunk': {'countries': []}}, 'parent_ids': ['5a0bc625-09fd-4bdf-9932-54909a9a8c29']}  
{'event': 'on_parser_stream', 'run_id': '37ee9e85-481c-415e-863b-c9e132d24948', 'name': 'my_parser', 'tags': ['seq:step:2'], 'metadata': {}, 'data': {'chunk': {'countries': [{}]}}, 'parent_ids': ['5a0bc625-09fd-4bdf-9932-54909a9a8c29']}  
{'event': 'on_parser_stream', 'run_id': '37ee9e85-481c-415e-863b-c9e132d24948', 'name': 'my_parser', 'tags': ['seq:step:2'], 'metadata': {}, 'data': {'chunk': {'countries': [{'name': 'France'}]}}, 'parent_ids': ['5a0bc625-09fd-4bdf-9932-54909a9a8c29']}  
{'event': 'on_parser_stream', 'run_id': '37ee9e85-481c-415e-863b-c9e132d24948', 'name': 'my_parser', 'tags': ['seq:step:2'], 'metadata': {}, 'data': {'chunk': {'countries': [{'name': 'France', 'population': 67}]}}, 'parent_ids': ['5a0bc625-09fd-4bdf-9932-54909a9a8c29']}  
{'event': 'on_parser_stream', 'run_id': '37ee9e85-481c-415e-863b-c9e132d24948', 'name': 'my_parser', 'tags': ['seq:step:2'], 'metadata': {}, 'data': {'chunk': {'countries': [{'name': 'France', 'population': 67413}]}}, 'parent_ids': ['5a0bc625-09fd-4bdf-9932-54909a9a8c29']}  
{'event': 'on_parser_stream', 'run_id': '37ee9e85-481c-415e-863b-c9e132d24948', 'name': 'my_parser', 'tags': ['seq:step:2'], 'metadata': {}, 'data': {'chunk': {'countries': [{'name': 'France', 'population': 67413000}]}}, 'parent_ids': ['5a0bc625-09fd-4bdf-9932-54909a9a8c29']}  
{'event': 'on_parser_stream', 'run_id': '37ee9e85-481c-415e-863b-c9e132d24948', 'name': 'my_parser', 'tags': ['seq:step:2'], 'metadata': {}, 'data': {'chunk': {'countries': [{'name': 'France', 'population': 67413000}, {}]}}, 'parent_ids': ['5a0bc625-09fd-4bdf-9932-54909a9a8c29']}  
{'event': 'on_parser_stream', 'run_id': '37ee9e85-481c-415e-863b-c9e132d24948', 'name': 'my_parser', 'tags': ['seq:step:2'], 'metadata': {}, 'data': {'chunk': {'countries': [{'name': 'France', 'population': 67413000}, {'name': 'Spain'}]}}, 'parent_ids': ['5a0bc625-09fd-4bdf-9932-54909a9a8c29']}  
{'event': 'on_parser_stream', 'run_id': '37ee9e85-481c-415e-863b-c9e132d24948', 'name': 'my_parser', 'tags': ['seq:step:2'], 'metadata': {}, 'data': {'chunk': {'countries': [{'name': 'France', 'population': 67413000}, {'name': 'Spain', 'population': 47}]}}, 'parent_ids': ['5a0bc625-09fd-4bdf-9932-54909a9a8c29']}  
...  

```

#### By Type[​](#by-type "Direct link to By Type")

```
chain = model.with_config({"run_name": "model"}) | JsonOutputParser().with_config(  
    {"run_name": "my_parser"}  
)  
  
max_events = 0  
async for event in chain.astream_events(  
    'output a list of the countries france, spain and japan and their populations in JSON format. Use a dict with an outer key of "countries" which contains a list of countries. Each country should have the key `name` and `population`',  
    include_types=["chat_model"],  
):  
    print(event)  
    max_events += 1  
    if max_events > 10:  
        # Truncate output  
        print("...")  
        break  

```

```
{'event': 'on_chat_model_start', 'data': {'input': 'output a list of the countries france, spain and japan and their populations in JSON format. Use a dict with an outer key of "countries" which contains a list of countries. Each country should have the key `name` and `population`'}, 'name': 'model', 'tags': ['seq:step:1'], 'run_id': '156c3e40-82fb-49ff-8e41-9e998061be8c', 'metadata': {'ls_provider': 'anthropic', 'ls_model_name': 'claude-3-sonnet-20240229', 'ls_model_type': 'chat', 'ls_temperature': 0.0, 'ls_max_tokens': 1024}, 'parent_ids': ['7b927055-bc1b-4b50-a34c-10d3cfcb3899']}  
{'event': 'on_chat_model_stream', 'data': {'chunk': AIMessageChunk(content='', additional_kwargs={}, response_metadata={}, id='run-156c3e40-82fb-49ff-8e41-9e998061be8c', usage_metadata={'input_tokens': 56, 'output_tokens': 1, 'total_tokens': 57, 'input_token_details': {'cache_creation': 0, 'cache_read': 0}})}, 'run_id': '156c3e40-82fb-49ff-8e41-9e998061be8c', 'name': 'model', 'tags': ['seq:step:1'], 'metadata': {'ls_provider': 'anthropic', 'ls_model_name': 'claude-3-sonnet-20240229', 'ls_model_type': 'chat', 'ls_temperature': 0.0, 'ls_max_tokens': 1024}, 'parent_ids': ['7b927055-bc1b-4b50-a34c-10d3cfcb3899']}  
{'event': 'on_chat_model_stream', 'data': {'chunk': AIMessageChunk(content='{', additional_kwargs={}, response_metadata={}, id='run-156c3e40-82fb-49ff-8e41-9e998061be8c')}, 'run_id': '156c3e40-82fb-49ff-8e41-9e998061be8c', 'name': 'model', 'tags': ['seq:step:1'], 'metadata': {'ls_provider': 'anthropic', 'ls_model_name': 'claude-3-sonnet-20240229', 'ls_model_type': 'chat', 'ls_temperature': 0.0, 'ls_max_tokens': 1024}, 'parent_ids': ['7b927055-bc1b-4b50-a34c-10d3cfcb3899']}  
{'event': 'on_chat_model_stream', 'data': {'chunk': AIMessageChunk(content='\n  "countries', additional_kwargs={}, response_metadata={}, id='run-156c3e40-82fb-49ff-8e41-9e998061be8c')}, 'run_id': '156c3e40-82fb-49ff-8e41-9e998061be8c', 'name': 'model', 'tags': ['seq:step:1'], 'metadata': {'ls_provider': 'anthropic', 'ls_model_name': 'claude-3-sonnet-20240229', 'ls_model_type': 'chat', 'ls_temperature': 0.0, 'ls_max_tokens': 1024}, 'parent_ids': ['7b927055-bc1b-4b50-a34c-10d3cfcb3899']}  
{'event': 'on_chat_model_stream', 'data': {'chunk': AIMessageChunk(content='": [\n    ', additional_kwargs={}, response_metadata={}, id='run-156c3e40-82fb-49ff-8e41-9e998061be8c')}, 'run_id': '156c3e40-82fb-49ff-8e41-9e998061be8c', 'name': 'model', 'tags': ['seq:step:1'], 'metadata': {'ls_provider': 'anthropic', 'ls_model_name': 'claude-3-sonnet-20240229', 'ls_model_type': 'chat', 'ls_temperature': 0.0, 'ls_max_tokens': 1024}, 'parent_ids': ['7b927055-bc1b-4b50-a34c-10d3cfcb3899']}  
{'event': 'on_chat_model_stream', 'data': {'chunk': AIMessageChunk(content='{\n      "', additional_kwargs={}, response_metadata={}, id='run-156c3e40-82fb-49ff-8e41-9e998061be8c')}, 'run_id': '156c3e40-82fb-49ff-8e41-9e998061be8c', 'name': 'model', 'tags': ['seq:step:1'], 'metadata': {'ls_provider': 'anthropic', 'ls_model_name': 'claude-3-sonnet-20240229', 'ls_model_type': 'chat', 'ls_temperature': 0.0, 'ls_max_tokens': 1024}, 'parent_ids': ['7b927055-bc1b-4b50-a34c-10d3cfcb3899']}  
{'event': 'on_chat_model_stream', 'data': {'chunk': AIMessageChunk(content='name": "France', additional_kwargs={}, response_metadata={}, id='run-156c3e40-82fb-49ff-8e41-9e998061be8c')}, 'run_id': '156c3e40-82fb-49ff-8e41-9e998061be8c', 'name': 'model', 'tags': ['seq:step:1'], 'metadata': {'ls_provider': 'anthropic', 'ls_model_name': 'claude-3-sonnet-20240229', 'ls_model_type': 'chat', 'ls_temperature': 0.0, 'ls_max_tokens': 1024}, 'parent_ids': ['7b927055-bc1b-4b50-a34c-10d3cfcb3899']}  
{'event': 'on_chat_model_stream', 'data': {'chunk': AIMessageChunk(content='",\n      "', additional_kwargs={}, response_metadata={}, id='run-156c3e40-82fb-49ff-8e41-9e998061be8c')}, 'run_id': '156c3e40-82fb-49ff-8e41-9e998061be8c', 'name': 'model', 'tags': ['seq:step:1'], 'metadata': {'ls_provider': 'anthropic', 'ls_model_name': 'claude-3-sonnet-20240229', 'ls_model_type': 'chat', 'ls_temperature': 0.0, 'ls_max_tokens': 1024}, 'parent_ids': ['7b927055-bc1b-4b50-a34c-10d3cfcb3899']}  
{'event': 'on_chat_model_stream', 'data': {'chunk': AIMessageChunk(content='population": 67', additional_kwargs={}, response_metadata={}, id='run-156c3e40-82fb-49ff-8e41-9e998061be8c')}, 'run_id': '156c3e40-82fb-49ff-8e41-9e998061be8c', 'name': 'model', 'tags': ['seq:step:1'], 'metadata': {'ls_provider': 'anthropic', 'ls_model_name': 'claude-3-sonnet-20240229', 'ls_model_type': 'chat', 'ls_temperature': 0.0, 'ls_max_tokens': 1024}, 'parent_ids': ['7b927055-bc1b-4b50-a34c-10d3cfcb3899']}  
{'event': 'on_chat_model_stream', 'data': {'chunk': AIMessageChunk(content='413', additional_kwargs={}, response_metadata={}, id='run-156c3e40-82fb-49ff-8e41-9e998061be8c')}, 'run_id': '156c3e40-82fb-49ff-8e41-9e998061be8c', 'name': 'model', 'tags': ['seq:step:1'], 'metadata': {'ls_provider': 'anthropic', 'ls_model_name': 'claude-3-sonnet-20240229', 'ls_model_type': 'chat', 'ls_temperature': 0.0, 'ls_max_tokens': 1024}, 'parent_ids': ['7b927055-bc1b-4b50-a34c-10d3cfcb3899']}  
{'event': 'on_chat_model_stream', 'data': {'chunk': AIMessageChunk(content='000\n    },', additional_kwargs={}, response_metadata={}, id='run-156c3e40-82fb-49ff-8e41-9e998061be8c')}, 'run_id': '156c3e40-82fb-49ff-8e41-9e998061be8c', 'name': 'model', 'tags': ['seq:step:1'], 'metadata': {'ls_provider': 'anthropic', 'ls_model_name': 'claude-3-sonnet-20240229', 'ls_model_type': 'chat', 'ls_temperature': 0.0, 'ls_max_tokens': 1024}, 'parent_ids': ['7b927055-bc1b-4b50-a34c-10d3cfcb3899']}  
...  

```

#### By Tags[​](#by-tags "Direct link to By Tags")

caution

Tags are inherited by child components of a given runnable.

If you're using tags to filter, make sure that this is what you want.

```
chain = (model | JsonOutputParser()).with_config({"tags": ["my_chain"]})  
  
max_events = 0  
async for event in chain.astream_events(  
    'output a list of the countries france, spain and japan and their populations in JSON format. Use a dict with an outer key of "countries" which contains a list of countries. Each country should have the key `name` and `population`',  
    include_tags=["my_chain"],  
):  
    print(event)  
    max_events += 1  
    if max_events > 10:  
        # Truncate output  
        print("...")  
        break  

```

```
{'event': 'on_chain_start', 'data': {'input': 'output a list of the countries france, spain and japan and their populations in JSON format. Use a dict with an outer key of "countries" which contains a list of countries. Each country should have the key `name` and `population`'}, 'name': 'RunnableSequence', 'tags': ['my_chain'], 'run_id': '58d1302e-36ce-4df7-a3cb-47cb73d57e44', 'metadata': {}, 'parent_ids': []}  
{'event': 'on_chat_model_start', 'data': {'input': {'messages': [[HumanMessage(content='output a list of the countries france, spain and japan and their populations in JSON format. Use a dict with an outer key of "countries" which contains a list of countries. Each country should have the key `name` and `population`', additional_kwargs={}, response_metadata={})]]}}, 'name': 'ChatAnthropic', 'tags': ['seq:step:1', 'my_chain'], 'run_id': '8222e8a1-d978-4f30-87fc-b2dba838774b', 'metadata': {'ls_provider': 'anthropic', 'ls_model_name': 'claude-3-sonnet-20240229', 'ls_model_type': 'chat', 'ls_temperature': 0.0, 'ls_max_tokens': 1024}, 'parent_ids': ['58d1302e-36ce-4df7-a3cb-47cb73d57e44']}  
{'event': 'on_chat_model_stream', 'data': {'chunk': AIMessageChunk(content='', additional_kwargs={}, response_metadata={}, id='run-8222e8a1-d978-4f30-87fc-b2dba838774b', usage_metadata={'input_tokens': 56, 'output_tokens': 1, 'total_tokens': 57, 'input_token_details': {'cache_creation': 0, 'cache_read': 0}})}, 'run_id': '8222e8a1-d978-4f30-87fc-b2dba838774b', 'name': 'ChatAnthropic', 'tags': ['seq:step:1', 'my_chain'], 'metadata': {'ls_provider': 'anthropic', 'ls_model_name': 'claude-3-sonnet-20240229', 'ls_model_type': 'chat', 'ls_temperature': 0.0, 'ls_max_tokens': 1024}, 'parent_ids': ['58d1302e-36ce-4df7-a3cb-47cb73d57e44']}  
{'event': 'on_parser_start', 'data': {}, 'name': 'JsonOutputParser', 'tags': ['seq:step:2', 'my_chain'], 'run_id': '75604c84-e1e6-494a-8b2a-950f45d932e8', 'metadata': {}, 'parent_ids': ['58d1302e-36ce-4df7-a3cb-47cb73d57e44']}  
{'event': 'on_chat_model_stream', 'data': {'chunk': AIMessageChunk(content='{', additional_kwargs={}, response_metadata={}, id='run-8222e8a1-d978-4f30-87fc-b2dba838774b')}, 'run_id': '8222e8a1-d978-4f30-87fc-b2dba838774b', 'name': 'ChatAnthropic', 'tags': ['seq:step:1', 'my_chain'], 'metadata': {'ls_provider': 'anthropic', 'ls_model_name': 'claude-3-sonnet-20240229', 'ls_model_type': 'chat', 'ls_temperature': 0.0, 'ls_max_tokens': 1024}, 'parent_ids': ['58d1302e-36ce-4df7-a3cb-47cb73d57e44']}  
{'event': 'on_parser_stream', 'run_id': '75604c84-e1e6-494a-8b2a-950f45d932e8', 'name': 'JsonOutputParser', 'tags': ['seq:step:2', 'my_chain'], 'metadata': {}, 'data': {'chunk': {}}, 'parent_ids': ['58d1302e-36ce-4df7-a3cb-47cb73d57e44']}  
{'event': 'on_chain_stream', 'run_id': '58d1302e-36ce-4df7-a3cb-47cb73d57e44', 'name': 'RunnableSequence', 'tags': ['my_chain'], 'metadata': {}, 'data': {'chunk': {}}, 'parent_ids': []}  
{'event': 'on_chat_model_stream', 'data': {'chunk': AIMessageChunk(content='\n  "countries', additional_kwargs={}, response_metadata={}, id='run-8222e8a1-d978-4f30-87fc-b2dba838774b')}, 'run_id': '8222e8a1-d978-4f30-87fc-b2dba838774b', 'name': 'ChatAnthropic', 'tags': ['seq:step:1', 'my_chain'], 'metadata': {'ls_provider': 'anthropic', 'ls_model_name': 'claude-3-sonnet-20240229', 'ls_model_type': 'chat', 'ls_temperature': 0.0, 'ls_max_tokens': 1024}, 'parent_ids': ['58d1302e-36ce-4df7-a3cb-47cb73d57e44']}  
{'event': 'on_chat_model_stream', 'data': {'chunk': AIMessageChunk(content='": [\n    ', additional_kwargs={}, response_metadata={}, id='run-8222e8a1-d978-4f30-87fc-b2dba838774b')}, 'run_id': '8222e8a1-d978-4f30-87fc-b2dba838774b', 'name': 'ChatAnthropic', 'tags': ['seq:step:1', 'my_chain'], 'metadata': {'ls_provider': 'anthropic', 'ls_model_name': 'claude-3-sonnet-20240229', 'ls_model_type': 'chat', 'ls_temperature': 0.0, 'ls_max_tokens': 1024}, 'parent_ids': ['58d1302e-36ce-4df7-a3cb-47cb73d57e44']}  
{'event': 'on_parser_stream', 'run_id': '75604c84-e1e6-494a-8b2a-950f45d932e8', 'name': 'JsonOutputParser', 'tags': ['seq:step:2', 'my_chain'], 'metadata': {}, 'data': {'chunk': {'countries': []}}, 'parent_ids': ['58d1302e-36ce-4df7-a3cb-47cb73d57e44']}  
{'event': 'on_chain_stream', 'run_id': '58d1302e-36ce-4df7-a3cb-47cb73d57e44', 'name': 'RunnableSequence', 'tags': ['my_chain'], 'metadata': {}, 'data': {'chunk': {'countries': []}}, 'parent_ids': []}  
...  

```

### Non-streaming components[​](#non-streaming-components-1 "Direct link to Non-streaming components")

Remember how some components don't stream well because they don't operate on **input streams**?

While such components can break streaming of the final output when using `astream`, `astream_events` will still yield streaming events from intermediate steps that support streaming!

```
# Function that does not support streaming.  
# It operates on the finalizes inputs rather than  
# operating on the input stream.  
def _extract_country_names(inputs):  
    """A function that does not operates on input streams and breaks streaming."""  
    if not isinstance(inputs, dict):  
        return ""  
  
    if "countries" not in inputs:  
        return ""  
  
    countries = inputs["countries"]  
  
    if not isinstance(countries, list):  
        return ""  
  
    country_names = [  
        country.get("name") for country in countries if isinstance(country, dict)  
    ]  
    return country_names  
  
  
chain = (  
    model | JsonOutputParser() | _extract_country_names  
)  # This parser only works with OpenAI right now  

```

As expected, the `astream` API doesn't work correctly because `_extract_country_names` doesn't operate on streams.

```
async for chunk in chain.astream(  
    "output a list of the countries france, spain and japan and their populations in JSON format. "  
    'Use a dict with an outer key of "countries" which contains a list of countries. '  
    "Each country should have the key `name` and `population`",  
):  
    print(chunk, flush=True)  

```

```
['France', 'Spain', 'Japan']  

```

Now, let's confirm that with astream\_events we're still seeing streaming output from the model and the parser.

```
num_events = 0  
  
async for event in chain.astream_events(  
    "output a list of the countries france, spain and japan and their populations in JSON format. "  
    'Use a dict with an outer key of "countries" which contains a list of countries. '  
    "Each country should have the key `name` and `population`",  
):  
    kind = event["event"]  
    if kind == "on_chat_model_stream":  
        print(  
            f"Chat model chunk: {repr(event['data']['chunk'].content)}",  
            flush=True,  
        )  
    if kind == "on_parser_stream":  
        print(f"Parser chunk: {event['data']['chunk']}", flush=True)  
    num_events += 1  
    if num_events > 30:  
        # Truncate the output  
        print("...")  
        break  

```

```
Chat model chunk: ''  
Chat model chunk: '{'  
Parser chunk: {}  
Chat model chunk: '\n  "countries'  
Chat model chunk: '": [\n    '  
Parser chunk: {'countries': []}  
Chat model chunk: '{\n      "'  
Parser chunk: {'countries': [{}]}  
Chat model chunk: 'name": "France'  
Parser chunk: {'countries': [{'name': 'France'}]}  
Chat model chunk: '",\n      "'  
Chat model chunk: 'population": 67'  
Parser chunk: {'countries': [{'name': 'France', 'population': 67}]}  
Chat model chunk: '413'  
Parser chunk: {'countries': [{'name': 'France', 'population': 67413}]}  
Chat model chunk: '000\n    },'  
Parser chunk: {'countries': [{'name': 'France', 'population': 67413000}]}  
Chat model chunk: '\n    {'  
Parser chunk: {'countries': [{'name': 'France', 'population': 67413000}, {}]}  
Chat model chunk: '\n      "name":'  
Chat model chunk: ' "Spain",'  
Parser chunk: {'countries': [{'name': 'France', 'population': 67413000}, {'name': 'Spain'}]}  
Chat model chunk: '\n      "population":'  
Chat model chunk: ' 47'  
Parser chunk: {'countries': [{'name': 'France', 'population': 67413000}, {'name': 'Spain', 'population': 47}]}  
Chat model chunk: '351'  
Parser chunk: {'countries': [{'name': 'France', 'population': 67413000}, {'name': 'Spain', 'population': 47351}]}  
...  

```

### Propagating Callbacks[​](#propagating-callbacks "Direct link to Propagating Callbacks")

caution

If you're using invoking runnables inside your tools, you need to propagate callbacks to the runnable; otherwise, no stream events will be generated.

note

When using `RunnableLambdas` or `@chain` decorator, callbacks are propagated automatically behind the scenes.

```
from langchain_core.runnables import RunnableLambda  
from langchain_core.tools import tool  
  
  
def reverse_word(word: str):  
    return word[::-1]  
  
  
reverse_word = RunnableLambda(reverse_word)  
  
  
@tool  
def bad_tool(word: str):  
    """Custom tool that doesn't propagate callbacks."""  
    return reverse_word.invoke(word)  
  
  
async for event in bad_tool.astream_events("hello"):  
    print(event)  

```

**API Reference:**[RunnableLambda](https://python.langchain.com/api_reference/core/runnables/langchain_core.runnables.base.RunnableLambda.html) | [tool](https://python.langchain.com/api_reference/core/tools/langchain_core.tools.convert.tool.html)

```
{'event': 'on_tool_start', 'data': {'input': 'hello'}, 'name': 'bad_tool', 'tags': [], 'run_id': 'ea900472-a8f7-425d-b627-facdef936ee8', 'metadata': {}}  
{'event': 'on_chain_start', 'data': {'input': 'hello'}, 'name': 'reverse_word', 'tags': [], 'run_id': '77b01284-0515-48f4-8d7c-eb27c1882f86', 'metadata': {}}  
{'event': 'on_chain_end', 'data': {'output': 'olleh', 'input': 'hello'}, 'run_id': '77b01284-0515-48f4-8d7c-eb27c1882f86', 'name': 'reverse_word', 'tags': [], 'metadata': {}}  
{'event': 'on_tool_end', 'data': {'output': 'olleh'}, 'run_id': 'ea900472-a8f7-425d-b627-facdef936ee8', 'name': 'bad_tool', 'tags': [], 'metadata': {}}  

```

Here's a re-implementation that does propagate callbacks correctly. You'll notice that now we're getting events from the `reverse_word` runnable as well.

```
@tool  
def correct_tool(word: str, callbacks):  
    """A tool that correctly propagates callbacks."""  
    return reverse_word.invoke(word, {"callbacks": callbacks})  
  
  
async for event in correct_tool.astream_events("hello"):  
    print(event)  

```

```
{'event': 'on_tool_start', 'data': {'input': 'hello'}, 'name': 'correct_tool', 'tags': [], 'run_id': 'd5ea83b9-9278-49cc-9f1d-aa302d671040', 'metadata': {}}  
{'event': 'on_chain_start', 'data': {'input': 'hello'}, 'name': 'reverse_word', 'tags': [], 'run_id': '44dafbf4-2f87-412b-ae0e-9f71713810df', 'metadata': {}}  
{'event': 'on_chain_end', 'data': {'output': 'olleh', 'input': 'hello'}, 'run_id': '44dafbf4-2f87-412b-ae0e-9f71713810df', 'name': 'reverse_word', 'tags': [], 'metadata': {}}  
{'event': 'on_tool_end', 'data': {'output': 'olleh'}, 'run_id': 'd5ea83b9-9278-49cc-9f1d-aa302d671040', 'name': 'correct_tool', 'tags': [], 'metadata': {}}  

```

If you're invoking runnables from within Runnable Lambdas or `@chains`, then callbacks will be passed automatically on your behalf.

```
from langchain_core.runnables import RunnableLambda  
  
  
async def reverse_and_double(word: str):  
    return await reverse_word.ainvoke(word) * 2  
  
  
reverse_and_double = RunnableLambda(reverse_and_double)  
  
await reverse_and_double.ainvoke("1234")  
  
async for event in reverse_and_double.astream_events("1234"):  
    print(event)  

```

**API Reference:**[RunnableLambda](https://python.langchain.com/api_reference/core/runnables/langchain_core.runnables.base.RunnableLambda.html)

```
{'event': 'on_chain_start', 'data': {'input': '1234'}, 'name': 'reverse_and_double', 'tags': [], 'run_id': '03b0e6a1-3e60-42fc-8373-1e7829198d80', 'metadata': {}}  
{'event': 'on_chain_start', 'data': {'input': '1234'}, 'name': 'reverse_word', 'tags': [], 'run_id': '5cf26fc8-840b-4642-98ed-623dda28707a', 'metadata': {}}  
{'event': 'on_chain_end', 'data': {'output': '4321', 'input': '1234'}, 'run_id': '5cf26fc8-840b-4642-98ed-623dda28707a', 'name': 'reverse_word', 'tags': [], 'metadata': {}}  
{'event': 'on_chain_stream', 'data': {'chunk': '43214321'}, 'run_id': '03b0e6a1-3e60-42fc-8373-1e7829198d80', 'name': 'reverse_and_double', 'tags': [], 'metadata': {}}  
{'event': 'on_chain_end', 'data': {'output': '43214321'}, 'run_id': '03b0e6a1-3e60-42fc-8373-1e7829198d80', 'name': 'reverse_and_double', 'tags': [], 'metadata': {}}  

```

And with the `@chain` decorator:

```
from langchain_core.runnables import chain  
  
  
@chain  
async def reverse_and_double(word: str):  
    return await reverse_word.ainvoke(word) * 2  
  
  
await reverse_and_double.ainvoke("1234")  
  
async for event in reverse_and_double.astream_events("1234"):  
    print(event)  

```

**API Reference:**[chain](https://python.langchain.com/api_reference/core/runnables/langchain_core.runnables.base.chain.html)

```
{'event': 'on_chain_start', 'data': {'input': '1234'}, 'name': 'reverse_and_double', 'tags': [], 'run_id': '1bfcaedc-f4aa-4d8e-beee-9bba6ef17008', 'metadata': {}}  
{'event': 'on_chain_start', 'data': {'input': '1234'}, 'name': 'reverse_word', 'tags': [], 'run_id': '64fc99f0-5d7d-442b-b4f5-4537129f67d1', 'metadata': {}}  
{'event': 'on_chain_end', 'data': {'output': '4321', 'input': '1234'}, 'run_id': '64fc99f0-5d7d-442b-b4f5-4537129f67d1', 'name': 'reverse_word', 'tags': [], 'metadata': {}}  
{'event': 'on_chain_stream', 'data': {'chunk': '43214321'}, 'run_id': '1bfcaedc-f4aa-4d8e-beee-9bba6ef17008', 'name': 'reverse_and_double', 'tags': [], 'metadata': {}}  
{'event': 'on_chain_end', 'data': {'output': '43214321'}, 'run_id': '1bfcaedc-f4aa-4d8e-beee-9bba6ef17008', 'name': 'reverse_and_double', 'tags': [], 'metadata': {}}  

```

## Next steps[​](#next-steps "Direct link to Next steps")

Now you've learned some ways to stream both final outputs and internal steps with LangChain.

To learn more, check out the other how-to guides in this section, or the [conceptual guide on Langchain Expression Language](/docs/concepts/lcel/).

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/how_to/streaming.ipynb)