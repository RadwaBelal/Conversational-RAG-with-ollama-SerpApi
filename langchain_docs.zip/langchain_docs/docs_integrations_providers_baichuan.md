# Source: https://python.langchain.com/docs/integrations/providers/baichuan/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Baichuan

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/baichuan.mdx)

# Baichuan

> [Baichuan Inc.](https://www.baichuan-ai.com/) is a Chinese startup in the era of AGI,
> dedicated to addressing fundamental human needs: Efficiency, Health, and Happiness.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

Register and get an API key [here](https://platform.baichuan-ai.com/).

## LLMs[​](#llms "Direct link to LLMs")

See a [usage example](/docs/integrations/llms/baichuan/).

```
from langchain_community.llms import BaichuanLLM  

```

**API Reference:**[BaichuanLLM](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.baichuan.BaichuanLLM.html)

## Chat models[​](#chat-models "Direct link to Chat models")

See a [usage example](/docs/integrations/chat/baichuan/).

```
from langchain_community.chat_models import ChatBaichuan  

```

**API Reference:**[ChatBaichuan](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.baichuan.ChatBaichuan.html)

## Embedding models[​](#embedding-models "Direct link to Embedding models")

See a [usage example](/docs/integrations/text_embedding/baichuan/).

```
from langchain_community.embeddings import BaichuanTextEmbeddings  

```

**API Reference:**[BaichuanTextEmbeddings](https://python.langchain.com/api_reference/community/embeddings/langchain_community.embeddings.baichuan.BaichuanTextEmbeddings.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/baichuan.mdx)