# Source: https://python.langchain.com/docs/integrations/chat/naver/

* [Components](/docs/integrations/components/)
* [Chat models](/docs/integrations/chat/)
* Naver

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/naver.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/naver.ipynb)

# ChatClovaX

This notebook provides a quick overview for getting started with Naver’s HyperCLOVA X [chat models](https://python.langchain.com/docs/concepts/chat_models) via CLOVA Studio. For detailed documentation of all ChatClovaX features and configurations head to the [API reference](https://guide.ncloud-docs.com/docs/clovastudio-dev-langchain).

[CLOVA Studio](http://clovastudio.ncloud.com/) has several chat models. You can find information about latest models and their costs, context windows, and supported input types in the CLOVA Studio Guide [documentation](https://guide.ncloud-docs.com/docs/clovastudio-model).

## Overview[​](#overview "Direct link to Overview")

### Integration details[​](#integration-details "Direct link to Integration details")

| Class | Package | Local | Serializable | JS support | Package downloads | Package latest |
| --- | --- | --- | --- | --- | --- | --- |
| [ChatClovaX](https://guide.ncloud-docs.com/docs/clovastudio-dev-langchain#HyperCLOVAX%EB%AA%A8%EB%8D%B8%EC%9D%B4%EC%9A%A9) | [langchain-naver](https://pypi.org/project/langchain-naver/) | ❌ | ❌ | ❌ | PyPI - Downloads | PyPI - Version |

### Model features[​](#model-features "Direct link to Model features")

| [Tool calling](/docs/how_to/tool_calling/) | [Structured output](/docs/how_to/structured_output/) | JSON mode | [Image input](/docs/how_to/multimodal_inputs/) | Audio input | Video input | [Token-level streaming](/docs/how_to/chat_streaming/) | Native async | [Token usage](/docs/how_to/chat_token_usage_tracking/) | [Logprobs](/docs/how_to/logprobs/) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ✅ | ❌ | ❌ | ✅ | ❌ | ❌ | ✅ | ✅ | ✅ | ❌ |

## Setup[​](#setup "Direct link to Setup")

Before using the chat model, you must go through the four steps below.

1. Creating [NAVER Cloud Platform](https://www.ncloud.com/) account
2. Apply to use [CLOVA Studio](https://www.ncloud.com/product/aiService/clovaStudio)
3. Create a CLOVA Studio Test App or Service App of a model to use (See [here](https://guide.ncloud-docs.com/docs/clovastudio-playground-testapp).)
4. Issue a Test or Service API key (See [here](https://api.ncloud-docs.com/docs/ai-naver-clovastudio-summary#API%ED%82%A4).)

### Credentials[​](#credentials "Direct link to Credentials")

Set the `CLOVASTUDIO_API_KEY` environment variable with your API key.

You can add them to your environment variables as below:

```
export CLOVASTUDIO_API_KEY="your-api-key-here"  

```

```
import getpass  
import os  
  
if not os.getenv("CLOVASTUDIO_API_KEY"):  
    os.environ["CLOVASTUDIO_API_KEY"] = getpass.getpass(  
        "Enter your CLOVA Studio API Key: "  
    )  

```

To enable automated tracing of your model calls, set your [LangSmith](https://docs.smith.langchain.com/) API key:

```
# os.environ["LANGSMITH_TRACING"] = "true"  
# os.environ["LANGSMITH_API_KEY"] = getpass.getpass("Enter your LangSmith API key: ")  

```

### Installation[​](#installation "Direct link to Installation")

The LangChain Naver integration lives in the `langchain-naver` package:

```
# install package  
%pip install -qU langchain-naver  

```

## Instantiation[​](#instantiation "Direct link to Instantiation")

Now we can instantiate our model object and generate chat completions:

```
from langchain_naver import ChatClovaX  
  
chat = ChatClovaX(  
    model="HCX-005",  
    temperature=0.5,  
    max_tokens=None,  
    timeout=None,  
    max_retries=2,  
    # other params...  
)  

```

## Invocation[​](#invocation "Direct link to Invocation")

In addition to invoke, `ChatClovaX` also support batch and stream functionalities.

```
messages = [  
    (  
        "system",  
        "You are a helpful assistant that translates English to Korean. Translate the user sentence.",  
    ),  
    ("human", "I love using NAVER AI."),  
]  
  
ai_msg = chat.invoke(messages)  
ai_msg  

```

```
AIMessage(content='네이버 인공지능을 사용하는 것을 정말 좋아합니다.', additional_kwargs={'refusal': None}, response_metadata={'token_usage': {'completion_tokens': 11, 'prompt_tokens': 28, 'total_tokens': 39, 'completion_tokens_details': None, 'prompt_tokens_details': None}, 'model_name': 'HCX-005', 'system_fingerprint': None, 'id': 'b70c26671cd247a0864115bacfb5fc12', 'finish_reason': 'stop', 'logprobs': None}, id='run-3faf6a8d-d5da-49ad-9fbb-7b56ed23b484-0', usage_metadata={'input_tokens': 28, 'output_tokens': 11, 'total_tokens': 39, 'input_token_details': {}, 'output_token_details': {}})  

```

```
print(ai_msg.content)  

```

```
네이버 인공지능을 사용하는 것을 정말 좋아합니다.  

```

## Chaining[​](#chaining "Direct link to Chaining")

We can [chain](/docs/how_to/sequence/) our model with a prompt template like so:

```
from langchain_core.prompts import ChatPromptTemplate  
  
prompt = ChatPromptTemplate.from_messages(  
    [  
        (  
            "system",  
            "You are a helpful assistant that translates {input_language} to {output_language}. Translate the user sentence.",  
        ),  
        ("human", "{input}"),  
    ]  
)  
  
chain = prompt | chat  
chain.invoke(  
    {  
        "input_language": "English",  
        "output_language": "Korean",  
        "input": "I love using NAVER AI.",  
    }  
)  

```

**API Reference:**[ChatPromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.chat.ChatPromptTemplate.html)

```
AIMessage(content='저는 네이버 인공지능을 사용하는 것을 좋아합니다.', additional_kwargs={'refusal': None}, response_metadata={'token_usage': {'completion_tokens': 10, 'prompt_tokens': 28, 'total_tokens': 38, 'completion_tokens_details': None, 'prompt_tokens_details': None}, 'model_name': 'HCX-005', 'system_fingerprint': None, 'id': 'b7a826d17fcf4fee8386fca2ebc63284', 'finish_reason': 'stop', 'logprobs': None}, id='run-35957816-3325-4d9c-9441-e40704912be6-0', usage_metadata={'input_tokens': 28, 'output_tokens': 10, 'total_tokens': 38, 'input_token_details': {}, 'output_token_details': {}})  

```

## Streaming[​](#streaming "Direct link to Streaming")

```
system = "You are a helpful assistant that can teach Korean pronunciation."  
human = "Could you let me know how to say '{phrase}' in Korean?"  
prompt = ChatPromptTemplate.from_messages([("system", system), ("human", human)])  
  
chain = prompt | chat  
  
for chunk in chain.stream({"phrase": "Hi"}):  
    print(chunk.content, end="", flush=True)  

```

```
In Korean, the informal way of saying 'hi' is "안녕" (annyeong). If you're addressing someone older or showing more respect, you would use "안녕하세요" (annjeonghaseyo). Both phrases are used as greetings similar to 'hello'. Remember, pronunciation is key so make sure to pronounce each syllable clearly: 안-녀-엉 (an-nyeo-eong) and 안-녕-하-세-요 (an-nyeong-ha-se-yo).  

```

## Additional functionalities[​](#additional-functionalities "Direct link to Additional functionalities")

### Using fine-tuned models[​](#using-fine-tuned-models "Direct link to Using fine-tuned models")

You can call fine-tuned models by passing the `task_id` to the `model` parameter as: `ft:{task_id}`.

You can check `task_id` from corresponding Test App or Service App details.

```
fine_tuned_model = ChatClovaX(  
    model="ft:a1b2c3d4",  # set as `ft:{task_id}` with your fine-tuned model's task id  
    # other params...  
)  
  
fine_tuned_model.invoke(messages)  

```

```
AIMessage(content='네이버 인공지능을 사용하는 것을 정말 좋아합니다.', additional_kwargs={'refusal': None}, response_metadata={'token_usage': {'completion_tokens': 11, 'prompt_tokens': 28, 'total_tokens': 39, 'completion_tokens_details': None, 'prompt_tokens_details': None}, 'model_name': 'HCX-005', 'system_fingerprint': None, 'id': '2222d6d411a948c883aac1e03ca6cebe', 'finish_reason': 'stop', 'logprobs': None}, id='run-9696d7e2-7afa-4bb4-9c03-b95fcf678ab8-0', usage_metadata={'input_tokens': 28, 'output_tokens': 11, 'total_tokens': 39, 'input_token_details': {}, 'output_token_details': {}})  

```

## API reference[​](#api-reference "Direct link to API reference")

For detailed documentation of all ChatClovaX features and configurations head to the [API reference](https://guide.ncloud-docs.com/docs/clovastudio-dev-langchain)

## Related[​](#related "Direct link to Related")

* Chat model [conceptual guide](/docs/concepts/chat_models/)
* Chat model [how-to guides](/docs/how_to/#chat-models)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/chat/naver.ipynb)