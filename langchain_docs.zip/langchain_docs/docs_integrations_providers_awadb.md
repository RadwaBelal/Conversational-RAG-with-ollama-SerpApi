# Source: https://python.langchain.com/docs/integrations/providers/awadb/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* AwaDB

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/awadb.md)

# AwaDB

> [AwaDB](https://github.com/awa-ai/awadb) is an AI Native database for the search and storage of embedding vectors used by LLM Applications.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

```
pip install awadb  

```

## Vector store[​](#vector-store "Direct link to Vector store")

```
from langchain_community.vectorstores import AwaDB  

```

**API Reference:**[AwaDB](https://python.langchain.com/api_reference/community/vectorstores/langchain_community.vectorstores.awadb.AwaDB.html)

See a [usage example](/docs/integrations/vectorstores/awadb/).

## Embedding models[​](#embedding-models "Direct link to Embedding models")

```
from langchain_community.embeddings import AwaEmbeddings  

```

**API Reference:**[AwaEmbeddings](https://python.langchain.com/api_reference/community/embeddings/langchain_community.embeddings.awa.AwaEmbeddings.html)

See a [usage example](/docs/integrations/text_embedding/awadb/).

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/awadb.md)