# Source: https://python.langchain.com/docs/integrations/providers/fireworks/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Fireworks AI

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/fireworks.md)

# Fireworks AI

> [Fireworks AI](https://fireworks.ai) is a generative AI inference platform to run and
> customize models with industry-leading speed and production-readiness.

## Installation and setup[​](#installation-and-setup "Direct link to Installation and setup")

* Install the Fireworks integration package.

  ```
  pip install langchain-fireworks  

  ```
* Get a Fireworks API key by signing up at [fireworks.ai](https://fireworks.ai).
* Authenticate by setting the FIREWORKS\_API\_KEY environment variable.

### Authentication[​](#authentication "Direct link to Authentication")

There are two ways to authenticate using your Fireworks API key:

1. Setting the `FIREWORKS_API_KEY` environment variable.

   ```
   os.environ["FIREWORKS_API_KEY"] = "<KEY>"  

   ```
2. Setting `api_key` field in the Fireworks LLM module.

   ```
   llm = Fireworks(api_key="<KEY>")  

   ```

## Chat models[​](#chat-models "Direct link to Chat models")

See a [usage example](/docs/integrations/chat/fireworks/).

```
from langchain_fireworks import ChatFireworks  

```

**API Reference:**[ChatFireworks](https://python.langchain.com/api_reference/fireworks/chat_models/langchain_fireworks.chat_models.ChatFireworks.html)

## LLMs[​](#llms "Direct link to LLMs")

See a [usage example](/docs/integrations/llms/fireworks/).

```
from langchain_fireworks import Fireworks   

```

**API Reference:**[Fireworks](https://python.langchain.com/api_reference/fireworks/llms/langchain_fireworks.llms.Fireworks.html)

## Embedding models[​](#embedding-models "Direct link to Embedding models")

See a [usage example](/docs/integrations/text_embedding/fireworks/).

```
from langchain_fireworks import FireworksEmbeddings   

```

**API Reference:**[FireworksEmbeddings](https://python.langchain.com/api_reference/fireworks/embeddings/langchain_fireworks.embeddings.FireworksEmbeddings.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/fireworks.md)