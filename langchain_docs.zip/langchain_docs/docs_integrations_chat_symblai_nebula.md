# Source: https://python.langchain.com/docs/integrations/chat/symblai_nebula/

* [Components](/docs/integrations/components/)
* [Chat models](/docs/integrations/chat/)
* Nebula (Symbl.ai)

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/symblai_nebula.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/symblai_nebula.ipynb)

# Nebula (Symbl.ai)

## Overview[​](#overview "Direct link to Overview")

This notebook covers how to get started with [Nebula](https://docs.symbl.ai/docs/nebula-llm) - Symbl.ai's chat model.

### Integration details[​](#integration-details "Direct link to Integration details")

Head to the [API reference](https://docs.symbl.ai/reference/nebula-chat) for detailed documentation.

### Model features: TODO[​](#model-features-todo "Direct link to Model features: TODO")

## Setup[​](#setup "Direct link to Setup")

### Credentials[​](#credentials "Direct link to Credentials")

To get started, request a [Nebula API key](https://platform.symbl.ai/#/login) and set the `NEBULA_API_KEY` environment variable:

```
import getpass  
import os  
  
os.environ["NEBULA_API_KEY"] = getpass.getpass()  

```

### Installation[​](#installation "Direct link to Installation")

The integration is set up in the `langchain-community` package.

## Instantiation[​](#instantiation "Direct link to Instantiation")

```
from langchain_community.chat_models.symblai_nebula import ChatNebula  
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage  

```

**API Reference:**[ChatNebula](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.symblai_nebula.ChatNebula.html) | [AIMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.ai.AIMessage.html) | [HumanMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.human.HumanMessage.html) | [SystemMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.system.SystemMessage.html)

```
chat = ChatNebula(max_tokens=1024, temperature=0.5)  

```

## Invocation[​](#invocation "Direct link to Invocation")

```
messages = [  
    SystemMessage(  
        content="You are a helpful assistant that answers general knowledge questions."  
    ),  
    HumanMessage(content="What is the capital of France?"),  
]  
chat.invoke(messages)  

```

```
AIMessage(content=[{'role': 'human', 'text': 'What is the capital of France?'}, {'role': 'assistant', 'text': 'The capital of France is Paris.'}])  

```

### Async[​](#async "Direct link to Async")

```
await chat.ainvoke(messages)  

```

```
AIMessage(content=[{'role': 'human', 'text': 'What is the capital of France?'}, {'role': 'assistant', 'text': 'The capital of France is Paris.'}])  

```

### Streaming[​](#streaming "Direct link to Streaming")

```
for chunk in chat.stream(messages):  
    print(chunk.content, end="", flush=True)  

```

```
 The capital of France is Paris.  

```

### Batch[​](#batch "Direct link to Batch")

```
chat.batch([messages])  

```

```
[AIMessage(content=[{'role': 'human', 'text': 'What is the capital of France?'}, {'role': 'assistant', 'text': 'The capital of France is Paris.'}])]  

```

## Chaining[​](#chaining "Direct link to Chaining")

```
from langchain_core.prompts import ChatPromptTemplate  
  
prompt = ChatPromptTemplate.from_template("Tell me a joke about {topic}")  
chain = prompt | chat  

```

**API Reference:**[ChatPromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.chat.ChatPromptTemplate.html)

```
chain.invoke({"topic": "cows"})  

```

```
AIMessage(content=[{'role': 'human', 'text': 'Tell me a joke about cows'}, {'role': 'assistant', 'text': "Sure, here's a joke about cows:\n\nWhy did the cow cross the road?\n\nTo get to the udder side!"}])  

```

## API reference[​](#api-reference "Direct link to API reference")

Check out the [API reference](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.symblai_nebula.ChatNebula.html) for more detail.

## Related[​](#related "Direct link to Related")

* Chat model [conceptual guide](/docs/concepts/chat_models/)
* Chat model [how-to guides](/docs/how_to/#chat-models)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/chat/symblai_nebula.ipynb)