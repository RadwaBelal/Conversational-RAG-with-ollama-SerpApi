# Source: https://python.langchain.com/docs/integrations/providers/elasticsearch/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Elasticsearch

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/elasticsearch.mdx)

# Elasticsearch

> [Elasticsearch](https://www.elastic.co/elasticsearch/) is a distributed, RESTful search and analytics engine.
> It provides a distributed, multi-tenant-capable full-text search engine with an HTTP web interface and schema-free
> JSON documents.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

### Setup Elasticsearch[​](#setup-elasticsearch "Direct link to Setup Elasticsearch")

There are two ways to get started with Elasticsearch:

#### Install Elasticsearch on your local machine via Docker[​](#install-elasticsearch-on-your-local-machine-via-docker "Direct link to Install Elasticsearch on your local machine via Docker")

Example: Run a single-node Elasticsearch instance with security disabled.
This is not recommended for production use.

```
    docker run -p 9200:9200 -e "discovery.type=single-node" -e "xpack.security.enabled=false" -e "xpack.security.http.ssl.enabled=false" docker.elastic.co/elasticsearch/elasticsearch:8.9.0  

```

#### Deploy Elasticsearch on Elastic Cloud[​](#deploy-elasticsearch-on-elastic-cloud "Direct link to Deploy Elasticsearch on Elastic Cloud")

`Elastic Cloud` is a managed Elasticsearch service. Signup for a [free trial](https://cloud.elastic.co/registration?utm_source=langchain&utm_content=documentation).

### Install Client[​](#install-client "Direct link to Install Client")

```
pip install elasticsearch  
pip install langchain-elasticsearch  

```

## Embedding models[​](#embedding-models "Direct link to Embedding models")

See a [usage example](/docs/integrations/text_embedding/elasticsearch/).

```
from langchain_elasticsearch import ElasticsearchEmbeddings  

```

**API Reference:**[ElasticsearchEmbeddings](https://python.langchain.com/api_reference/elasticsearch/embeddings/langchain_elasticsearch.embeddings.ElasticsearchEmbeddings.html)

## Vector store[​](#vector-store "Direct link to Vector store")

See a [usage example](/docs/integrations/vectorstores/elasticsearch/).

```
from langchain_elasticsearch import ElasticsearchStore  

```

**API Reference:**[ElasticsearchStore](https://python.langchain.com/api_reference/elasticsearch/vectorstores/langchain_elasticsearch.vectorstores.ElasticsearchStore.html)

### Third-party integrations[​](#third-party-integrations "Direct link to Third-party integrations")

#### EcloudESVectorStore[​](#ecloudesvectorstore "Direct link to EcloudESVectorStore")

```
from langchain_community.vectorstores.ecloud_vector_search import EcloudESVectorStore  

```

**API Reference:**[EcloudESVectorStore](https://python.langchain.com/api_reference/community/vectorstores/langchain_community.vectorstores.ecloud_vector_search.EcloudESVectorStore.html)

## Retrievers[​](#retrievers "Direct link to Retrievers")

### ElasticsearchRetriever[​](#elasticsearchretriever "Direct link to ElasticsearchRetriever")

The `ElasticsearchRetriever` enables flexible access to all Elasticsearch features
through the Query DSL.

See a [usage example](/docs/integrations/retrievers/elasticsearch_retriever/).

```
from langchain_elasticsearch import ElasticsearchRetriever  

```

**API Reference:**[ElasticsearchRetriever](https://python.langchain.com/api_reference/elasticsearch/retrievers/langchain_elasticsearch.retrievers.ElasticsearchRetriever.html)

### BM25[​](#bm25 "Direct link to BM25")

See a [usage example](/docs/integrations/retrievers/elastic_search_bm25/).

```
from langchain_community.retrievers import ElasticSearchBM25Retriever  

```

**API Reference:**[ElasticSearchBM25Retriever](https://python.langchain.com/api_reference/community/retrievers/langchain_community.retrievers.elastic_search_bm25.ElasticSearchBM25Retriever.html)

## Memory[​](#memory "Direct link to Memory")

See a [usage example](/docs/integrations/memory/elasticsearch_chat_message_history/).

```
from langchain_elasticsearch import ElasticsearchChatMessageHistory  

```

**API Reference:**[ElasticsearchChatMessageHistory](https://python.langchain.com/api_reference/elasticsearch/chat_history/langchain_elasticsearch.chat_history.ElasticsearchChatMessageHistory.html)

## LLM cache[​](#llm-cache "Direct link to LLM cache")

See a [usage example](/docs/integrations/llm_caching/#elasticsearch-caches).

```
from langchain_elasticsearch import ElasticsearchCache  

```

**API Reference:**[ElasticsearchCache](https://python.langchain.com/api_reference/elasticsearch/cache/langchain_elasticsearch.cache.ElasticsearchCache.html)

## Byte Store[​](#byte-store "Direct link to Byte Store")

See a [usage example](/docs/integrations/stores/elasticsearch/).

```
from langchain_elasticsearch import ElasticsearchEmbeddingsCache  

```

**API Reference:**[ElasticsearchEmbeddingsCache](https://python.langchain.com/api_reference/elasticsearch/cache/langchain_elasticsearch.cache.ElasticsearchEmbeddingsCache.html)

## Chain[​](#chain "Direct link to Chain")

It is a chain for interacting with Elasticsearch Database.

```
from langchain.chains.elasticsearch_database import ElasticsearchDatabaseChain  

```

**API Reference:**[ElasticsearchDatabaseChain](https://python.langchain.com/api_reference/langchain/chains/langchain.chains.elasticsearch_database.base.ElasticsearchDatabaseChain.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/elasticsearch.mdx)