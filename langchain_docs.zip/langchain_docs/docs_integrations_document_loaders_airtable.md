# Source: https://python.langchain.com/docs/integrations/document_loaders/airtable/

* [Components](/docs/integrations/components/)
* [Document loaders](/docs/integrations/document_loaders/)
* Airtable

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/airtable.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/airtable.ipynb)

# Airtable

```
%pip install --upgrade --quiet  pyairtable  

```

```
from langchain_community.document_loaders import AirtableLoader  

```

**API Reference:**[AirtableLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.airtable.AirtableLoader.html)

* Get your API key [here](https://support.airtable.com/docs/creating-and-using-api-keys-and-access-tokens).
* Get ID of your base [here](https://airtable.com/developers/web/api/introduction).
* Get your table ID from the table url as shown [here](https://www.highviewapps.com/kb/where-can-i-find-the-airtable-base-id-and-table-id/#:~:text=Both%20the%20Airtable%20Base%20ID,URL%20that%20begins%20with%20tbl).

```
api_key = "xxx"  
base_id = "xxx"  
table_id = "xxx"  
view = "xxx"  # optional  

```

```
loader = AirtableLoader(api_key, table_id, base_id, view=view)  
docs = loader.load()  

```

Returns each table row as `dict`.

```
len(docs)  

```

```
3  

```

```
eval(docs[0].page_content)  

```

```
{'id': 'recF3GbGZCuh9sXIQ',  
 'createdTime': '2023-06-09T04:47:21.000Z',  
 'fields': {'Priority': 'High',  
  'Status': 'In progress',  
  'Name': 'Document Splitters'}}  

```

## Related[​](#related "Direct link to Related")

* Document loader [conceptual guide](/docs/concepts/document_loaders/)
* Document loader [how-to guides](/docs/how_to/#document-loaders)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/airtable.ipynb)