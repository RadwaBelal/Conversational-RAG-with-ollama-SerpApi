# Source: https://python.langchain.com/docs/integrations/providers/bageldb/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* BagelDB

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/bageldb.mdx)

# BagelDB

> [BagelDB](https://www.bageldb.ai/) (`Open Vector Database for AI`), is like GitHub for AI data.
> It is a collaborative platform where users can create,
> share, and manage vector datasets. It can support private projects for independent developers,
> internal collaborations for enterprises, and public contributions for data DAOs.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

```
pip install betabageldb  

```

## VectorStore[​](#vectorstore "Direct link to VectorStore")

See a [usage example](/docs/integrations/vectorstores/bageldb/).

```
from langchain_community.vectorstores import Bagel  

```

**API Reference:**[Bagel](https://python.langchain.com/api_reference/community/vectorstores/langchain_community.vectorstores.bagel.Bagel.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/bageldb.mdx)