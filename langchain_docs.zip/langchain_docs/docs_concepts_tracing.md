# Source: https://python.langchain.com/docs/concepts/tracing/

* [Conceptual guide](/docs/concepts/)
* Tracing

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/concepts/tracing.mdx)

# Tracing



A trace is essentially a series of steps that your application takes to go from input to output.
Traces contain individual steps called `runs`. These can be individual calls from a model, retriever,
tool, or sub-chains.
Tracing gives you observability inside your chains and agents, and is vital in diagnosing issues.

For a deeper dive, check out [this LangSmith conceptual guide](https://docs.smith.langchain.com/concepts/tracing).

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/concepts/tracing.mdx)