# Source: https://python.langchain.com/docs/integrations/document_loaders/imsdb/

* [Components](/docs/integrations/components/)
* [Document loaders](/docs/integrations/document_loaders/)
* IMSDb

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/imsdb.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/imsdb.ipynb)

# IMSDb

> [IMSDb](https://imsdb.com/) is the `Internet Movie Script Database`.

This covers how to load `IMSDb` webpages into a document format that we can use downstream.

```
from langchain_community.document_loaders import IMSDbLoader  

```

**API Reference:**[IMSDbLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.imsdb.IMSDbLoader.html)

```
loader = IMSDbLoader("https://imsdb.com/scripts/BlacKkKlansman.html")  

```

```
data = loader.load()  

```

```
data[0].page_content[:500]  

```

```
'\n\r\n\r\n\r\n\r\n                                    BLACKKKLANSMAN\r\n                         \r\n                         \r\n                         \r\n                         \r\n                                      Written by\r\n\r\n                          Charlie Wachtel & David Rabinowitz\r\n\r\n                                         and\r\n\r\n                              Kevin Willmott & Spike Lee\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n                         FADE IN:\r\n                         \r\n          SCENE FROM "GONE WITH'  

```

```
data[0].metadata  

```

```
{'source': 'https://imsdb.com/scripts/BlacKkKlansman.html'}  

```

## Related[​](#related "Direct link to Related")

* Document loader [conceptual guide](/docs/concepts/document_loaders/)
* Document loader [how-to guides](/docs/how_to/#document-loaders)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/imsdb.ipynb)