# Source: https://python.langchain.com/docs/integrations/providers/airbyte/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Airbyte

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/airbyte.mdx)

# Airbyte

> [Airbyte](https://github.com/airbytehq/airbyte) is a data integration platform for ELT pipelines from APIs,
> databases & files to warehouses & lakes. It has the largest catalog of ELT connectors to data warehouses and databases.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

```
pip install -U langchain-airbyte  

```

note

Currently, the `langchain-airbyte` library does not support Pydantic v2.
Please downgrade to Pydantic v1 to use this package.

This package also currently requires Python 3.10+.

The integration package doesn't require any global environment variables that need to be
set, but some integrations (e.g. `source-github`) may need credentials passed in.

## Document loader[​](#document-loader "Direct link to Document loader")

### AirbyteLoader[​](#airbyteloader "Direct link to AirbyteLoader")

See a [usage example](/docs/integrations/document_loaders/airbyte/).

```
from langchain_airbyte import AirbyteLoader  

```

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/airbyte.mdx)