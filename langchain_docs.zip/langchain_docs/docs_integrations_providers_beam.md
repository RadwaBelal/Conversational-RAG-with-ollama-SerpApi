# Source: https://python.langchain.com/docs/integrations/providers/beam/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Beam

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/beam.mdx)

# Beam

> [Beam](https://www.beam.cloud/) is a cloud computing platform that allows you to run your code
> on remote servers with GPUs.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

* [Create an account](https://www.beam.cloud/)
* Install the Beam CLI with `curl https://raw.githubusercontent.com/slai-labs/get-beam/main/get-beam.sh -sSfL | sh`
* Register API keys with `beam configure`
* Set environment variables (`BEAM_CLIENT_ID`) and (`BEAM_CLIENT_SECRET`)
* Install the Beam SDK:

```
pip install beam-sdk  

```

## LLMs[​](#llms "Direct link to LLMs")

See a [usage example](/docs/integrations/llms/beam/).

See another example in the [Beam documentation](https://docs.beam.cloud/examples/langchain).

```
from langchain_community.llms.beam import Beam  

```

**API Reference:**[Beam](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.beam.Beam.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/beam.mdx)