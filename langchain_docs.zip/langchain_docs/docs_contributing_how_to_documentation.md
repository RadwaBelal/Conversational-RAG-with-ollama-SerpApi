# Source: https://python.langchain.com/docs/contributing/how_to/documentation/

* [How-to guides](/docs/contributing/how_to/)
* Contribute Documentation

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/contributing/how_to/documentation/index.mdx)

# Contribute Documentation

Documentation is a vital part of LangChain. We welcome both new documentation for new features and
community improvements to our current documentation. Please read the resources below before getting started:

* [Documentation style guide](/docs/contributing/how_to/documentation/style_guide/)
* [Setup](/docs/contributing/how_to/documentation/setup/)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/contributing/how_to/documentation/index.mdx)