# Source: https://python.langchain.com/docs/integrations/chat/vllm/

* [Components](/docs/integrations/components/)
* [Chat models](/docs/integrations/chat/)
* vLLM Chat

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/vllm.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/vllm.ipynb)

# vLLM Chat

vLLM can be deployed as a server that mimics the OpenAI API protocol. This allows vLLM to be used as a drop-in replacement for applications using OpenAI API. This server can be queried in the same format as OpenAI API.

## Overview[​](#overview "Direct link to Overview")

This will help you getting started with vLLM [chat models](/docs/concepts/chat_models/), which leverage the `langchain-openai` package. For detailed documentation of all `ChatOpenAI` features and configurations head to the [API reference](https://python.langchain.com/api_reference/openai/chat_models/langchain_openai.chat_models.base.ChatOpenAI.html).

### Integration details[​](#integration-details "Direct link to Integration details")

| Class | Package | Local | Serializable | JS support | Package downloads | Package latest |
| --- | --- | --- | --- | --- | --- | --- |
| [ChatOpenAI](https://python.langchain.com/api_reference/openai/chat_models/langchain_openai.chat_models.base.ChatOpenAI.html) | [langchain\_openai](https://python.langchain.com/api_reference/openai/) | ✅ | beta | ❌ | PyPI - Downloads | PyPI - Version |

### Model features[​](#model-features "Direct link to Model features")

Specific model features-- such as tool calling, support for multi-modal inputs, support for token-level streaming, etc.-- will depend on the hosted model.

## Setup[​](#setup "Direct link to Setup")

See the vLLM docs [here](https://docs.vllm.ai/en/latest/).

To access vLLM models through LangChain, you'll need to install the `langchain-openai` integration package.

### Credentials[​](#credentials "Direct link to Credentials")

Authentication will depend on specifics of the inference server.

To enable automated tracing of your model calls, set your [LangSmith](https://docs.smith.langchain.com/) API key:

```
# os.environ["LANGSMITH_TRACING"] = "true"  
# os.environ["LANGSMITH_API_KEY"] = getpass.getpass("Enter your LangSmith API key: ")  

```

### Installation[​](#installation "Direct link to Installation")

The LangChain vLLM integration can be accessed via the `langchain-openai` package:

```
%pip install -qU langchain-openai  

```

## Instantiation[​](#instantiation "Direct link to Instantiation")

Now we can instantiate our model object and generate chat completions:

```
from langchain_core.messages import HumanMessage, SystemMessage  
from langchain_core.prompts.chat import (  
    ChatPromptTemplate,  
    HumanMessagePromptTemplate,  
    SystemMessagePromptTemplate,  
)  
from langchain_openai import ChatOpenAI  

```

**API Reference:**[HumanMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.human.HumanMessage.html) | [SystemMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.system.SystemMessage.html) | [ChatPromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.chat.ChatPromptTemplate.html) | [HumanMessagePromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.chat.HumanMessagePromptTemplate.html) | [SystemMessagePromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.chat.SystemMessagePromptTemplate.html) | [ChatOpenAI](https://python.langchain.com/api_reference/openai/chat_models/langchain_openai.chat_models.base.ChatOpenAI.html)

```
inference_server_url = "http://localhost:8000/v1"  
  
llm = ChatOpenAI(  
    model="mosaicml/mpt-7b",  
    openai_api_key="EMPTY",  
    openai_api_base=inference_server_url,  
    max_tokens=5,  
    temperature=0,  
)  

```

## Invocation[​](#invocation "Direct link to Invocation")

```
messages = [  
    SystemMessage(  
        content="You are a helpful assistant that translates English to Italian."  
    ),  
    HumanMessage(  
        content="Translate the following sentence from English to Italian: I love programming."  
    ),  
]  
llm.invoke(messages)  

```

```
AIMessage(content=' Io amo programmare', additional_kwargs={}, example=False)  

```

## Chaining[​](#chaining "Direct link to Chaining")

We can [chain](/docs/how_to/sequence/) our model with a prompt template like so:

```
from langchain_core.prompts import ChatPromptTemplate  
  
prompt = ChatPromptTemplate(  
    [  
        (  
            "system",  
            "You are a helpful assistant that translates {input_language} to {output_language}.",  
        ),  
        ("human", "{input}"),  
    ]  
)  
  
chain = prompt | llm  
chain.invoke(  
    {  
        "input_language": "English",  
        "output_language": "German",  
        "input": "I love programming.",  
    }  
)  

```

**API Reference:**[ChatPromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.chat.ChatPromptTemplate.html)

## API reference[​](#api-reference "Direct link to API reference")

For detailed documentation of all features and configurations exposed via `langchain-openai`, head to the API reference: <https://python.langchain.com/api_reference/openai/chat_models/langchain_openai.chat_models.base.ChatOpenAI.html>

Refer to the vLLM [documentation](https://docs.vllm.ai/en/latest/) as well.

## Related[​](#related "Direct link to Related")

* Chat model [conceptual guide](/docs/concepts/chat_models/)
* Chat model [how-to guides](/docs/how_to/#chat-models)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/chat/vllm.ipynb)