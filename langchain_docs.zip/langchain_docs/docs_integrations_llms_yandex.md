# Source: https://python.langchain.com/docs/integrations/llms/yandex/

* [Components](/docs/integrations/components/)
* Other
* [LLMs](/docs/integrations/llms/)
* YandexGPT

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/llms/yandex.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/llms/yandex.ipynb)

# YandexGPT

This notebook goes over how to use Langchain with [YandexGPT](https://cloud.yandex.com/en/services/yandexgpt).

To use, you should have the `yandexcloud` python package installed.

```
%pip install --upgrade --quiet  yandexcloud  

```

First, you should [create service account](https://cloud.yandex.com/en/docs/iam/operations/sa/create) with the `ai.languageModels.user` role.

Next, you have two authentication options:

* [IAM token](https://cloud.yandex.com/en/docs/iam/operations/iam-token/create-for-sa).
  You can specify the token in a constructor parameter `iam_token` or in an environment variable `YC_IAM_TOKEN`.
* [API key](https://cloud.yandex.com/en/docs/iam/operations/api-key/create)
  You can specify the key in a constructor parameter `api_key` or in an environment variable `YC_API_KEY`.

To specify the model you can use `model_uri` parameter, see [the documentation](https://cloud.yandex.com/en/docs/yandexgpt/concepts/models#yandexgpt-generation) for more details.

By default, the latest version of `yandexgpt-lite` is used from the folder specified in the parameter `folder_id` or `YC_FOLDER_ID` environment variable.

```
from langchain.chains import LLMChain  
from langchain_community.llms import YandexGPT  
from langchain_core.prompts import PromptTemplate  

```

**API Reference:**[LLMChain](https://python.langchain.com/api_reference/langchain/chains/langchain.chains.llm.LLMChain.html) | [YandexGPT](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.yandex.YandexGPT.html) | [PromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.prompt.PromptTemplate.html)

```
template = "What is the capital of {country}?"  
prompt = PromptTemplate.from_template(template)  

```

```
llm = YandexGPT()  

```

```
llm_chain = LLMChain(prompt=prompt, llm=llm)  

```

```
country = "Russia"  
  
llm_chain.invoke(country)  

```

```
'The capital of Russia is Moscow.'  

```

## Related[​](#related "Direct link to Related")

* LLM [conceptual guide](/docs/concepts/text_llms/)
* LLM [how-to guides](/docs/how_to/#llms)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/llms/yandex.ipynb)