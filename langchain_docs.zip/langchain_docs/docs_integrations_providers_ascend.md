# Source: https://python.langchain.com/docs/integrations/providers/ascend/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Ascend

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/ascend.mdx)

# Ascend

> [Ascend](https://https://www.hiascend.com/) is Natural Process Unit provide by Huawei

This page covers how to use ascend NPU with LangChain.

### Installation[​](#installation "Direct link to Installation")

Install using torch-npu using:

```
pip install torch-npu  

```

Please follow the installation instructions as specified below:

* Install CANN as shown [here](https://www.hiascend.com/document/detail/zh/canncommercial/700/quickstart/quickstart/quickstart_18_0002.html).

### Embedding Models[​](#embedding-models "Direct link to Embedding Models")

See a [usage example](/docs/integrations/text_embedding/ascend/).

```
from langchain_community.embeddings import AscendEmbeddings  

```

**API Reference:**[AscendEmbeddings](https://python.langchain.com/api_reference/community/embeddings/langchain_community.embeddings.ascend.AscendEmbeddings.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/ascend.mdx)