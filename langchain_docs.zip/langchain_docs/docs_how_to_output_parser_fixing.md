# Source: https://python.langchain.com/docs/how_to/output_parser_fixing/

* [How-to guides](/docs/how_to/)
* How to use the output-fixing parser

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/how_to/output_parser_fixing.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/how_to/output_parser_fixing.ipynb)

# How to use the output-fixing parser

This [output parser](/docs/concepts/output_parsers/) wraps another output parser, and in the event that the first one fails it calls out to another LLM to fix any errors.

But we can do other things besides throw errors. Specifically, we can pass the misformatted output, along with the formatted instructions, to the model and ask it to fix it.

For this example, we'll use the above Pydantic output parser. Here's what happens if we pass it a result that does not comply with the schema:

```
from typing import List  
  
from langchain_core.exceptions import OutputParserException  
from langchain_core.output_parsers import PydanticOutputParser  
from langchain_openai import ChatOpenAI  
from pydantic import BaseModel, Field  

```

**API Reference:**[OutputParserException](https://python.langchain.com/api_reference/core/exceptions/langchain_core.exceptions.OutputParserException.html) | [PydanticOutputParser](https://python.langchain.com/api_reference/core/output_parsers/langchain_core.output_parsers.pydantic.PydanticOutputParser.html) | [ChatOpenAI](https://python.langchain.com/api_reference/openai/chat_models/langchain_openai.chat_models.base.ChatOpenAI.html)

```
class Actor(BaseModel):  
    name: str = Field(description="name of an actor")  
    film_names: List[str] = Field(description="list of names of films they starred in")  
  
  
actor_query = "Generate the filmography for a random actor."  
  
parser = PydanticOutputParser(pydantic_object=Actor)  

```

```
misformatted = "{'name': 'Tom Hanks', 'film_names': ['Forrest Gump']}"  

```

```
try:  
    parser.parse(misformatted)  
except OutputParserException as e:  
    print(e)  

```

```
Invalid json output: {'name': 'Tom Hanks', 'film_names': ['Forrest Gump']}  
For troubleshooting, visit: https://python.langchain.com/docs/troubleshooting/errors/OUTPUT_PARSING_FAILURE  

```

Now we can construct and use a `OutputFixingParser`. This output parser takes as an argument another output parser but also an LLM with which to try to correct any formatting mistakes.

```
from langchain.output_parsers import OutputFixingParser  
  
new_parser = OutputFixingParser.from_llm(parser=parser, llm=ChatOpenAI())  

```

**API Reference:**[OutputFixingParser](https://python.langchain.com/api_reference/langchain/output_parsers/langchain.output_parsers.fix.OutputFixingParser.html)

```
new_parser.parse(misformatted)  

```

```
Actor(name='Tom Hanks', film_names=['Forrest Gump'])  

```

Find out api documentation for [OutputFixingParser](https://python.langchain.com/api_reference/langchain/output_parsers/langchain.output_parsers.fix.OutputFixingParser.html#langchain.output_parsers.fix.OutputFixingParser).

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/how_to/output_parser_fixing.ipynb)