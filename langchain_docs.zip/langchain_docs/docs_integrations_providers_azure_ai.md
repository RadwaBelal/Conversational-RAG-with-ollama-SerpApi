# Source: https://python.langchain.com/docs/integrations/providers/azure_ai/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Azure AI

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/azure_ai.mdx)

# Azure AI

All functionality related to [Azure AI Foundry](https://learn.microsoft.com/en-us/azure/developer/python/get-started) and its related projects.

Integration packages for Azure AI, Dynamic Sessions, SQL Server are maintained in
the [langchain-azure](https://github.com/langchain-ai/langchain-azure) repository.

## Chat models[​](#chat-models "Direct link to Chat models")

We recommend developers start with the (`langchain-azure-ai`) to access all the models available in [Azure AI Foundry](https://learn.microsoft.com/en-us/azure/ai-studio/how-to/model-catalog-overview).

### Azure AI Chat Completions Model[​](#azure-ai-chat-completions-model "Direct link to Azure AI Chat Completions Model")

Access models like Azure OpenAI, DeepSeek R1, Cohere, Phi and Mistral using the `AzureAIChatCompletionsModel` class.

```
pip install -U langchain-azure-ai  

```

Configure your API key and Endpoint.

```
export AZURE_INFERENCE_CREDENTIAL=your-api-key  
export AZURE_INFERENCE_ENDPOINT=your-endpoint  

```

```
from langchain_azure_ai.chat_models import AzureAIChatCompletionsModel  
  
llm = AzureAIChatCompletionsModel(  
    model_name="gpt-4o",  
    api_version="2024-05-01-preview",  
)  
  
llm.invoke('Tell me a joke and include some emojis')  

```

**API Reference:**[AzureAIChatCompletionsModel](https://python.langchain.com/api_reference/azure_ai/chat_models/langchain_azure_ai.chat_models.inference.AzureAIChatCompletionsModel.html)

## Embedding models[​](#embedding-models "Direct link to Embedding models")

### Azure AI model inference for embeddings[​](#azure-ai-model-inference-for-embeddings "Direct link to Azure AI model inference for embeddings")

```
pip install -U langchain-azure-ai  

```

Configure your API key and Endpoint.

```
export AZURE_INFERENCE_CREDENTIAL=your-api-key  
export AZURE_INFERENCE_ENDPOINT=your-endpoint  

```

```
from langchain_azure_ai.embeddings import AzureAIEmbeddingsModel  
  
embed_model = AzureAIEmbeddingsModel(  
    model_name="text-embedding-ada-002"  
)  

```

**API Reference:**[AzureAIEmbeddingsModel](https://python.langchain.com/api_reference/azure_ai/embeddings/langchain_azure_ai.embeddings.inference.AzureAIEmbeddingsModel.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/azure_ai.mdx)