# Source: https://python.langchain.com/docs/integrations/providers/galaxia/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Smabbler

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/galaxia.mdx)

# Smabbler

> Smabbler’s graph-powered platform boosts AI development by transforming data into a structured knowledge foundation.

# Galaxia

> Galaxia Knowledge Base is an integrated knowledge base and retrieval mechanism for RAG. In contrast to standard solution, it is based on Knowledge Graphs built using symbolic NLP and Knowledge Representation solutions. Provided texts are analysed and transformed into Graphs containing text, language and semantic information. This rich structure allows for retrieval that is based on semantic information, not on vector similarity/distance.

Implementing RAG using Galaxia involves first uploading your files to [Galaxia](https://beta.cloud.smabbler.com/home), analyzing them there and then building a model (knowledge graph). When the model is built, you can use `GalaxiaRetriever` to connect to the API and start retrieving.

More information: [docs](https://smabbler.gitbook.io/smabbler)

## Installation[​](#installation "Direct link to Installation")

```
pip install langchain-galaxia-retriever  

```

## Usage[​](#usage "Direct link to Usage")

```
from langchain_galaxia_retriever.retriever import GalaxiaRetriever  
  
gr = GalaxiaRetriever(  
    api_url="beta.api.smabbler.com",  
    api_key="<key>",  
    knowledge_base_id="<knowledge_base_id>",  
    n_retries=10,  
    wait_time=5,  
)  
  
result = gr.invoke('<test question>')  
print(result)  
  

```

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/galaxia.mdx)