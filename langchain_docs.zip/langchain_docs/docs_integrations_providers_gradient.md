# Source: https://python.langchain.com/docs/integrations/providers/gradient/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Gradient

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/gradient.mdx)

# Gradient

> [Gradient](https://gradient.ai/) allows to fine tune and get completions on LLMs with a simple web API.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

* Install the Python SDK :

```
pip install gradientai  

```

Get a [Gradient access token and workspace](https://gradient.ai/) and set it as an environment variable (`Gradient_ACCESS_TOKEN`) and (`GRADIENT_WORKSPACE_ID`)

## LLM[​](#llm "Direct link to LLM")

There exists an Gradient LLM wrapper, which you can access with
See a [usage example](/docs/integrations/llms/gradient/).

```
from langchain_community.llms import GradientLLM  

```

**API Reference:**[GradientLLM](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.gradient_ai.GradientLLM.html)

## Text Embedding Model[​](#text-embedding-model "Direct link to Text Embedding Model")

There exists an Gradient Embedding model, which you can access with

```
from langchain_community.embeddings import GradientEmbeddings  

```

**API Reference:**[GradientEmbeddings](https://python.langchain.com/api_reference/community/embeddings/langchain_community.embeddings.gradient_ai.GradientEmbeddings.html)

For a more detailed walkthrough of this, see [this notebook](/docs/integrations/text_embedding/gradient/)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/gradient.mdx)