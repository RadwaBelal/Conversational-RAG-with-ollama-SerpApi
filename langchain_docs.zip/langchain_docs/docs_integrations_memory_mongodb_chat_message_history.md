# Source: https://python.langchain.com/docs/integrations/memory/mongodb_chat_message_history/

* [Components](/docs/integrations/components/)
* Other
* [Message histories](/docs/integrations/memory/)
* MongoDB

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/memory/mongodb_chat_message_history.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/memory/mongodb_chat_message_history.ipynb)

# MongoDB

> `MongoDB` is a source-available cross-platform document-oriented database program. Classified as a NoSQL database program, `MongoDB` uses `JSON`-like documents with optional schemas.
>
> `MongoDB` is developed by MongoDB Inc. and licensed under the Server Side Public License (SSPL). - [Wikipedia](https://en.wikipedia.org/wiki/MongoDB)

This notebook goes over how to use the `MongoDBChatMessageHistory` class to store chat message history in a Mongodb database.

## Setup[​](#setup "Direct link to Setup")

The integration lives in the `langchain-mongodb` package, so we need to install that.

```
pip install -U --quiet langchain-mongodb  

```

It's also helpful (but not needed) to set up [LangSmith](https://smith.langchain.com/) for best-in-class observability

```
# os.environ["LANGSMITH_TRACING"] = "true"  
# os.environ["LANGSMITH_API_KEY"] = getpass.getpass()  

```

## Usage[​](#usage "Direct link to Usage")

To use the storage you need to provide only 2 things:

1. Session Id - a unique identifier of the session, like user name, email, chat id etc.
2. Connection string - a string that specifies the database connection. It will be passed to MongoDB create\_engine function.

If you want to customize where the chat histories go, you can also pass:

1. *database\_name* - name of the database to use
2. *collection\_name* - collection to use within that database

```
from langchain_mongodb.chat_message_histories import MongoDBChatMessageHistory  
  
chat_message_history = MongoDBChatMessageHistory(  
    session_id="test_session",  
    connection_string="mongodb://mongo_user:password123@mongo:27017",  
    database_name="my_db",  
    collection_name="chat_histories",  
)  
  
chat_message_history.add_user_message("Hello")  
chat_message_history.add_ai_message("Hi")  

```

**API Reference:**[MongoDBChatMessageHistory](https://python.langchain.com/api_reference/mongodb/chat_message_histories/langchain_mongodb.chat_message_histories.MongoDBChatMessageHistory.html)

```
chat_message_history.messages  

```

```
[HumanMessage(content='Hello'), AIMessage(content='Hi')]  

```

## Chaining[​](#chaining "Direct link to Chaining")

We can easily combine this message history class with [LCEL Runnables](/docs/how_to/message_history/)

To do this we will want to use OpenAI, so we need to install that. You will also need to set the OPENAI\_API\_KEY environment variable to your OpenAI key.

```
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder  
from langchain_core.runnables.history import RunnableWithMessageHistory  
from langchain_openai import ChatOpenAI  

```

**API Reference:**[ChatPromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.chat.ChatPromptTemplate.html) | [MessagesPlaceholder](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.chat.MessagesPlaceholder.html) | [RunnableWithMessageHistory](https://python.langchain.com/api_reference/core/runnables/langchain_core.runnables.history.RunnableWithMessageHistory.html) | [ChatOpenAI](https://python.langchain.com/api_reference/openai/chat_models/langchain_openai.chat_models.base.ChatOpenAI.html)

```
import os  
  
assert os.environ[  
    "OPENAI_API_KEY"  
], "Set the OPENAI_API_KEY environment variable with your OpenAI API key."  

```

```
prompt = ChatPromptTemplate.from_messages(  
    [  
        ("system", "You are a helpful assistant."),  
        MessagesPlaceholder(variable_name="history"),  
        ("human", "{question}"),  
    ]  
)  
  
chain = prompt | ChatOpenAI()  

```

```
chain_with_history = RunnableWithMessageHistory(  
    chain,  
    lambda session_id: MongoDBChatMessageHistory(  
        session_id=session_id,  
        connection_string="mongodb://mongo_user:password123@mongo:27017",  
        database_name="my_db",  
        collection_name="chat_histories",  
    ),  
    input_messages_key="question",  
    history_messages_key="history",  
)  

```

```
# This is where we configure the session id  
config = {"configurable": {"session_id": "<SESSION_ID>"}}  

```

```
chain_with_history.invoke({"question": "Hi! I'm bob"}, config=config)  

```

```
AIMessage(content='Hi Bob! How can I assist you today?')  

```

```
chain_with_history.invoke({"question": "Whats my name"}, config=config)  

```

```
AIMessage(content='Your name is Bob. Is there anything else I can help you with, Bob?')  

```

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/memory/mongodb_chat_message_history.ipynb)