# Source: https://python.langchain.com/docs/integrations/providers/assemblyai/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* AssemblyAI

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/assemblyai.mdx)

# AssemblyAI

> [AssemblyAI](https://www.assemblyai.com/) builds `Speech AI` models for tasks like
> speech-to-text, speaker diarization, speech summarization, and more.
> `AssemblyAI’s` Speech AI models include accurate speech-to-text for voice data
> (such as calls, virtual meetings, and podcasts), speaker detection, sentiment analysis,
> chapter detection, PII redaction.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

Get your [API key](https://www.assemblyai.com/dashboard/signup).

Install the `assemblyai` package.

```
pip install -U assemblyai  

```

## Document Loader[​](#document-loader "Direct link to Document Loader")

### AssemblyAI Audio Transcript[​](#assemblyai-audio-transcript "Direct link to AssemblyAI Audio Transcript")

The `AssemblyAIAudioTranscriptLoader` transcribes audio files with the `AssemblyAI API`
and loads the transcribed text into documents.

See a [usage example](/docs/integrations/document_loaders/assemblyai/).

```
from langchain_community.document_loaders import AssemblyAIAudioTranscriptLoader  

```

**API Reference:**[AssemblyAIAudioTranscriptLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.assemblyai.AssemblyAIAudioTranscriptLoader.html)

### AssemblyAI Audio Loader By Id[​](#assemblyai-audio-loader-by-id "Direct link to AssemblyAI Audio Loader By Id")

The `AssemblyAIAudioLoaderById` uses the AssemblyAI API to get an existing
transcription and loads the transcribed text into one or more Documents,
depending on the specified format.

```
from langchain_community.document_loaders import AssemblyAIAudioLoaderById  

```

**API Reference:**[AssemblyAIAudioLoaderById](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.assemblyai.AssemblyAIAudioLoaderById.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/assemblyai.mdx)