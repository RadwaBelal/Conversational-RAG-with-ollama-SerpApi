# Source: https://python.langchain.com/docs/contributing/

* Welcome Contributors

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/contributing/index.mdx)

# Welcome Contributors

Hi there! Thank you for your interest in contributing to LangChain.
As an open-source project in a fast developing field, we are extremely open to contributions, whether they involve new features, improved infrastructure, better documentation, or bug fixes.

## Tutorials[​](#tutorials "Direct link to Tutorials")

More coming soon! We are working on tutorials to help you make your first contribution to the project.

* [**Make your first docs PR**](/docs/contributing/tutorials/docs/)

## How-to Guides[​](#how-to-guides "Direct link to How-to Guides")

* [**Documentation**](/docs/contributing/how_to/documentation/): Help improve our docs, including this one!
* [**Code**](/docs/contributing/how_to/code/): Help us write code, fix bugs, or improve our infrastructure.
* [**Integrations**](/docs/contributing/how_to/integrations/): Help us integrate with your favorite vendors and tools.
* [**Standard Tests**](/docs/contributing/how_to/integrations/standard_tests/): Ensure your integration passes an expected set of tests.

## Reference[​](#reference "Direct link to Reference")

* [**Repository Structure**](/docs/contributing/reference/repo_structure/): Understand the high level structure of the repository.
* [**Review Process**](/docs/contributing/reference/review_process/): Learn about the review process for pull requests.
* [**Frequently Asked Questions (FAQ)**](/docs/contributing/reference/faq/): Get answers to common questions about contributing.

## Community[​](#community "Direct link to Community")

### 💭 GitHub Discussions[​](#-github-discussions "Direct link to 💭 GitHub Discussions")

We have a [discussions](https://github.com/langchain-ai/langchain/discussions) page where users can ask usage questions, discuss design decisions, and propose new features.

If you are able to help answer questions, please do so! This will allow the maintainers to spend more time focused on development and bug fixing.

### 🚩 GitHub Issues[​](#-github-issues "Direct link to 🚩 GitHub Issues")

Our [issues](https://github.com/langchain-ai/langchain/issues) page is kept up to date with bugs, improvements, and feature requests.

There is a [taxonomy of labels](https://github.com/langchain-ai/langchain/labels?sort=count-desc)
to help with sorting and discovery of issues of interest. Please use these to help
organize issues. Check out the [Help Wanted](https://github.com/langchain-ai/langchain/labels/help%20wanted)
and [Good First Issue](https://github.com/langchain-ai/langchain/labels/good%20first%20issue)
tags for recommendations.

If you start working on an issue, please assign it to yourself.

If you are adding an issue, please try to keep it focused on a single, modular bug/improvement/feature.
If two issues are related, or blocking, please link them rather than combining them.

We will try to keep these issues as up-to-date as possible, though
with the rapid rate of development in this field some may get out of date.
If you notice this happening, please let us know.

### 📢 Community Slack[​](#-community-slack "Direct link to 📢 Community Slack")

We have a [community slack](https://www.langchain.com/join-community) where you can ask questions, get help, and discuss the project with other contributors and users.

### 🙋 Getting Help[​](#-getting-help "Direct link to 🙋 Getting Help")

Our goal is to have the simplest developer setup possible. Should you experience any difficulty getting setup, please
ask in [community slack](https://www.langchain.com/join-community) or open a [discussion on GitHub](https://github.com/langchain-ai/langchain/discussions).

In a similar vein, we do enforce certain linting, formatting, and documentation standards in the codebase.
If you are finding these difficult (or even just annoying) to work with, feel free to ask in [community slack](https://www.langchain.com/join-community)!

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/contributing/index.mdx)