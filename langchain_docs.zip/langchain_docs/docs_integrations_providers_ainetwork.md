# Source: https://python.langchain.com/docs/integrations/providers/ainetwork/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* AINetwork

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/ainetwork.mdx)

# AINetwork

> [AI Network](https://www.ainetwork.ai/build-on-ain) is a layer 1 blockchain designed to accommodate
> large-scale AI models, utilizing a decentralized GPU network powered by the
> [$AIN token](https://www.ainetwork.ai/token), enriching AI-driven `NFTs` (`AINFTs`).

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

You need to install `ain-py` python package.

```
pip install ain-py  

```

You need to set the `AIN_BLOCKCHAIN_ACCOUNT_PRIVATE_KEY` environmental variable to your AIN Blockchain Account Private Key.

## Toolkit[​](#toolkit "Direct link to Toolkit")

See a [usage example](/docs/integrations/tools/ainetwork/).

```
from langchain_community.agent_toolkits.ainetwork.toolkit import AINetworkToolkit  

```

**API Reference:**[AINetworkToolkit](https://python.langchain.com/api_reference/community/agent_toolkits/langchain_community.agent_toolkits.ainetwork.toolkit.AINetworkToolkit.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/ainetwork.mdx)