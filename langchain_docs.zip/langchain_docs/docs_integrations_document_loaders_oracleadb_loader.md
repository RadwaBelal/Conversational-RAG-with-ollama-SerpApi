# Source: https://python.langchain.com/docs/integrations/document_loaders/oracleadb_loader/

* [Components](/docs/integrations/components/)
* [Document loaders](/docs/integrations/document_loaders/)
* Oracle Autonomous Database

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/oracleadb_loader.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/oracleadb_loader.ipynb)

# Oracle Autonomous Database

Oracle autonomous database is a cloud database that uses machine learning to automate database tuning, security, backups, updates, and other routine management tasks traditionally performed by DBAs.

This notebook covers how to load documents from oracle autonomous database, the loader supports connection with connection string or tns configuration.

## Prerequisites[​](#prerequisites "Direct link to Prerequisites")

1. Database runs in a 'Thin' mode:
   <https://python-oracledb.readthedocs.io/en/latest/user_guide/appendix_b.html>
2. `pip install oracledb`:
   <https://python-oracledb.readthedocs.io/en/latest/user_guide/installation.html>

## Instructions[​](#instructions "Direct link to Instructions")

```
pip install oracledb  

```

```
from langchain_community.document_loaders import OracleAutonomousDatabaseLoader  
from settings import s  

```

**API Reference:**[OracleAutonomousDatabaseLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.oracleadb_loader.OracleAutonomousDatabaseLoader.html)

With mutual TLS authentication (mTLS), wallet\_location and wallet\_password are required to create the connection, user can create connection by providing either connection string or tns configuration details.

```
SQL_QUERY = "select prod_id, time_id from sh.costs fetch first 5 rows only"  
  
doc_loader_1 = OracleAutonomousDatabaseLoader(  
    query=SQL_QUERY,  
    user=s.USERNAME,  
    password=s.PASSWORD,  
    schema=s.SCHEMA,  
    config_dir=s.CONFIG_DIR,  
    wallet_location=s.WALLET_LOCATION,  
    wallet_password=s.PASSWORD,  
    tns_name=s.TNS_NAME,  
)  
doc_1 = doc_loader_1.load()  
  
doc_loader_2 = OracleAutonomousDatabaseLoader(  
    query=SQL_QUERY,  
    user=s.USERNAME,  
    password=s.PASSWORD,  
    schema=s.SCHEMA,  
    connection_string=s.CONNECTION_STRING,  
    wallet_location=s.WALLET_LOCATION,  
    wallet_password=s.PASSWORD,  
)  
doc_2 = doc_loader_2.load()  

```

With TLS authentication, wallet\_location and wallet\_password are not required.
Bind variable option is provided by argument "parameters".

```
SQL_QUERY = "select channel_id, channel_desc from sh.channels where channel_desc = :1 fetch first 5 rows only"  
  
doc_loader_3 = OracleAutonomousDatabaseLoader(  
    query=SQL_QUERY,  
    user=s.USERNAME,  
    password=s.PASSWORD,  
    schema=s.SCHEMA,  
    config_dir=s.CONFIG_DIR,  
    tns_name=s.TNS_NAME,  
    parameters=["Direct Sales"],  
)  
doc_3 = doc_loader_3.load()  
  
doc_loader_4 = OracleAutonomousDatabaseLoader(  
    query=SQL_QUERY,  
    user=s.USERNAME,  
    password=s.PASSWORD,  
    schema=s.SCHEMA,  
    connection_string=s.CONNECTION_STRING,  
    parameters=["Direct Sales"],  
)  
doc_4 = doc_loader_4.load()  

```

## Related[​](#related "Direct link to Related")

* Document loader [conceptual guide](/docs/concepts/document_loaders/)
* Document loader [how-to guides](/docs/how_to/#document-loaders)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/oracleadb_loader.ipynb)