# Source: https://python.langchain.com/docs/integrations/providers/docugami/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Docugami

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/docugami.mdx)

# Docugami

> [Docugami](https://docugami.com) converts business documents into a Document XML Knowledge Graph, generating forests
> of XML semantic trees representing entire documents. This is a rich representation that includes the semantic and
> structural characteristics of various chunks in the document as an XML tree.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

```
pip install dgml-utils  
pip install docugami-langchain  

```

## Document Loader[​](#document-loader "Direct link to Document Loader")

See a [usage example](/docs/integrations/document_loaders/docugami/).

```
from docugami_langchain.document_loaders import DocugamiLoader  

```

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/docugami.mdx)