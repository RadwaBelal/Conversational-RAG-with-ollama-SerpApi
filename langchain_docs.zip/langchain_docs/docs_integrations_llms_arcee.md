# Source: https://python.langchain.com/docs/integrations/llms/arcee/

* [Components](/docs/integrations/components/)
* Other
* [LLMs](/docs/integrations/llms/)
* Arcee

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/llms/arcee.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/llms/arcee.ipynb)

# Arcee

This notebook demonstrates how to use the `Arcee` class for generating text using Arcee's Domain Adapted Language Models (DALMs).

```
##Installing the langchain packages needed to use the integration  
%pip install -qU langchain-community  

```

### Setup[​](#setup "Direct link to Setup")

Before using Arcee, make sure the Arcee API key is set as `ARCEE_API_KEY` environment variable. You can also pass the api key as a named parameter.

```
from langchain_community.llms import Arcee  
  
# Create an instance of the Arcee class  
arcee = Arcee(  
    model="DALM-PubMed",  
    # arcee_api_key="ARCEE-API-KEY" # if not already set in the environment  
)  

```

**API Reference:**[Arcee](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.arcee.Arcee.html)

### Additional Configuration[​](#additional-configuration "Direct link to Additional Configuration")

You can also configure Arcee's parameters such as `arcee_api_url`, `arcee_app_url`, and `model_kwargs` as needed.
Setting the `model_kwargs` at the object initialization uses the parameters as default for all the subsequent calls to the generate response.

```
arcee = Arcee(  
    model="DALM-Patent",  
    # arcee_api_key="ARCEE-API-KEY", # if not already set in the environment  
    arcee_api_url="https://custom-api.arcee.ai",  # default is https://api.arcee.ai  
    arcee_app_url="https://custom-app.arcee.ai",  # default is https://app.arcee.ai  
    model_kwargs={  
        "size": 5,  
        "filters": [  
            {  
                "field_name": "document",  
                "filter_type": "fuzzy_search",  
                "value": "Einstein",  
            }  
        ],  
    },  
)  

```

### Generating Text[​](#generating-text "Direct link to Generating Text")

You can generate text from Arcee by providing a prompt. Here's an example:

```
# Generate text  
prompt = "Can AI-driven music therapy contribute to the rehabilitation of patients with disorders of consciousness?"  
response = arcee(prompt)  

```

### Additional parameters[​](#additional-parameters "Direct link to Additional parameters")

Arcee allows you to apply `filters` and set the `size` (in terms of count) of retrieved document(s) to aid text generation. Filters help narrow down the results. Here's how to use these parameters:

```
# Define filters  
filters = [  
    {"field_name": "document", "filter_type": "fuzzy_search", "value": "Einstein"},  
    {"field_name": "year", "filter_type": "strict_search", "value": "1905"},  
]  
  
# Generate text with filters and size params  
response = arcee(prompt, size=5, filters=filters)  

```

## Related[​](#related "Direct link to Related")

* LLM [conceptual guide](/docs/concepts/text_llms/)
* LLM [how-to guides](/docs/how_to/#llms)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/llms/arcee.ipynb)