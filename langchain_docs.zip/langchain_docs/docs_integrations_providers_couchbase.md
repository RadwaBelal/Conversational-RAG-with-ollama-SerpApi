# Source: https://python.langchain.com/docs/integrations/providers/couchbase/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Couchbase

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/couchbase.mdx)

# Couchbase

> [Couchbase](http://couchbase.com/) is an award-winning distributed NoSQL cloud database
> that delivers unmatched versatility, performance, scalability, and financial value
> for all of your cloud, mobile, AI, and edge computing applications.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

We have to install the `langchain-couchbase` package.

```
pip install langchain-couchbase  

```

## Vector Store[​](#vector-store "Direct link to Vector Store")

See a [usage example](/docs/integrations/vectorstores/couchbase/).

```
from langchain_couchbase import CouchbaseSearchVectorStore  

```

## Document loader[​](#document-loader "Direct link to Document loader")

See a [usage example](/docs/integrations/document_loaders/couchbase/).

```
from langchain_community.document_loaders.couchbase import CouchbaseLoader  

```

**API Reference:**[CouchbaseLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.couchbase.CouchbaseLoader.html)

## LLM Caches[​](#llm-caches "Direct link to LLM Caches")

### CouchbaseCache[​](#couchbasecache "Direct link to CouchbaseCache")

Use Couchbase as a cache for prompts and responses.

See a [usage example](/docs/integrations/llm_caching/#couchbase-caches).

To import this cache:

```
from langchain_couchbase.cache import CouchbaseCache  

```

To use this cache with your LLMs:

```
from langchain_core.globals import set_llm_cache  
  
cluster = couchbase_cluster_connection_object  
  
set_llm_cache(  
    CouchbaseCache(  
        cluster=cluster,  
        bucket_name=BUCKET_NAME,  
        scope_name=SCOPE_NAME,  
        collection_name=COLLECTION_NAME,  
    )  
)  

```

**API Reference:**[set\_llm\_cache](https://python.langchain.com/api_reference/core/globals/langchain_core.globals.set_llm_cache.html)

### CouchbaseSemanticCache[​](#couchbasesemanticcache "Direct link to CouchbaseSemanticCache")

Semantic caching allows users to retrieve cached prompts based on the semantic similarity between the user input and previously cached inputs. Under the hood it uses Couchbase as both a cache and a vectorstore.
The CouchbaseSemanticCache needs a Search Index defined to work. Please look at the [usage example](/docs/integrations/vectorstores/couchbase/) on how to set up the index.

See a [usage example](/docs/integrations/llm_caching/#couchbase-caches).

To import this cache:

```
from langchain_couchbase.cache import CouchbaseSemanticCache  

```

To use this cache with your LLMs:

```
from langchain_core.globals import set_llm_cache  
  
# use any embedding provider...  
from langchain_openai.Embeddings import OpenAIEmbeddings  
  
embeddings = OpenAIEmbeddings()  
cluster = couchbase_cluster_connection_object  
  
set_llm_cache(  
    CouchbaseSemanticCache(  
        cluster=cluster,  
        embedding = embeddings,  
        bucket_name=BUCKET_NAME,  
        scope_name=SCOPE_NAME,  
        collection_name=COLLECTION_NAME,  
        index_name=INDEX_NAME,  
    )  
)  

```

**API Reference:**[set\_llm\_cache](https://python.langchain.com/api_reference/core/globals/langchain_core.globals.set_llm_cache.html)

## Chat Message History[​](#chat-message-history "Direct link to Chat Message History")

Use Couchbase as the storage for your chat messages.

See a [usage example](/docs/integrations/memory/couchbase_chat_message_history/).

To use the chat message history in your applications:

```
from langchain_couchbase.chat_message_histories import CouchbaseChatMessageHistory  
  
message_history = CouchbaseChatMessageHistory(  
    cluster=cluster,  
    bucket_name=BUCKET_NAME,  
    scope_name=SCOPE_NAME,  
    collection_name=COLLECTION_NAME,  
    session_id="test-session",  
)  
  
message_history.add_user_message("hi!")  

```

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/couchbase.mdx)