# Source: https://python.langchain.com/docs/integrations/llms/solar/

* [Components](/docs/integrations/components/)
* Other
* [LLMs](/docs/integrations/llms/)
* Solar

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/llms/solar.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/llms/solar.ipynb)

# Solar

*This community integration is deprecated. You should use [`ChatUpstage`](/docs/integrations/chat/upstage/) instead to access Solar LLM via the chat model connector.*

```
import os  
  
from langchain_community.llms.solar import Solar  
  
os.environ["SOLAR_API_KEY"] = "SOLAR_API_KEY"  
llm = Solar()  
llm.invoke("tell me a story?")  

```

**API Reference:**[Solar](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.solar.Solar.html)

```
from langchain.chains import LLMChain  
from langchain_community.llms.solar import Solar  
from langchain_core.prompts import PromptTemplate  
  
template = """Question: {question}  
  
Answer: Let's think step by step."""  
  
prompt = PromptTemplate.from_template(template)  
  
llm = Solar()  
llm_chain = LLMChain(prompt=prompt, llm=llm)  
  
question = "What NFL team won the Super Bowl in the year Justin Beiber was born?"  
  
llm_chain.run(question)  

```

**API Reference:**[LLMChain](https://python.langchain.com/api_reference/langchain/chains/langchain.chains.llm.LLMChain.html) | [Solar](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.solar.Solar.html) | [PromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.prompt.PromptTemplate.html)

## Related[​](#related "Direct link to Related")

* LLM [conceptual guide](/docs/concepts/text_llms/)
* LLM [how-to guides](/docs/how_to/#llms)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/llms/solar.ipynb)