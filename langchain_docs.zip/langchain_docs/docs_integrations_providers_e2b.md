# Source: https://python.langchain.com/docs/integrations/providers/e2b/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* E2B

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/e2b.mdx)

# E2B

> [E2B](https://e2b.dev/) provides open-source secure sandboxes
> for AI-generated code execution. See more [here](https://github.com/e2b-dev).

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

You have to install a python package:

```
pip install e2b_code_interpreter  

```

## Tool[​](#tool "Direct link to Tool")

See a [usage example](/docs/integrations/tools/e2b_data_analysis/).

```
from langchain_community.tools import E2BDataAnalysisTool  

```

**API Reference:**[E2BDataAnalysisTool](https://python.langchain.com/api_reference/community/tools/langchain_community.tools.e2b_data_analysis.tool.E2BDataAnalysisTool.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/e2b.mdx)