# Source: https://python.langchain.com/docs/integrations/providers/fiddler/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Fiddler

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/fiddler.md)

# Fiddler

> [Fiddler](https://www.fiddler.ai/) provides a unified platform to monitor, explain, analyze,
> and improve ML deployments at an enterprise scale.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

Set up your model [with Fiddler](https://demo.fiddler.ai):

* The URL you're using to connect to Fiddler
* Your organization ID
* Your authorization token

Install the Python package:

```
pip install fiddler-client  

```

## Callbacks[​](#callbacks "Direct link to Callbacks")

```
from langchain_community.callbacks.fiddler_callback import FiddlerCallbackHandler  

```

**API Reference:**[FiddlerCallbackHandler](https://python.langchain.com/api_reference/community/callbacks/langchain_community.callbacks.fiddler_callback.FiddlerCallbackHandler.html)

See an [example](/docs/integrations/callbacks/fiddler/).

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/fiddler.md)