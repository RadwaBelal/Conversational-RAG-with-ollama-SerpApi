# Source: https://python.langchain.com/docs/integrations/providers/dedoc/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Dedoc

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/dedoc.mdx)

# Dedoc

> [Dedoc](https://dedoc.readthedocs.io) is an [open-source](https://github.com/ispras/dedoc)
> library/service that extracts texts, tables, attached files and document structure
> (e.g., titles, list items, etc.) from files of various formats.

`Dedoc` supports `DOCX`, `XLSX`, `PPTX`, `EML`, `HTML`, `PDF`, images and more.
Full list of supported formats can be found [here](https://dedoc.readthedocs.io/en/latest/#id1).

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

### Dedoc library[​](#dedoc-library "Direct link to Dedoc library")

You can install `Dedoc` using `pip`.
In this case, you will need to install dependencies,
please go [here](https://dedoc.readthedocs.io/en/latest/getting_started/installation.html)
to get more information.

```
pip install dedoc  

```

### Dedoc API[​](#dedoc-api "Direct link to Dedoc API")

If you are going to use `Dedoc` API, you don't need to install `dedoc` library.
In this case, you should run the `Dedoc` service, e.g. `Docker` container (please see
[the documentation](https://dedoc.readthedocs.io/en/latest/getting_started/installation.html#install-and-run-dedoc-using-docker)
for more details):

```
docker pull dedocproject/dedoc  
docker run -p 1231:1231  

```

## Document Loader[​](#document-loader "Direct link to Document Loader")

* For handling files of any formats (supported by `Dedoc`), you can use `DedocFileLoader`:

  ```
  from langchain_community.document_loaders import DedocFileLoader  

  ```
* For handling PDF files (with or without a textual layer), you can use `DedocPDFLoader`:

  ```
  from langchain_community.document_loaders import DedocPDFLoader  

  ```
* For handling files of any formats without library installation,
  you can use `Dedoc API` with `DedocAPIFileLoader`:

  ```
  from langchain_community.document_loaders import DedocAPIFileLoader  

  ```

Please see a [usage example](/docs/integrations/document_loaders/dedoc/) for more details.

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/dedoc.mdx)