# Source: https://python.langchain.com/docs/integrations/providers/docusaurus/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Docusaurus

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/docusaurus.mdx)

# Docusaurus

> [Docusaurus](https://docusaurus.io/) is a static-site generator which provides
> out-of-the-box documentation features.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

```
pip install -U beautifulsoup4 lxml  

```

## Document Loader[​](#document-loader "Direct link to Document Loader")

See a [usage example](/docs/integrations/document_loaders/docusaurus/).

```
from langchain_community.document_loaders import DocusaurusLoader  

```

**API Reference:**[DocusaurusLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.docusaurus.DocusaurusLoader.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/docusaurus.mdx)