# Source: https://python.langchain.com/docs/integrations/providers/breebs/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Breebs (Open Knowledge)

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/breebs.md)

# Breebs (Open Knowledge)

> [Breebs](https://www.breebs.com/) is an open collaborative knowledge platform.
> Anybody can create a `Breeb`, a knowledge capsule based on PDFs stored on a Google Drive folder.
> A `Breeb` can be used by any LLM/chatbot to improve its expertise, reduce hallucinations and give access to sources.
> Behind the scenes, `Breebs` implements several `Retrieval Augmented Generation (RAG)` models
> to seamlessly provide useful context at each iteration.

## Retriever[​](#retriever "Direct link to Retriever")

```
from langchain.retrievers import BreebsRetriever  

```

[See a usage example (Retrieval & ConversationalRetrievalChain)](/docs/integrations/retrievers/breebs/)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/breebs.md)