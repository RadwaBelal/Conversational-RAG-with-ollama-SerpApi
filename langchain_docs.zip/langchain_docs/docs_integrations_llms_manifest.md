# Source: https://python.langchain.com/docs/integrations/llms/manifest/

* [Components](/docs/integrations/components/)
* Other
* [LLMs](/docs/integrations/llms/)
* Manifest

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/llms/manifest.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/llms/manifest.ipynb)

# Manifest

This notebook goes over how to use Manifest and LangChain.

For more detailed information on `manifest`, and how to use it with local huggingface models like in this example, see <https://github.com/HazyResearch/manifest>

Another example of [using Manifest with Langchain](https://github.com/HazyResearch/manifest/blob/main/examples/langchain_chatgpt.html).

```
%pip install --upgrade --quiet  manifest-ml  

```

```
from langchain_community.llms.manifest import ManifestWrapper  
from manifest import Manifest  

```

**API Reference:**[ManifestWrapper](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.manifest.ManifestWrapper.html)

```
manifest = Manifest(  
    client_name="huggingface", client_connection="http://127.0.0.1:5000"  
)  
print(manifest.client_pool.get_current_client().get_model_params())  

```

```
llm = ManifestWrapper(  
    client=manifest, llm_kwargs={"temperature": 0.001, "max_tokens": 256}  
)  

```

```
# Map reduce example  
from langchain.chains.mapreduce import MapReduceChain  
from langchain_core.prompts import PromptTemplate  
from langchain_text_splitters import CharacterTextSplitter  
  
_prompt = """Write a concise summary of the following:  
  
  
{text}  
  
  
CONCISE SUMMARY:"""  
prompt = PromptTemplate.from_template(_prompt)  
  
text_splitter = CharacterTextSplitter()  
  
mp_chain = MapReduceChain.from_params(llm, prompt, text_splitter)  

```

**API Reference:**[MapReduceChain](https://python.langchain.com/api_reference/langchain/chains/langchain.chains.mapreduce.MapReduceChain.html) | [PromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.prompt.PromptTemplate.html) | [CharacterTextSplitter](https://python.langchain.com/api_reference/text_splitters/character/langchain_text_splitters.character.CharacterTextSplitter.html)

```
with open("../../how_to/state_of_the_union.txt") as f:  
    state_of_the_union = f.read()  
mp_chain.run(state_of_the_union)  

```

```
'President Obama delivered his annual State of the Union address on Tuesday night, laying out his priorities for the coming year. Obama said the government will provide free flu vaccines to all Americans, ending the government shutdown and allowing businesses to reopen. The president also said that the government will continue to send vaccines to 112 countries, more than any other nation. "We have lost so much to COVID-19," Trump said. "Time with one another. And worst of all, so much loss of life." He said the CDC is working on a vaccine for kids under 5, and that the government will be ready with plenty of vaccines when they are available. Obama says the new guidelines are a "great step forward" and that the virus is no longer a threat. He says the government is launching a "Test to Treat" initiative that will allow people to get tested at a pharmacy and get antiviral pills on the spot at no cost. Obama says the new guidelines are a "great step forward" and that the virus is no longer a threat. He says the government will continue to send vaccines to 112 countries, more than any other nation. "We are coming for your'  

```

## Compare HF Models[​](#compare-hf-models "Direct link to Compare HF Models")

```
from langchain.model_laboratory import ModelLaboratory  
  
manifest1 = ManifestWrapper(  
    client=Manifest(  
        client_name="huggingface", client_connection="http://127.0.0.1:5000"  
    ),  
    llm_kwargs={"temperature": 0.01},  
)  
manifest2 = ManifestWrapper(  
    client=Manifest(  
        client_name="huggingface", client_connection="http://127.0.0.1:5001"  
    ),  
    llm_kwargs={"temperature": 0.01},  
)  
manifest3 = ManifestWrapper(  
    client=Manifest(  
        client_name="huggingface", client_connection="http://127.0.0.1:5002"  
    ),  
    llm_kwargs={"temperature": 0.01},  
)  
llms = [manifest1, manifest2, manifest3]  
model_lab = ModelLaboratory(llms)  

```

**API Reference:**[ModelLaboratory](https://python.langchain.com/api_reference/langchain/model_laboratory/langchain.model_laboratory.ModelLaboratory.html)

```
model_lab.compare("What color is a flamingo?")  

```

```
[1mInput:[0m  
What color is a flamingo?  
  
[1mManifestWrapper[0m  
Params: {'model_name': 'bigscience/T0_3B', 'model_path': 'bigscience/T0_3B', 'temperature': 0.01}  
[104mpink[0m  
  
[1mManifestWrapper[0m  
Params: {'model_name': 'EleutherAI/gpt-neo-125M', 'model_path': 'EleutherAI/gpt-neo-125M', 'temperature': 0.01}  
[103mA flamingo is a small, round[0m  
  
[1mManifestWrapper[0m  
Params: {'model_name': 'google/flan-t5-xl', 'model_path': 'google/flan-t5-xl', 'temperature': 0.01}  
[101mpink[0m  

```

## Related[​](#related "Direct link to Related")

* LLM [conceptual guide](/docs/concepts/text_llms/)
* LLM [how-to guides](/docs/how_to/#llms)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/llms/manifest.ipynb)