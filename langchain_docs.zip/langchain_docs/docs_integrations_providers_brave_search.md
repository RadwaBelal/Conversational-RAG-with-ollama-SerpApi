# Source: https://python.langchain.com/docs/integrations/providers/brave_search/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Brave Search

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/brave_search.mdx)

# Brave Search

> [Brave Search](https://en.wikipedia.org/wiki/Brave_Search) is a search engine developed by Brave Software.
>
> * `Brave Search` uses its own web index. As of May 2022, it covered over 10 billion pages and was used to serve 92%
>   of search results without relying on any third-parties, with the remainder being retrieved
>   server-side from the Bing API or (on an opt-in basis) client-side from Google. According
>   to Brave, the index was kept "intentionally smaller than that of Google or Bing" in order to
>   help avoid spam and other low-quality content, with the disadvantage that "Brave Search is
>   not yet as good as Google in recovering long-tail queries."
> * `Brave Search Premium`: As of April 2023 Brave Search is an ad-free website, but it will
>   eventually switch to a new model that will include ads and premium users will get an ad-free experience.
>   User data including IP addresses won't be collected from its users by default. A premium account
>   will be required for opt-in data-collection.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

To get access to the Brave Search API, you need to [create an account and get an API key](https://api.search.brave.com/app/dashboard).

## Document Loader[​](#document-loader "Direct link to Document Loader")

See a [usage example](/docs/integrations/document_loaders/brave_search/).

```
from langchain_community.document_loaders import BraveSearchLoader  

```

**API Reference:**[BraveSearchLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.brave_search.BraveSearchLoader.html)

## Tool[​](#tool "Direct link to Tool")

See a [usage example](/docs/integrations/tools/brave_search/).

```
from langchain.tools import BraveSearch  

```

**API Reference:**[BraveSearch](https://python.langchain.com/api_reference/community/tools/langchain_community.tools.brave_search.tool.BraveSearch.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/brave_search.mdx)