# Source: https://python.langchain.com/docs/integrations/providers/arize/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Arize

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/arize.mdx)

# Arize

[Arize](https://arize.com) is an AI observability and LLM evaluation platform that offers
support for LangChain applications, providing detailed traces of input, embeddings, retrieval,
functions, and output messages.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

First, you need to install `arize` python package.

```
pip install arize  

```

Second, you need to set up your [Arize account](https://app.arize.com/auth/join)
and get your `API_KEY` or `SPACE_KEY`.

## Callback handler[​](#callback-handler "Direct link to Callback handler")

```
from langchain_community.callbacks import ArizeCallbackHandler  

```

**API Reference:**[ArizeCallbackHandler](https://python.langchain.com/api_reference/community/callbacks/langchain_community.callbacks.arize_callback.ArizeCallbackHandler.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/arize.mdx)