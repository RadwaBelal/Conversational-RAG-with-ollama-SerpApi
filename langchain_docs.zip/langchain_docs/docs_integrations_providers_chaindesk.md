# Source: https://python.langchain.com/docs/integrations/providers/chaindesk/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Chaindesk

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/chaindesk.mdx)

# Chaindesk

> [Chaindesk](https://chaindesk.ai) is an [open-source](https://github.com/gmpetrov/databerry) document retrieval platform that helps to connect your personal data with Large Language Models.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

We need to sign up for Chaindesk, create a datastore, add some data and get your datastore api endpoint url.
We need the [API Key](https://docs.chaindesk.ai/api-reference/authentication).

## Retriever[​](#retriever "Direct link to Retriever")

See a [usage example](/docs/integrations/retrievers/chaindesk/).

```
from langchain.retrievers import ChaindeskRetriever  

```

**API Reference:**[ChaindeskRetriever](https://python.langchain.com/api_reference/community/retrievers/langchain_community.retrievers.chaindesk.ChaindeskRetriever.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/chaindesk.mdx)