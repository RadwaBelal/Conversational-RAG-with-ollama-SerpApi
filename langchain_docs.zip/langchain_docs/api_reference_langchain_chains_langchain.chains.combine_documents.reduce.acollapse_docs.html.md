# Source: https://python.langchain.com/api_reference/langchain/chains/langchain.chains.combine_documents.reduce.acollapse_docs.html

# acollapse\_docs[#](#acollapse-docs "Link to this heading")

*async* langchain.chains.combine\_documents.reduce.acollapse\_docs( : *docs: list[[Document](../../core/documents/langchain_core.documents.base.Document.html#langchain_core.documents.base.Document "langchain_core.documents.base.Document")]*, : *combine\_document\_func: [AsyncCombineDocsProtocol](langchain.chains.combine_documents.reduce.AsyncCombineDocsProtocol.html#langchain.chains.combine_documents.reduce.AsyncCombineDocsProtocol "langchain.chains.combine_documents.reduce.AsyncCombineDocsProtocol")*, : *\*\*kwargs: Any*, ) → [Document](../../core/documents/langchain_core.documents.base.Document.html#langchain_core.documents.base.Document "langchain_core.documents.base.Document")[[source]](../../_modules/langchain/chains/combine_documents/reduce.html#acollapse_docs)[#](#langchain.chains.combine_documents.reduce.acollapse_docs "Link to this definition")
:   Execute a collapse function on a set of documents and merge their metadatas.

    Parameters:
    :   * **docs** (*list**[*[*Document*](../../core/documents/langchain_core.documents.base.Document.html#langchain_core.documents.base.Document "langchain_core.documents.base.Document")*]*) – A list of Documents to combine.
        * **combine\_document\_func** ([*AsyncCombineDocsProtocol*](langchain.chains.combine_documents.reduce.AsyncCombineDocsProtocol.html#langchain.chains.combine_documents.reduce.AsyncCombineDocsProtocol "langchain.chains.combine_documents.reduce.AsyncCombineDocsProtocol")) – A function that takes in a list of Documents and
          optionally addition keyword parameters and combines them into a single
          string.
        * **\*\*kwargs** (*Any*) – Arbitrary additional keyword params to pass to the
          combine\_document\_func.

    Returns:
    :   A single Document with the output of combine\_document\_func for the page content
        :   and the combined metadata’s of all the input documents. All metadata values
            are strings, and where there are overlapping keys across documents the
            values are joined by “, “.

    Return type:
    :   [*Document*](../../core/documents/langchain_core.documents.base.Document.html#langchain_core.documents.base.Document "langchain_core.documents.base.Document")

Examples using acollapse\_docs

* [# Basic example (short documents)](https://python.langchain.com/docs/versions/migrating_chains/map_reduce_chain/)
* [How to summarize text through parallelization](https://python.langchain.com/docs/how_to/summarize_map_reduce/)
* [Summarize Text](https://python.langchain.com/docs/tutorials/summarization/)