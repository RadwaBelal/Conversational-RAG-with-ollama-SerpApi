# Source: https://python.langchain.com/docs/integrations/providers/ctranslate2/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* CTranslate2

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/ctranslate2.mdx)

# CTranslate2

> [CTranslate2](https://opennmt.net/CTranslate2/quickstart.html) is a C++ and Python library
> for efficient inference with Transformer models.
>
> The project implements a custom runtime that applies many performance optimization
> techniques such as weights quantization, layers fusion, batch reordering, etc.,
> to accelerate and reduce the memory usage of Transformer models on CPU and GPU.
>
> A full list of features and supported models is included in the
> [project’s repository](https://opennmt.net/CTranslate2/guides/transformers.html).
> To start, please check out the official [quickstart guide](https://opennmt.net/CTranslate2/quickstart.html).

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

Install the Python package:

```
pip install ctranslate2  

```

## LLMs[​](#llms "Direct link to LLMs")

See a [usage example](/docs/integrations/llms/ctranslate2/).

```
from langchain_community.llms import CTranslate2  

```

**API Reference:**[CTranslate2](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.ctranslate2.CTranslate2.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/ctranslate2.mdx)