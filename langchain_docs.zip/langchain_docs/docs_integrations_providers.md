# Source: https://python.langchain.com/docs/integrations/providers/

* Providers

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/index.mdx)

# Providers

info

If you'd like to write your own integration, see [Extending LangChain](/docs/how_to/#custom).
If you'd like to contribute an integration, see [Contributing integrations](/docs/contributing/how_to/integrations/).

LangChain integrates with many providers.

## Integration Packages[​](#integration-packages "Direct link to Integration Packages")

These providers have standalone `langchain-{provider}` packages for improved versioning, dependency management and testing.

| Provider | Package | Downloads | Latest | [JS](https://js.langchain.com/docs/integrations/platforms/) |
| --- | --- | --- | --- | --- |
| [Google VertexAI](/docs/integrations/providers/google/) | [langchain-google-vertexai](https://python.langchain.com/api_reference/google_vertexai/) | PyPI - Downloads | PyPI - Version | ✅ |
| [OpenAI](/docs/integrations/providers/openai/) | [langchain-openai](https://python.langchain.com/api_reference/openai/) | PyPI - Downloads | PyPI - Version | ✅ |
| [Google Community](/docs/integrations/providers/google/) | [langchain-google-community](https://python.langchain.com/api_reference/google_community/) | PyPI - Downloads | PyPI - Version | ❌ |
| [AWS](/docs/integrations/providers/aws/) | [langchain-aws](https://python.langchain.com/api_reference/aws/) | PyPI - Downloads | PyPI - Version | ✅ |
| [Anthropic](/docs/integrations/providers/anthropic/) | [langchain-anthropic](https://python.langchain.com/api_reference/anthropic/) | PyPI - Downloads | PyPI - Version | ✅ |
| [Google Generative AI](/docs/integrations/providers/google/) | [langchain-google-genai](https://python.langchain.com/api_reference/google_genai/) | PyPI - Downloads | PyPI - Version | ✅ |
| [Chroma](/docs/integrations/providers/chroma/) | [langchain-chroma](https://python.langchain.com/api_reference/chroma/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Ollama](/docs/integrations/providers/ollama/) | [langchain-ollama](https://python.langchain.com/api_reference/ollama/) | PyPI - Downloads | PyPI - Version | ✅ |
| [Cohere](/docs/integrations/providers/cohere/) | [langchain-cohere](https://python.langchain.com/api_reference/cohere/) | PyPI - Downloads | PyPI - Version | ✅ |
| [Pinecone](/docs/integrations/providers/pinecone/) | [langchain-pinecone](https://python.langchain.com/api_reference/pinecone/) | PyPI - Downloads | PyPI - Version | ✅ |
| [Postgres](/docs/integrations/providers/pgvector/) | [langchain-postgres](https://python.langchain.com/api_reference/postgres/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Groq](/docs/integrations/providers/groq/) | [langchain-groq](https://python.langchain.com/api_reference/groq/) | PyPI - Downloads | PyPI - Version | ✅ |
| [Huggingface](/docs/integrations/providers/huggingface/) | [langchain-huggingface](https://python.langchain.com/api_reference/huggingface/) | PyPI - Downloads | PyPI - Version | ❌ |
| [MistralAI](/docs/integrations/providers/mistralai/) | [langchain-mistralai](https://python.langchain.com/api_reference/mistralai/) | PyPI - Downloads | PyPI - Version | ✅ |
| [Fireworks](/docs/integrations/providers/fireworks/) | [langchain-fireworks](https://python.langchain.com/api_reference/fireworks/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Ibm](/docs/integrations/providers/ibm/) | [langchain-ibm](https://python.langchain.com/api_reference/ibm/) | PyPI - Downloads | PyPI - Version | ✅ |
| [MongoDB](/docs/integrations/providers/mongodb_atlas/) | [langchain-mongodb](https://python.langchain.com/api_reference/mongodb/) | PyPI - Downloads | PyPI - Version | ✅ |
| [Deepseek](/docs/integrations/providers/deepseek/) | [langchain-deepseek](https://python.langchain.com/api_reference/deepseek/) | PyPI - Downloads | PyPI - Version | ✅ |
| [Milvus](/docs/integrations/providers/milvus/) | [langchain-milvus](https://python.langchain.com/api_reference/milvus/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Nvidia AI Endpoints](/docs/integrations/providers/nvidia/) | [langchain-nvidia-ai-endpoints](https://python.langchain.com/api_reference/nvidia_ai_endpoints/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Elasticsearch](/docs/integrations/providers/elasticsearch/) | [langchain-elasticsearch](https://python.langchain.com/api_reference/elasticsearch/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Qdrant](/docs/integrations/providers/qdrant/) | [langchain-qdrant](https://python.langchain.com/api_reference/qdrant/) | PyPI - Downloads | PyPI - Version | ✅ |
| [Unstructured](/docs/integrations/providers/unstructured/) | [langchain-unstructured](https://python.langchain.com/api_reference/unstructured/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Databricks](/docs/integrations/providers/databricks/) | [databricks-langchain](https://pypi.org/project/databricks-langchain/) | PyPI - Downloads | PyPI - Version | ❌ |
| [DataStax Astra DB](/docs/integrations/providers/astradb/) | [langchain-astradb](https://python.langchain.com/api_reference/astradb/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Together](/docs/integrations/providers/together/) | [langchain-together](https://python.langchain.com/api_reference/together/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Sambanova](/docs/integrations/providers/sambanova/) | [langchain-sambanova](https://pypi.org/project/langchain-sambanova/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Neo4J](/docs/integrations/providers/neo4j/) | [langchain-neo4j](https://python.langchain.com/api_reference/neo4j/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Graph RAG](/docs/integrations/providers/graph_rag/) | [langchain-graph-retriever](https://pypi.org/project/langchain-graph-retriever/) | PyPI - Downloads | PyPI - Version | ❌ |
| [XAI](/docs/integrations/providers/xai/) | [langchain-xai](https://python.langchain.com/api_reference/xai/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Redis](/docs/integrations/providers/redis/) | [langchain-redis](https://python.langchain.com/api_reference/redis/) | PyPI - Downloads | PyPI - Version | ✅ |
| [Cerebras](/docs/integrations/providers/cerebras/) | [langchain-cerebras](https://python.langchain.com/api_reference/cerebras/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Weaviate](/docs/integrations/providers/weaviate/) | [langchain-weaviate](https://python.langchain.com/api_reference/weaviate/) | PyPI - Downloads | PyPI - Version | ✅ |
| [Tavily](/docs/integrations/providers/tavily/) | [langchain-tavily](https://pypi.org/project/langchain-tavily/) | PyPI - Downloads | PyPI - Version | ✅ |
| [Azure AI](/docs/integrations/providers/azure_ai/) | [langchain-azure-ai](https://python.langchain.com/api_reference/azure_ai/) | PyPI - Downloads | PyPI - Version | ✅ |
| [VoyageAI](/docs/integrations/providers/voyageai/) | [langchain-voyageai](https://python.langchain.com/api_reference/voyageai/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Upstage](/docs/integrations/providers/upstage/) | [langchain-upstage](https://python.langchain.com/api_reference/upstage/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Docling](/docs/integrations/providers/docling/) | [langchain-docling](https://pypi.org/project/langchain-docling/) | PyPI - Downloads | PyPI - Version | ❌ |
| [VDMS](/docs/integrations/providers/vdms/) | [langchain-vdms](https://pypi.org/project/langchain-vdms/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Nomic](/docs/integrations/providers/nomic/) | [langchain-nomic](https://python.langchain.com/api_reference/nomic/) | PyPI - Downloads | PyPI - Version | ✅ |
| [Azure Dynamic Sessions](/docs/integrations/providers/microsoft/) | [langchain-azure-dynamic-sessions](https://python.langchain.com/api_reference/azure_dynamic_sessions/) | PyPI - Downloads | PyPI - Version | ✅ |
| [Perplexity](/docs/integrations/providers/perplexity/) | [langchain-perplexity](https://python.langchain.com/api_reference/perplexity/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Exa](/docs/integrations/providers/exa_search/) | [langchain-exa](https://python.langchain.com/api_reference/exa/) | PyPI - Downloads | PyPI - Version | ✅ |
| [Pymupdf4Llm](/docs/integrations/providers/pymupdf4llm/) | [langchain-pymupdf4llm](https://pypi.org/project/langchain-pymupdf4llm/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Litellm](/docs/integrations/providers/litellm/) | [langchain-litellm](https://pypi.org/project/langchain-litellm/) | PyPI - Downloads | PyPI - Version | ❌ |
| [AI21](/docs/integrations/providers/ai21/) | [langchain-ai21](https://python.langchain.com/api_reference/ai21/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Predictionguard](/docs/integrations/providers/predictionguard/) | [langchain-predictionguard](https://pypi.org/project/langchain-predictionguard/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Sqlserver](/docs/integrations/providers/microsoft/) | [langchain-sqlserver](https://python.langchain.com/api_reference/sqlserver/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Prompty](/docs/integrations/providers/microsoft/) | [langchain-prompty](https://python.langchain.com/api_reference/prompty/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Snowflake](/docs/integrations/providers/snowflake/) | [langchain-snowflake](https://python.langchain.com/api_reference/snowflake/) | PyPI - Downloads | PyPI - Version | ❌ |
| [LangFair](/docs/integrations/providers/langfair/) | [langfair](https://pypi.org/project/langfair/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Sema4](/docs/integrations/providers/robocorp/) | [langchain-sema4](https://python.langchain.com/api_reference/sema4/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Couchbase](/docs/integrations/providers/couchbase/) | [langchain-couchbase](https://pypi.org/project/langchain-couchbase/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Scrapegraph](/docs/integrations/providers/scrapegraph/) | [langchain-scrapegraph](https://pypi.org/project/langchain-scrapegraph/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Apify](/docs/integrations/providers/apify/) | [langchain-apify](https://pypi.org/project/langchain-apify/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Salesforce](/docs/integrations/providers/salesforce/) | [langchain-salesforce](https://pypi.org/project/langchain-salesforce/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Cloudflare](/docs/integrations/providers/cloudflare/) | [langchain-cloudflare](https://pypi.org/project/langchain-cloudflare/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Memgraph](/docs/integrations/providers/memgraph/) | [langchain-memgraph](https://pypi.org/project/langchain-memgraph/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Qwq](/docs/integrations/providers/alibaba_cloud/) | [langchain-qwq](https://pypi.org/project/langchain-qwq/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Kuzu](/docs/integrations/providers/kuzu/) | [langchain-kuzu](https://pypi.org/project/langchain-kuzu/) | PyPI - Downloads | PyPI - Version | ❌ |
| [LocalAI](/docs/integrations/providers/localai/) | [langchain-localai](https://pypi.org/project/langchain-localai/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Writer](/docs/integrations/providers/writer/) | [langchain-writer](https://pypi.org/project/langchain-writer/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Naver](/docs/integrations/providers/naver/) | [langchain-naver](https://pypi.org/project/langchain-naver/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Box](/docs/integrations/providers/box/) | [langchain-box](https://pypi.org/project/langchain-box/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Linkup](/docs/integrations/providers/linkup/) | [langchain-linkup](https://pypi.org/project/langchain-linkup/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Tableau](/docs/integrations/providers/tableau/) | [langchain-tableau](https://pypi.org/project/langchain-tableau/) | PyPI - Downloads | PyPI - Version | ❌ |
| [ADS4GPTs](/docs/integrations/providers/ads4gpts/) | [ads4gpts-langchain](https://pypi.org/project/ads4gpts-langchain/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Contextual AI](/docs/integrations/providers/contextual/) | [langchain-contextual](https://pypi.org/project/langchain-contextual/) | PyPI - Downloads | PyPI - Version | ❌ |
| [MariaDB](/docs/integrations/providers/mariadb/) | [langchain-mariadb](https://pypi.org/project/langchain-mariadb/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Hyperbrowser](/docs/integrations/providers/hyperbrowser/) | [langchain-hyperbrowser](https://pypi.org/project/langchain-hyperbrowser/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Taiga](/docs/integrations/providers/taiga/) | [langchain-taiga](https://pypi.org/project/langchain-taiga/) | PyPI - Downloads | PyPI - Version | ❌ |
| [GOAT SDK](/docs/integrations/providers/goat/) | [goat-sdk-adapter-langchain](https://pypi.org/project/goat-sdk-adapter-langchain/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Galaxia Retriever](/docs/integrations/providers/galaxia/) | [langchain-galaxia-retriever](https://pypi.org/project/langchain-galaxia-retriever/) | PyPI - Downloads | PyPI - Version | ❌ |
| [SAP HANA Cloud](/docs/integrations/providers/sap/) | [langchain-hana](https://pypi.org/project/langchain-hana/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Agentql](/docs/integrations/providers/agentql/) | [langchain-agentql](https://pypi.org/project/langchain-agentql/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Dappier](/docs/integrations/providers/dappier/) | [langchain-dappier](https://pypi.org/project/langchain-dappier/) | PyPI - Downloads | PyPI - Version | ❌ |
| [RunPod](/docs/integrations/providers/runpod/) | [langchain-runpod](https://pypi.org/project/langchain-runpod/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Vectara](/docs/integrations/providers/vectara/) | [langchain-vectara](https://pypi.org/project/langchain-vectara/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Goodfire](/docs/integrations/providers/goodfire/) | [langchain-goodfire](https://pypi.org/project/langchain-goodfire/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Abso](/docs/integrations/providers/abso/) | [langchain-abso](https://pypi.org/project/langchain-abso/) | PyPI - Downloads | PyPI - Version | ❌ |
| [CrateDB](/docs/integrations/providers/cratedb/) | [langchain-cratedb](https://pypi.org/project/langchain-cratedb/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Nimble](/docs/integrations/providers/nimble/) | [langchain-nimble](https://pypi.org/project/langchain-nimble/) | PyPI - Downloads | PyPI - Version | ❌ |
| [YDB](/docs/integrations/providers/ydb/) | [langchain-ydb](https://pypi.org/project/langchain-ydb/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Permit](/docs/integrations/providers/permit/) | [langchain-permit](https://pypi.org/project/langchain-permit/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Valthera](/docs/integrations/providers/valthera/) | [langchain-valthera](https://pypi.org/project/langchain-valthera/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Payman Tool](/docs/integrations/providers/payman-tool/) | [langchain-payman-tool](https://pypi.org/project/langchain-payman-tool/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Jenkins](/docs/integrations/providers/jenkins/) | [langchain-jenkins](https://pypi.org/project/langchain-jenkins/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Prolog](/docs/integrations/providers/prolog/) | [langchain-prolog](https://pypi.org/project/langchain-prolog/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Naver (community-maintained)](/docs/integrations/providers/naver/) | [langchain-naver-community](https://pypi.org/project/langchain-naver-community/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Valyu](/docs/integrations/providers/valyu/) | [langchain-valyu](https://pypi.org/project/langchain-valyu/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Opengradient](/docs/integrations/providers/opengradient/) | [langchain-opengradient](https://pypi.org/project/langchain-opengradient/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Tilores](/docs/integrations/providers/tilores/) | [tilores-langchain](https://pypi.org/project/tilores-langchain/) | PyPI - Downloads | PyPI - Version | ❌ |
| [SingleStore](/docs/integrations/providers/singlestore/) | [langchain-singlestore](https://pypi.org/project/langchain-singlestore/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Fmp Data](/docs/integrations/providers/fmp-data/) | [langchain-fmp-data](https://pypi.org/project/langchain-fmp-data/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Pull Md](/docs/integrations/providers/pull-md/) | [langchain-pull-md](https://pypi.org/project/langchain-pull-md/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Modelscope](/docs/integrations/providers/modelscope/) | [langchain-modelscope](https://pypi.org/project/langchain-modelscope/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Discord Shikenso](/docs/integrations/providers/discord-shikenso/) | [langchain-discord-shikenso](https://pypi.org/project/langchain-discord-shikenso/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Xinference](/docs/integrations/providers/xinference/) | [langchain-xinference](https://pypi.org/project/langchain-xinference/) | PyPI - Downloads | PyPI - Version | ❌ |
| [FalkorDB](/docs/integrations/providers/falkordb/) | [langchain-falkordb](https://pypi.org/project/langchain-falkordb/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Pipeshift](/docs/integrations/providers/pipeshift/) | [langchain-pipeshift](https://pypi.org/project/langchain-pipeshift/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Cognee](/docs/integrations/providers/cognee/) | [langchain-cognee](https://pypi.org/project/langchain-cognee/) | PyPI - Downloads | PyPI - Version | ❌ |
| [PowerScale RAG Connector](/docs/integrations/providers/dell/) | [powerscale-rag-connector](https://pypi.org/project/powerscale-rag-connector/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Oceanbase](/docs/integrations/providers/oceanbase/) | [langchain-oceanbase](https://pypi.org/project/langchain-oceanbase/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Deeplake](/docs/integrations/providers/deeplake/) | [langchain-deeplake](https://pypi.org/project/langchain-deeplake/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Zotero](/docs/integrations/providers/zotero/) | [langchain-zotero-retriever](https://pypi.org/project/langchain-zotero-retriever/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Oxylabs](/docs/integrations/providers/oxylabs/) | [langchain-oxylabs](https://pypi.org/project/langchain-oxylabs/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Lindorm Integration](/docs/integrations/providers/lindorm/) | [langchain-lindorm-integration](https://pypi.org/project/langchain-lindorm-integration/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Netmind](/docs/integrations/providers/netmind/) | [langchain-netmind](https://pypi.org/project/langchain-netmind/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Gel](/docs/integrations/providers/gel/) | [langchain-gel](https://pypi.org/project/langchain-gel/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Aerospike](/docs/integrations/providers/aerospike/) | [langchain-aerospike](https://pypi.org/project/langchain-aerospike/) | PyPI - Downloads | PyPI - Version | ❌ |
| [Brightdata](/docs/integrations/providers/brightdata/) | [langchain-brightdata](https://pypi.org/project/langchain-brightdata/) | PyPI - Downloads | PyPI - Version | ❌ |

## All Providers[​](#all-providers "Direct link to All Providers")

Click [here](/docs/integrations/providers/all/) to see all providers. Or search for a
provider using the Search field in the top-right corner of the screen.

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/index.mdx)