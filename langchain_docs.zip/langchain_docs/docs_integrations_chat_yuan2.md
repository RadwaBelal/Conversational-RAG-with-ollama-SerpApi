# Source: https://python.langchain.com/docs/integrations/chat/yuan2/

* [Components](/docs/integrations/components/)
* [Chat models](/docs/integrations/chat/)
* Yuan2.0

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/yuan2.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/yuan2.ipynb)

# Yuan2.0

This notebook shows how to use [YUAN2 API](https://github.com/IEIT-Yuan/Yuan-2.0/blob/main/docs/inference_server.md) in LangChain with the langchain.chat\_models.ChatYuan2.

[*Yuan2.0*](https://github.com/IEIT-Yuan/Yuan-2.0/blob/main/README-EN.md) is a new generation Fundamental Large Language Model developed by IEIT System. We have published all three models, Yuan 2.0-102B, Yuan 2.0-51B, and Yuan 2.0-2B. And we provide relevant scripts for pretraining, fine-tuning, and inference services for other developers. Yuan2.0 is based on Yuan1.0, utilizing a wider range of high-quality pre training data and instruction fine-tuning datasets to enhance the model's understanding of semantics, mathematics, reasoning, code, knowledge, and other aspects.

## Getting started[​](#getting-started "Direct link to Getting started")

### Installation[​](#installation "Direct link to Installation")

First, Yuan2.0 provided an OpenAI compatible API, and we integrate ChatYuan2 into langchain chat model by using OpenAI client.
Therefore, ensure the openai package is installed in your Python environment. Run the following command:

```
%pip install --upgrade --quiet openai  

```

### Importing the Required Modules[​](#importing-the-required-modules "Direct link to Importing the Required Modules")

After installation, import the necessary modules to your Python script:

```
from langchain_community.chat_models import ChatYuan2  
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage  

```

**API Reference:**[ChatYuan2](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.yuan2.ChatYuan2.html) | [AIMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.ai.AIMessage.html) | [HumanMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.human.HumanMessage.html) | [SystemMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.system.SystemMessage.html)

### Setting Up Your API server[​](#setting-up-your-api-server "Direct link to Setting Up Your API server")

Setting up your OpenAI compatible API server following [yuan2 openai api server](https://github.com/IEIT-Yuan/Yuan-2.0/blob/main/docs/Yuan2_fastchat.md).
If you deployed api server locally, you can simply set `yuan2_api_key="EMPTY"` or anything you want.
Just make sure, the `yuan2_api_base` is set correctly.

```
yuan2_api_key = "your_api_key"  
yuan2_api_base = "http://127.0.0.1:8001/v1"  

```

### Initialize the ChatYuan2 Model[​](#initialize-the-chatyuan2-model "Direct link to Initialize the ChatYuan2 Model")

Here's how to initialize the chat model:

```
chat = ChatYuan2(  
    yuan2_api_base="http://127.0.0.1:8001/v1",  
    temperature=1.0,  
    model_name="yuan2",  
    max_retries=3,  
    streaming=False,  
)  

```

### Basic Usage[​](#basic-usage "Direct link to Basic Usage")

Invoke the model with system and human messages like this:

```
messages = [  
    SystemMessage(content="你是一个人工智能助手。"),  
    HumanMessage(content="你好，你是谁？"),  
]  

```

```
print(chat.invoke(messages))  

```

### Basic Usage with streaming[​](#basic-usage-with-streaming "Direct link to Basic Usage with streaming")

For continuous interaction, use the streaming feature:

```
from langchain_core.callbacks import StreamingStdOutCallbackHandler  
  
chat = ChatYuan2(  
    yuan2_api_base="http://127.0.0.1:8001/v1",  
    temperature=1.0,  
    model_name="yuan2",  
    max_retries=3,  
    streaming=True,  
    callbacks=[StreamingStdOutCallbackHandler()],  
)  
messages = [  
    SystemMessage(content="你是个旅游小助手。"),  
    HumanMessage(content="给我介绍一下北京有哪些好玩的。"),  
]  

```

**API Reference:**[StreamingStdOutCallbackHandler](https://python.langchain.com/api_reference/core/callbacks/langchain_core.callbacks.streaming_stdout.StreamingStdOutCallbackHandler.html)

```
chat.invoke(messages)  

```

## Advanced Features[​](#advanced-features "Direct link to Advanced Features")

### Usage with async calls[​](#usage-with-async-calls "Direct link to Usage with async calls")

Invoke the model with non-blocking calls, like this:

```
async def basic_agenerate():  
    chat = ChatYuan2(  
        yuan2_api_base="http://127.0.0.1:8001/v1",  
        temperature=1.0,  
        model_name="yuan2",  
        max_retries=3,  
    )  
    messages = [  
        [  
            SystemMessage(content="你是个旅游小助手。"),  
            HumanMessage(content="给我介绍一下北京有哪些好玩的。"),  
        ]  
    ]  
  
    result = await chat.agenerate(messages)  
    print(result)  

```

```
import asyncio  
  
asyncio.run(basic_agenerate())  

```

### Usage with prompt template[​](#usage-with-prompt-template "Direct link to Usage with prompt template")

Invoke the model with non-blocking calls and used chat template like this:

```
async def ainvoke_with_prompt_template():  
    from langchain_core.prompts.chat import (  
        ChatPromptTemplate,  
    )  
  
    chat = ChatYuan2(  
        yuan2_api_base="http://127.0.0.1:8001/v1",  
        temperature=1.0,  
        model_name="yuan2",  
        max_retries=3,  
    )  
    prompt = ChatPromptTemplate.from_messages(  
        [  
            ("system", "你是一个诗人，擅长写诗。"),  
            ("human", "给我写首诗，主题是{theme}。"),  
        ]  
    )  
    chain = prompt | chat  
    result = await chain.ainvoke({"theme": "明月"})  
    print(f"type(result): {type(result)}; {result}")  

```

**API Reference:**[ChatPromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.chat.ChatPromptTemplate.html)

```
asyncio.run(ainvoke_with_prompt_template())  

```

### Usage with async calls in streaming[​](#usage-with-async-calls-in-streaming "Direct link to Usage with async calls in streaming")

For non-blocking calls with streaming output, use the astream method:

```
async def basic_astream():  
    chat = ChatYuan2(  
        yuan2_api_base="http://127.0.0.1:8001/v1",  
        temperature=1.0,  
        model_name="yuan2",  
        max_retries=3,  
    )  
    messages = [  
        SystemMessage(content="你是个旅游小助手。"),  
        HumanMessage(content="给我介绍一下北京有哪些好玩的。"),  
    ]  
    result = chat.astream(messages)  
    async for chunk in result:  
        print(chunk.content, end="", flush=True)  

```

```
import asyncio  
  
asyncio.run(basic_astream())  

```

## Related[​](#related "Direct link to Related")

* Chat model [conceptual guide](/docs/concepts/chat_models/)
* Chat model [how-to guides](/docs/how_to/#chat-models)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/chat/yuan2.ipynb)