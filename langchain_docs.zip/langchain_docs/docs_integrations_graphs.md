# Source: https://python.langchain.com/docs/integrations/graphs/

[## 📄️ Amazon Neptune with Cypher

Amazon Neptune is a high-performance graph analytics and serverless database for superior scalability and availability.](/docs/integrations/graphs/amazon_neptune_open_cypher/)

[## 📄️ Amazon Neptune with SPARQL

Amazon Neptune is a high-performance graph analytics and serverless database for superior scalability and availability.](/docs/integrations/graphs/amazon_neptune_sparql/)

[## 📄️ Apache AGE

Apache AGE is a PostgreSQL extension that provides graph database functionality. AGE is an acronym for A Graph Extension, and is inspired by Bitnine’s fork of PostgreSQL 10, AgensGraph, which is a multi-model database. The goal of the project is to create single storage that can handle both relational and graph model data so that users can use standard ANSI SQL along with openCypher, the Graph query language. The data elements Apache AGE stores are nodes, edges connecting them, and attributes of nodes and edges.](/docs/integrations/graphs/apache_age/)

[## 📄️ ArangoDB

Open In Colab](/docs/integrations/graphs/arangodb/)

[## 📄️ Azure Cosmos DB for Apache Gremlin

Azure Cosmos DB for Apache Gremlin is a graph database service that can be used to store massive graphs with billions of vertices and edges. You can query the graphs with millisecond latency and evolve the graph structure easily.](/docs/integrations/graphs/azure_cosmosdb_gremlin/)

[## 📄️ Diffbot

Diffbot is a suite of ML-based products that make it easy to structure web data.](/docs/integrations/graphs/diffbot/)

[## 📄️ FalkorDB

FalkorDB is a low-latency Graph Database that delivers knowledge to GenAI.](/docs/integrations/graphs/falkordb/)

[## 📄️ HugeGraph

HugeGraph is a convenient, efficient, and adaptable graph database compatible with](/docs/integrations/graphs/hugegraph/)

[## 📄️ Kuzu

Kùzu is an embeddable, scalable, extremely fast graph database.](/docs/integrations/graphs/kuzu_db/)

[## 📄️ Memgraph

Memgraph is an open-source graph database, tuned for dynamic analytics environments and compatible with Neo4j. To query the database, Memgraph uses Cypher - the most widely adopted, fully-specified, and open query language for property graph databases.](/docs/integrations/graphs/memgraph/)

[## 📄️ NebulaGraph

NebulaGraph is an open-source, distributed, scalable, lightning-fast](/docs/integrations/graphs/nebula_graph/)

[## 📄️ Neo4j

Neo4j is a graph database management system developed by Neo4j, Inc.](/docs/integrations/graphs/neo4j_cypher/)

[## 📄️ NetworkX

NetworkX is a Python package for the creation, manipulation, and study of the structure, dynamics, and functions of complex networks.](/docs/integrations/graphs/networkx/)

[## 📄️ Ontotext GraphDB

Ontotext GraphDB is a graph database and knowledge discovery tool compliant with RDF and SPARQL.](/docs/integrations/graphs/ontotext/)

[## 📄️ RDFLib

RDFLib is a pure Python package for working with RDF. RDFLib contains most things you need to work with RDF, including:](/docs/integrations/graphs/rdflib_sparql/)

[## 📄️ TigerGraph

TigerGraph is a natively distributed and high-performance graph database.](/docs/integrations/graphs/tigergraph/)