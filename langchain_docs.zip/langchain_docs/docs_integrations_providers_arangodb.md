# Source: https://python.langchain.com/docs/integrations/providers/arangodb/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* ArangoDB

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/arangodb.mdx)

# ArangoDB

> [ArangoDB](https://github.com/arangodb/arangodb) is a scalable graph database system to
> drive value from connected data, faster. Native graphs, an integrated search engine, and JSON support, via a single query language. ArangoDB runs on-prem, in the cloud – anywhere.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

Install the [ArangoDB Python Driver](https://github.com/ArangoDB-Community/python-arango) package with

```
pip install python-arango  

```

## Graph QA Chain[​](#graph-qa-chain "Direct link to Graph QA Chain")

Connect your `ArangoDB` Database with a chat model to get insights on your data.

See the notebook example [here](/docs/integrations/graphs/arangodb/).

```
from arango import ArangoClient  
  
from langchain_community.graphs import ArangoGraph  
from langchain.chains import ArangoGraphQAChain  

```

**API Reference:**[ArangoGraph](https://python.langchain.com/api_reference/community/graphs/langchain_community.graphs.arangodb_graph.ArangoGraph.html) | [ArangoGraphQAChain](https://python.langchain.com/api_reference/community/chains/langchain_community.chains.graph_qa.arangodb.ArangoGraphQAChain.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/arangodb.mdx)