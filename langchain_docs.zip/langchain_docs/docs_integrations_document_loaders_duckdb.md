# Source: https://python.langchain.com/docs/integrations/document_loaders/duckdb/

* [Components](/docs/integrations/components/)
* [Document loaders](/docs/integrations/document_loaders/)
* DuckDB

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/duckdb.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/duckdb.ipynb)

# DuckDB

> [DuckDB](https://duckdb.org/) is an in-process SQL OLAP database management system.

Load a `DuckDB` query with one document per row.

```
%pip install --upgrade --quiet  duckdb  

```

```
from langchain_community.document_loaders import DuckDBLoader  

```

**API Reference:**[DuckDBLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.duckdb_loader.DuckDBLoader.html)

```
%%file example.csv  
Team,Payroll  
Nationals,81.34  
Reds,82.20  

```

```
Writing example.csv  

```

```
loader = DuckDBLoader("SELECT * FROM read_csv_auto('example.csv')")  
  
data = loader.load()  

```

```
print(data)  

```

```
[Document(page_content='Team: Nationals\nPayroll: 81.34', metadata={}), Document(page_content='Team: Reds\nPayroll: 82.2', metadata={})]  

```

## Specifying Which Columns are Content vs Metadata[​](#specifying-which-columns-are-content-vs-metadata "Direct link to Specifying Which Columns are Content vs Metadata")

```
loader = DuckDBLoader(  
    "SELECT * FROM read_csv_auto('example.csv')",  
    page_content_columns=["Team"],  
    metadata_columns=["Payroll"],  
)  
  
data = loader.load()  

```

```
print(data)  

```

```
[Document(page_content='Team: Nationals', metadata={'Payroll': 81.34}), Document(page_content='Team: Reds', metadata={'Payroll': 82.2})]  

```

## Adding Source to Metadata[​](#adding-source-to-metadata "Direct link to Adding Source to Metadata")

```
loader = DuckDBLoader(  
    "SELECT Team, Payroll, Team As source FROM read_csv_auto('example.csv')",  
    metadata_columns=["source"],  
)  
  
data = loader.load()  

```

```
print(data)  

```

```
[Document(page_content='Team: Nationals\nPayroll: 81.34\nsource: Nationals', metadata={'source': 'Nationals'}), Document(page_content='Team: Reds\nPayroll: 82.2\nsource: Reds', metadata={'source': 'Reds'})]  

```

## Related[​](#related "Direct link to Related")

* Document loader [conceptual guide](/docs/concepts/document_loaders/)
* Document loader [how-to guides](/docs/how_to/#document-loaders)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/duckdb.ipynb)