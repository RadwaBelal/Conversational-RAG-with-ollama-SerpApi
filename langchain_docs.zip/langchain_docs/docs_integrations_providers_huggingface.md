# Source: https://python.langchain.com/docs/integrations/providers/huggingface/

* [Providers](/docs/integrations/providers/)
* Hugging Face

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/huggingface.mdx)

# Hugging Face

All functionality related to the [Hugging Face Platform](https://huggingface.co/).

## Installation[​](#installation "Direct link to Installation")

Most of the Hugging Face integrations are available in the `langchain-huggingface` package.

```
pip install langchain-huggingface  

```

## Chat models[​](#chat-models "Direct link to Chat models")

### ChatHuggingFace[​](#chathuggingface "Direct link to ChatHuggingFace")

We can use the `Hugging Face` LLM classes or directly use the `ChatHuggingFace` class.

See a [usage example](/docs/integrations/chat/huggingface/).

```
from langchain_huggingface import ChatHuggingFace  

```

**API Reference:**[ChatHuggingFace](https://python.langchain.com/api_reference/huggingface/chat_models/langchain_huggingface.chat_models.huggingface.ChatHuggingFace.html)

## LLMs[​](#llms "Direct link to LLMs")

### HuggingFaceEndpoint[​](#huggingfaceendpoint "Direct link to HuggingFaceEndpoint")

See a [usage example](/docs/integrations/llms/huggingface_endpoint/).

```
from langchain_huggingface import HuggingFaceEndpoint  

```

**API Reference:**[HuggingFaceEndpoint](https://python.langchain.com/api_reference/huggingface/llms/langchain_huggingface.llms.huggingface_endpoint.HuggingFaceEndpoint.html)

### HuggingFacePipeline[​](#huggingfacepipeline "Direct link to HuggingFacePipeline")

Hugging Face models can be run locally through the `HuggingFacePipeline` class.

See a [usage example](/docs/integrations/llms/huggingface_pipelines/).

```
from langchain_huggingface import HuggingFacePipeline  

```

**API Reference:**[HuggingFacePipeline](https://python.langchain.com/api_reference/huggingface/llms/langchain_huggingface.llms.huggingface_pipeline.HuggingFacePipeline.html)

## Embedding Models[​](#embedding-models "Direct link to Embedding Models")

### HuggingFaceEmbeddings[​](#huggingfaceembeddings "Direct link to HuggingFaceEmbeddings")

See a [usage example](/docs/integrations/text_embedding/huggingfacehub/).

```
from langchain_huggingface import HuggingFaceEmbeddings  

```

**API Reference:**[HuggingFaceEmbeddings](https://python.langchain.com/api_reference/huggingface/embeddings/langchain_huggingface.embeddings.huggingface.HuggingFaceEmbeddings.html)

### HuggingFaceEndpointEmbeddings[​](#huggingfaceendpointembeddings "Direct link to HuggingFaceEndpointEmbeddings")

See a [usage example](/docs/integrations/text_embedding/huggingfacehub/).

```
from langchain_huggingface import HuggingFaceEndpointEmbeddings  

```

**API Reference:**[HuggingFaceEndpointEmbeddings](https://python.langchain.com/api_reference/huggingface/embeddings/langchain_huggingface.embeddings.huggingface_endpoint.HuggingFaceEndpointEmbeddings.html)

### HuggingFaceInferenceAPIEmbeddings[​](#huggingfaceinferenceapiembeddings "Direct link to HuggingFaceInferenceAPIEmbeddings")

See a [usage example](/docs/integrations/text_embedding/huggingfacehub/).

```
from langchain_community.embeddings import HuggingFaceInferenceAPIEmbeddings  

```

**API Reference:**[HuggingFaceInferenceAPIEmbeddings](https://python.langchain.com/api_reference/community/embeddings/langchain_community.embeddings.huggingface.HuggingFaceInferenceAPIEmbeddings.html)

### HuggingFaceInstructEmbeddings[​](#huggingfaceinstructembeddings "Direct link to HuggingFaceInstructEmbeddings")

See a [usage example](/docs/integrations/text_embedding/instruct_embeddings/).

```
from langchain_community.embeddings import HuggingFaceInstructEmbeddings  

```

**API Reference:**[HuggingFaceInstructEmbeddings](https://python.langchain.com/api_reference/community/embeddings/langchain_community.embeddings.huggingface.HuggingFaceInstructEmbeddings.html)

### HuggingFaceBgeEmbeddings[​](#huggingfacebgeembeddings "Direct link to HuggingFaceBgeEmbeddings")

> [BGE models on the HuggingFace](https://huggingface.co/BAAI/bge-large-en-v1.5) are one of [the best open-source embedding models](https://huggingface.co/spaces/mteb/leaderboard).
> BGE model is created by the [Beijing Academy of Artificial Intelligence (BAAI)](https://en.wikipedia.org/wiki/Beijing_Academy_of_Artificial_Intelligence). `BAAI` is a private non-profit organization engaged in AI research and development.

See a [usage example](/docs/integrations/text_embedding/bge_huggingface/).

```
from langchain_community.embeddings import HuggingFaceBgeEmbeddings  

```

**API Reference:**[HuggingFaceBgeEmbeddings](https://python.langchain.com/api_reference/community/embeddings/langchain_community.embeddings.huggingface.HuggingFaceBgeEmbeddings.html)

## Document Loaders[​](#document-loaders "Direct link to Document Loaders")

### Hugging Face dataset[​](#hugging-face-dataset "Direct link to Hugging Face dataset")

> [Hugging Face Hub](https://huggingface.co/docs/hub/index) is home to over 75,000
> [datasets](https://huggingface.co/docs/hub/index#datasets) in more than 100 languages
> that can be used for a broad range of tasks across NLP, Computer Vision, and Audio.
> They used for a diverse range of tasks such as translation, automatic speech
> recognition, and image classification.

We need to install `datasets` python package.

```
pip install datasets  

```

See a [usage example](/docs/integrations/document_loaders/hugging_face_dataset/).

```
from langchain_community.document_loaders.hugging_face_dataset import HuggingFaceDatasetLoader  

```

**API Reference:**[HuggingFaceDatasetLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.hugging_face_dataset.HuggingFaceDatasetLoader.html)

### Hugging Face model loader[​](#hugging-face-model-loader "Direct link to Hugging Face model loader")

> Load model information from `Hugging Face Hub`, including README content.
>
> This loader interfaces with the `Hugging Face Models API` to fetch
> and load model metadata and README files.
> The API allows you to search and filter models based on
> specific criteria such as model tags, authors, and more.

```
from langchain_community.document_loaders import HuggingFaceModelLoader  

```

**API Reference:**[HuggingFaceModelLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.hugging_face_model.HuggingFaceModelLoader.html)

### Image captions[​](#image-captions "Direct link to Image captions")

It uses the Hugging Face models to generate image captions.

We need to install several python packages.

```
pip install transformers pillow  

```

See a [usage example](/docs/integrations/document_loaders/image_captions/).

```
from langchain_community.document_loaders import ImageCaptionLoader  

```

**API Reference:**[ImageCaptionLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.image_captions.ImageCaptionLoader.html)

## Tools[​](#tools "Direct link to Tools")

### Hugging Face Hub Tools[​](#hugging-face-hub-tools "Direct link to Hugging Face Hub Tools")

> [Hugging Face Tools](https://huggingface.co/docs/transformers/v4.29.0/en/custom_tools)
> support text I/O and are loaded using the `load_huggingface_tool` function.

We need to install several python packages.

```
pip install transformers huggingface_hub  

```

See a [usage example](/docs/integrations/tools/huggingface_tools/).

```
from langchain_community.agent_toolkits.load_tools import load_huggingface_tool  

```

**API Reference:**[load\_huggingface\_tool](https://python.langchain.com/api_reference/community/agent_toolkits/langchain_community.agent_toolkits.load_tools.load_huggingface_tool.html)

### Hugging Face Text-to-Speech Model Inference.[​](#hugging-face-text-to-speech-model-inference "Direct link to Hugging Face Text-to-Speech Model Inference.")

> It is a wrapper around `OpenAI Text-to-Speech API`.

```
from langchain_community.tools.audio import HuggingFaceTextToSpeechModelInference  

```

**API Reference:**[HuggingFaceTextToSpeechModelInference](https://python.langchain.com/api_reference/community/tools/langchain_community.tools.audio.huggingface_text_to_speech_inference.HuggingFaceTextToSpeechModelInference.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/huggingface.mdx)