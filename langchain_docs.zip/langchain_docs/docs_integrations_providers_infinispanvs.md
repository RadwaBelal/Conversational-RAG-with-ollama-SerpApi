# Source: https://python.langchain.com/docs/integrations/providers/infinispanvs/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Infinispan VS

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/infinispanvs.mdx)

# Infinispan VS

> [Infinispan](https://infinispan.org) Infinispan is an open-source in-memory data grid that provides
> a key/value data store able to hold all types of data, from Java objects to plain text.
> Since version 15 Infinispan supports vector search over caches.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

See [Get Started](https://infinispan.org/get-started/) to run an Infinispan server, you may want to disable authentication
(not supported atm)

## Vector Store[​](#vector-store "Direct link to Vector Store")

See a [usage example](/docs/integrations/vectorstores/infinispanvs/).

```
from langchain_community.vectorstores import InfinispanVS  

```

**API Reference:**[InfinispanVS](https://python.langchain.com/api_reference/community/vectorstores/langchain_community.vectorstores.infinispanvs.InfinispanVS.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/infinispanvs.mdx)