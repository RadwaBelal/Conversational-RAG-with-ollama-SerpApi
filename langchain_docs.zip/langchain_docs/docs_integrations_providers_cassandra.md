# Source: https://python.langchain.com/docs/integrations/providers/cassandra/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Cassandra

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/cassandra.mdx)

# Cassandra

> [Apache Cassandra®](https://cassandra.apache.org/) is a NoSQL, row-oriented, highly scalable and highly available database.
> Starting with version 5.0, the database ships with [vector search capabilities](https://cassandra.apache.org/doc/trunk/cassandra/vector-search/overview.html).

The integrations outlined in this page can be used with `Cassandra` as well as other CQL-compatible databases,
i.e. those using the `Cassandra Query Language` protocol.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

Install the following Python package:

```
pip install "cassio>=0.1.6"  

```

## Vector Store[​](#vector-store "Direct link to Vector Store")

```
from langchain_community.vectorstores import Cassandra  

```

**API Reference:**[Cassandra](https://python.langchain.com/api_reference/community/vectorstores/langchain_community.vectorstores.cassandra.Cassandra.html)

Learn more in the [example notebook](/docs/integrations/vectorstores/cassandra/).

## Chat message history[​](#chat-message-history "Direct link to Chat message history")

```
from langchain_community.chat_message_histories import CassandraChatMessageHistory  

```

**API Reference:**[CassandraChatMessageHistory](https://python.langchain.com/api_reference/community/chat_message_histories/langchain_community.chat_message_histories.cassandra.CassandraChatMessageHistory.html)

Learn more in the [example notebook](/docs/integrations/memory/cassandra_chat_message_history/).

## LLM Cache[​](#llm-cache "Direct link to LLM Cache")

```
from langchain.globals import set_llm_cache  
from langchain_community.cache import CassandraCache  
set_llm_cache(CassandraCache())  

```

**API Reference:**[set\_llm\_cache](https://python.langchain.com/api_reference/langchain/globals/langchain.globals.set_llm_cache.html) | [CassandraCache](https://python.langchain.com/api_reference/community/cache/langchain_community.cache.CassandraCache.html)

Learn more in the [example notebook](/docs/integrations/llm_caching/#cassandra-caches) (scroll to the Cassandra section).

## Semantic LLM Cache[​](#semantic-llm-cache "Direct link to Semantic LLM Cache")

```
from langchain.globals import set_llm_cache  
from langchain_community.cache import CassandraSemanticCache  
set_llm_cache(CassandraSemanticCache(  
    embedding=my_embedding,  
    table_name="my_store",  
))  

```

**API Reference:**[set\_llm\_cache](https://python.langchain.com/api_reference/langchain/globals/langchain.globals.set_llm_cache.html) | [CassandraSemanticCache](https://python.langchain.com/api_reference/community/cache/langchain_community.cache.CassandraSemanticCache.html)

Learn more in the [example notebook](/docs/integrations/llm_caching/#cassandra-caches) (scroll to the appropriate section).

## Document loader[​](#document-loader "Direct link to Document loader")

```
from langchain_community.document_loaders import CassandraLoader  

```

**API Reference:**[CassandraLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.cassandra.CassandraLoader.html)

Learn more in the [example notebook](/docs/integrations/document_loaders/cassandra/).

#### Attribution statement[​](#attribution-statement "Direct link to Attribution statement")

> Apache Cassandra, Cassandra and Apache are either registered trademarks or trademarks of
> the [Apache Software Foundation](http://www.apache.org/) in the United States and/or other countries.

## Toolkit[​](#toolkit "Direct link to Toolkit")

The `Cassandra Database toolkit` enables AI engineers to efficiently integrate agents
with Cassandra data.

```
from langchain_community.agent_toolkits.cassandra_database.toolkit import (  
    CassandraDatabaseToolkit,  
)  

```

**API Reference:**[CassandraDatabaseToolkit](https://python.langchain.com/api_reference/community/agent_toolkits/langchain_community.agent_toolkits.cassandra_database.toolkit.CassandraDatabaseToolkit.html)

Learn more in the [example notebook](/docs/integrations/tools/cassandra_database/).

Cassandra Database individual tools:

### Get Schema[​](#get-schema "Direct link to Get Schema")

Tool for getting the schema of a keyspace in an Apache Cassandra database.

```
from langchain_community.tools import GetSchemaCassandraDatabaseTool  

```

### Get Table Data[​](#get-table-data "Direct link to Get Table Data")

Tool for getting data from a table in an Apache Cassandra database.

```
from langchain_community.tools import GetTableDataCassandraDatabaseTool  

```

### Query[​](#query "Direct link to Query")

Tool for querying an Apache Cassandra database with provided CQL.

```
from langchain_community.tools import QueryCassandraDatabaseTool  

```

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/cassandra.mdx)