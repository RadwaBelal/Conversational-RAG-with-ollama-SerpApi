# Source: https://python.langchain.com/docs/integrations/providers/connery/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Connery

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/connery.mdx)

# Connery

> [Connery SDK](https://github.com/connery-io/connery-sdk) is an NPM package that
> includes both an SDK and a CLI, designed for the development of plugins and actions.
>
> The CLI automates many things in the development process. The SDK
> offers a JavaScript API for defining plugins and actions and packaging them
> into a plugin server with a standardized REST API generated from the metadata.
> The plugin server handles authorization, input validation, and logging.
> So you can focus on the logic of your actions.
>
> See the use cases and examples in the [Connery SDK documentation](https://sdk.connery.io/docs/use-cases/)

## Toolkit[​](#toolkit "Direct link to Toolkit")

See [usage example](/docs/integrations/tools/connery/).

```
from langchain_community.agent_toolkits.connery import ConneryToolkit  

```

**API Reference:**[ConneryToolkit](https://python.langchain.com/api_reference/community/agent_toolkits/langchain_community.agent_toolkits.connery.toolkit.ConneryToolkit.html)

## Tools[​](#tools "Direct link to Tools")

### ConneryAction[​](#conneryaction "Direct link to ConneryAction")

```
from langchain_community.tools.connery import ConneryService  

```

**API Reference:**[ConneryService](https://python.langchain.com/api_reference/community/tools/langchain_community.tools.connery.service.ConneryService.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/connery.mdx)