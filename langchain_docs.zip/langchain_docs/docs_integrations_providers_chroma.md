# Source: https://python.langchain.com/docs/integrations/providers/chroma/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Chroma

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/chroma.mdx)

# Chroma

> [Chroma](https://docs.trychroma.com/getting-started) is a database for building AI applications with embeddings.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

```
pip install langchain-chroma  

```

## VectorStore[​](#vectorstore "Direct link to VectorStore")

There exists a wrapper around Chroma vector databases, allowing you to use it as a vectorstore,
whether for semantic search or example selection.

```
from langchain_chroma import Chroma  

```

For a more detailed walkthrough of the Chroma wrapper, see [this notebook](/docs/integrations/vectorstores/chroma/)

## Retriever[​](#retriever "Direct link to Retriever")

See a [usage example](/docs/integrations/retrievers/self_query/chroma_self_query/).

```
from langchain.retrievers import SelfQueryRetriever  

```

**API Reference:**[SelfQueryRetriever](https://python.langchain.com/api_reference/langchain/retrievers/langchain.retrievers.self_query.base.SelfQueryRetriever.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/chroma.mdx)