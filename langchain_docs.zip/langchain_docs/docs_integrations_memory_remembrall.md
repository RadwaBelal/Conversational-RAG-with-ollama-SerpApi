# Source: https://python.langchain.com/docs/integrations/memory/remembrall/

* [Components](/docs/integrations/components/)
* Other
* [Message histories](/docs/integrations/memory/)
* Remembrall

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/memory/remembrall.md)

# Remembrall

This page covers how to use the [Remembrall](https://remembrall.dev) ecosystem within LangChain.

## What is Remembrall?[​](#what-is-remembrall "Direct link to What is Remembrall?")

Remembrall gives your language model long-term memory, retrieval augmented generation, and complete observability with just a few lines of code.

![Screenshot of the Remembrall dashboard showing request statistics and model interactions.](/assets/images/RemembrallDashboard-0100fe50b3bc6728c8861c07f9bb2a1a.png "Remembrall Dashboard Interface")

It works as a light-weight proxy on top of your OpenAI calls and simply augments the context of the chat calls at runtime with relevant facts that have been collected.

## Setup[​](#setup "Direct link to Setup")

To get started, [sign in with Github on the Remembrall platform](https://remembrall.dev/login) and copy your [API key from the settings page](https://remembrall.dev/dashboard/settings).

Any request that you send with the modified `openai_api_base` (see below) and Remembrall API key will automatically be tracked in the Remembrall dashboard. You **never** have to share your OpenAI key with our platform and this information is **never** stored by the Remembrall systems.

To do this, we need to install the following dependencies:

```
pip install -U langchain-openai  

```

### Enable Long Term Memory[​](#enable-long-term-memory "Direct link to Enable Long Term Memory")

In addition to setting the `openai_api_base` and Remembrall API key via `x-gp-api-key`, you should specify a UID to maintain memory for. This will usually be a unique user identifier (like email).

```
from langchain_openai import ChatOpenAI  
chat_model = ChatOpenAI(openai_api_base="https://remembrall.dev/api/openai/v1",  
                        model_kwargs={  
                            "headers":{  
                                "x-gp-api-key": "remembrall-api-key-here",  
                                "x-gp-remember": "user@email.com",  
                            }  
                        })  
  
chat_model.predict("My favorite color is blue.")  
import time; time.sleep(5)  # wait for system to save fact via auto save  
print(chat_model.predict("What is my favorite color?"))  

```

**API Reference:**[ChatOpenAI](https://python.langchain.com/api_reference/openai/chat_models/langchain_openai.chat_models.base.ChatOpenAI.html)

### Enable Retrieval Augmented Generation[​](#enable-retrieval-augmented-generation "Direct link to Enable Retrieval Augmented Generation")

First, create a document context in the [Remembrall dashboard](https://remembrall.dev/dashboard/spells). Paste in the document texts or upload documents as PDFs to be processed. Save the Document Context ID and insert it as shown below.

```
from langchain_openai import ChatOpenAI  
chat_model = ChatOpenAI(openai_api_base="https://remembrall.dev/api/openai/v1",  
                        model_kwargs={  
                            "headers":{  
                                "x-gp-api-key": "remembrall-api-key-here",  
                                "x-gp-context": "document-context-id-goes-here",  
                            }  
                        })  
  
print(chat_model.predict("This is a question that can be answered with my document."))  

```

**API Reference:**[ChatOpenAI](https://python.langchain.com/api_reference/openai/chat_models/langchain_openai.chat_models.base.ChatOpenAI.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/memory/remembrall.md)