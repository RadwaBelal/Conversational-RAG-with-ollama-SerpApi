# Source: https://python.langchain.com/docs/how_to/summarize_stuff/

* [How-to guides](/docs/how_to/)
* How to summarize text in a single LLM call

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/how_to/summarize_stuff.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/how_to/summarize_stuff.ipynb)

# How to summarize text in a single LLM call

LLMs can summarize and otherwise distill desired information from text, including large volumes of text. In many cases, especially for models with larger context windows, this can be adequately achieved via a single LLM call.

LangChain implements a simple [pre-built chain](https://python.langchain.com/api_reference/langchain/chains/langchain.chains.combine_documents.stuff.create_stuff_documents_chain.html) that "stuffs" a prompt with the desired context for summarization and other purposes. In this guide we demonstrate how to use the chain.

## Load chat model[​](#load-chat-model "Direct link to Load chat model")

Let's first load a [chat model](/docs/concepts/chat_models/):

Select [chat model](/docs/integrations/chat/):

OpenAI▾

- [OpenAI](#)
- [Anthropic](#)
- [Azure](#)
- [Google Gemini](#)
- [Google Vertex](#)
- [AWS](#)
- [Groq](#)
- [Cohere](#)
- [NVIDIA](#)
- [Fireworks AI](#)
- [Mistral AI](#)
- [Together AI](#)
- [IBM watsonx](#)
- [Databricks](#)
- [xAI](#)
- [Perplexity](#)

```
pip install -qU "langchain[openai]"  

```

```
import getpass  
import os  
  
if not os.environ.get("OPENAI_API_KEY"):  
  os.environ["OPENAI_API_KEY"] = getpass.getpass("Enter API key for OpenAI: ")  
  
from langchain.chat_models import init_chat_model  
  
llm = init_chat_model("gpt-4o-mini", model_provider="openai")  

```

## Load documents[​](#load-documents "Direct link to Load documents")

Next, we need some documents to summarize. Below, we generate some toy documents for illustrative purposes. See the document loader [how-to guides](/docs/how_to/#document-loaders) and [integration pages](/docs/integrations/document_loaders/) for additional sources of data. The [summarization tutorial](/docs/tutorials/summarization/) also includes an example summarizing a blog post.

```
from langchain_core.documents import Document  
  
documents = [  
    Document(page_content="Apples are red", metadata={"title": "apple_book"}),  
    Document(page_content="Blueberries are blue", metadata={"title": "blueberry_book"}),  
    Document(page_content="Bananas are yelow", metadata={"title": "banana_book"}),  
]  

```

**API Reference:**[Document](https://python.langchain.com/api_reference/core/documents/langchain_core.documents.base.Document.html)

## Load chain[​](#load-chain "Direct link to Load chain")

Below, we define a simple prompt and instantiate the chain with our chat model and documents:

```
from langchain.chains.combine_documents import create_stuff_documents_chain  
from langchain_core.prompts import ChatPromptTemplate  
  
prompt = ChatPromptTemplate.from_template("Summarize this content: {context}")  
chain = create_stuff_documents_chain(llm, prompt)  

```

**API Reference:**[create\_stuff\_documents\_chain](https://python.langchain.com/api_reference/langchain/chains/langchain.chains.combine_documents.stuff.create_stuff_documents_chain.html) | [ChatPromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.chat.ChatPromptTemplate.html)

## Invoke chain[​](#invoke-chain "Direct link to Invoke chain")

Because the chain is a [Runnable](/docs/concepts/runnables/), it implements the usual methods for invocation:

```
result = chain.invoke({"context": documents})  
result  

```

```
'The content describes the colors of three fruits: apples are red, blueberries are blue, and bananas are yellow.'  

```

### Streaming[​](#streaming "Direct link to Streaming")

Note that the chain also supports streaming of individual output tokens:

```
for chunk in chain.stream({"context": documents}):  
    print(chunk, end="|")  

```

```
|The| content| describes| the| colors| of| three| fruits|:| apples| are| red|,| blueberries| are| blue|,| and| bananas| are| yellow|.||  

```

## Next steps[​](#next-steps "Direct link to Next steps")

See the summarization [how-to guides](/docs/how_to/#summarization) for additional summarization strategies, including those designed for larger volumes of text.

See also [this tutorial](/docs/tutorials/summarization/) for more detail on summarization.

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/how_to/summarize_stuff.ipynb)