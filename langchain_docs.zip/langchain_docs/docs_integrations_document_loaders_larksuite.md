# Source: https://python.langchain.com/docs/integrations/document_loaders/larksuite/

* [Components](/docs/integrations/components/)
* [Document loaders](/docs/integrations/document_loaders/)
* LarkSuite (FeiShu)

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/larksuite.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/larksuite.ipynb)

# LarkSuite (FeiShu)

> [LarkSuite](https://www.larksuite.com/) is an enterprise collaboration platform developed by ByteDance.

This notebook covers how to load data from the `LarkSuite` REST API into a format that can be ingested into LangChain, along with example usage for text summarization.

The LarkSuite API requires an access token (tenant\_access\_token or user\_access\_token), checkout [LarkSuite open platform document](https://open.larksuite.com/document) for API details.

```
from getpass import getpass  
  
from langchain_community.document_loaders.larksuite import (  
    LarkSuiteDocLoader,  
    LarkSuiteWikiLoader,  
)  
  
DOMAIN = input("larksuite domain")  
ACCESS_TOKEN = getpass("larksuite tenant_access_token or user_access_token")  
DOCUMENT_ID = input("larksuite document id")  

```

**API Reference:**[LarkSuiteDocLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.larksuite.LarkSuiteDocLoader.html) | [LarkSuiteWikiLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.larksuite.LarkSuiteWikiLoader.html)

## Load From Document[​](#load-from-document "Direct link to Load From Document")

```
from pprint import pprint  
  
larksuite_loader = LarkSuiteDocLoader(DOMAIN, ACCESS_TOKEN, DOCUMENT_ID)  
docs = larksuite_loader.load()  
  
pprint(docs)  

```

```
[Document(page_content='Test Doc\nThis is a Test Doc\n\n1\n2\n3\n\n', metadata={'document_id': 'V76kdbd2HoBbYJxdiNNccajunPf', 'revision_id': 11, 'title': 'Test Doc'})]  

```

## Load From Wiki[​](#load-from-wiki "Direct link to Load From Wiki")

```
from pprint import pprint  
  
DOCUMENT_ID = input("larksuite wiki id")  
larksuite_loader = LarkSuiteWikiLoader(DOMAIN, ACCESS_TOKEN, DOCUMENT_ID)  
docs = larksuite_loader.load()  
  
pprint(docs)  

```

```
[Document(page_content='Test doc\nThis is a test wiki doc.\n', metadata={'document_id': 'TxOKdtMWaoSTDLxYS4ZcdEI7nwc', 'revision_id': 15, 'title': 'Test doc'})]  

```

```
# see https://python.langchain.com/docs/use_cases/summarization for more details  
from langchain.chains.summarize import load_summarize_chain  
from langchain_community.llms.fake import FakeListLLM  
  
llm = FakeListLLM()  
chain = load_summarize_chain(llm, chain_type="map_reduce")  
chain.run(docs)  

```

**API Reference:**[load\_summarize\_chain](https://python.langchain.com/api_reference/langchain/chains/langchain.chains.summarize.chain.load_summarize_chain.html) | [FakeListLLM](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.fake.FakeListLLM.html)

## Related[​](#related "Direct link to Related")

* Document loader [conceptual guide](/docs/concepts/document_loaders/)
* Document loader [how-to guides](/docs/how_to/#document-loaders)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/larksuite.ipynb)