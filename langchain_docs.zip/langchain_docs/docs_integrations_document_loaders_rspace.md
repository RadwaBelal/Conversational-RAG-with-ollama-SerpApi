# Source: https://python.langchain.com/docs/integrations/document_loaders/rspace/

* [Components](/docs/integrations/components/)
* [Document loaders](/docs/integrations/document_loaders/)
* rspace

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/rspace.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/rspace.ipynb)

# rspace

This notebook shows how to use the RSpace document loader to import research notes and documents from RSpace Electronic
Lab Notebook into Langchain pipelines.

To start you'll need an RSpace account and an API key.

You can set up a free account at <https://community.researchspace.com> or use your institutional RSpace.

You can get an RSpace API token from your account's profile page.

```
%pip install --upgrade --quiet  rspace_client  

```

It's best to store your RSpace API key as an environment variable.

RSPACE\_API\_KEY=<YOUR\_KEY>

You'll also need to set the URL of your RSpace installation e.g.

RSPACE\_URL=<https://community.researchspace.com>

If you use these exact environment variable names, they will be detected automatically.

```
from langchain_community.document_loaders.rspace import RSpaceLoader  

```

**API Reference:**[RSpaceLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.rspace.RSpaceLoader.html)

You can import various items from RSpace:

* A single RSpace structured or basic document. This will map 1-1 to a Langchain document.
* A folder or noteook. All documents inside the notebook or folder are imported as Langchain documents.
* If you have PDF files in the RSpace Gallery, these can be imported individually as well. Under the hood, Langchain's PDF loader will be used and this creates one Langchain document per PDF page.

```
## replace these ids with some from your own research notes.  
## Make sure to use  global ids (with the 2 character prefix). This helps the loader know which API calls to make  
## to RSpace API.  
  
rspace_ids = ["NB1932027", "FL1921314", "SD1932029", "GL1932384"]  
for rs_id in rspace_ids:  
    loader = RSpaceLoader(global_id=rs_id)  
    docs = loader.load()  
    for doc in docs:  
        ## the name and ID are added to the 'source' metadata property.  
        print(doc.metadata)  
        print(doc.page_content[:500])  

```

If you don't want to use the environment variables as above, you can pass these into the RSpaceLoader

```
loader = RSpaceLoader(  
    global_id=rs_id, api_key="MY_API_KEY", url="https://my.researchspace.com"  
)  

```

## Related[​](#related "Direct link to Related")

* Document loader [conceptual guide](/docs/concepts/document_loaders/)
* Document loader [how-to guides](/docs/how_to/#document-loaders)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/rspace.ipynb)