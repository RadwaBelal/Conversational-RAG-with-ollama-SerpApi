# Source: https://python.langchain.com/docs/integrations/document_loaders/acreom/

* [Components](/docs/integrations/components/)
* [Document loaders](/docs/integrations/document_loaders/)
* acreom

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/acreom.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/acreom.ipynb)

# acreom

[acreom](https://acreom.com) is a dev-first knowledge base with tasks running on local markdown files.

Below is an example on how to load a local acreom vault into Langchain. As the local vault in acreom is a folder of plain text .md files, the loader requires the path to the directory.

Vault files may contain some metadata which is stored as a YAML header. These values will be added to the document’s metadata if `collect_metadata` is set to true.

```
from langchain_community.document_loaders import AcreomLoader  

```

**API Reference:**[AcreomLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.acreom.AcreomLoader.html)

```
loader = AcreomLoader("<path-to-acreom-vault>", collect_metadata=False)  

```

```
docs = loader.load()  

```

## Related[​](#related "Direct link to Related")

* Document loader [conceptual guide](/docs/concepts/document_loaders/)
* Document loader [how-to guides](/docs/how_to/#document-loaders)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/acreom.ipynb)