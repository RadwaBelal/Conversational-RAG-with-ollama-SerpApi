# Source: https://python.langchain.com/docs/integrations/document_loaders/

* [Components](/docs/integrations/components/)
* Document loaders

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/index.mdx)

# Document loaders



DocumentLoaders load data into the standard LangChain Document format.

Each DocumentLoader has its own specific parameters, but they can all be invoked in the same way with the .load method.
An example use case is as follows:

```
from langchain_community.document_loaders.csv_loader import CSVLoader  
  
loader = CSVLoader(  
    ...  # <-- Integration specific parameters here  
)  
data = loader.load()  

```

**API Reference:**[CSVLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.csv_loader.CSVLoader.html)

## Webpages[​](#webpages "Direct link to Webpages")

The below document loaders allow you to load webpages.

See this guide for a starting point: [How to: load web pages](/docs/how_to/document_loader_web/).

| Document Loader | Description | Package/API |
| --- | --- | --- |
| [Web](web_base) | Uses urllib and BeautifulSoup to load and parse HTML web pages | Package |
| [Unstructured](unstructured_file) | Uses Unstructured to load and parse web pages | Package |
| [RecursiveURL](recursive_url) | Recursively scrapes all child links from a root URL | Package |
| [Sitemap](sitemap) | Scrapes all pages on a given sitemap | Package |
| [Firecrawl](firecrawl) | API service that can be deployed locally, hosted version has free credits. | API |
| [Docling](docling) | Uses Docling to load and parse web pages | Package |
| [Hyperbrowser](hyperbrowser) | Platform for running and scaling headless browsers, can be used to scrape/crawl any site | API |
| [AgentQL](agentql) | Web interaction and structured data extraction from any web page using an AgentQL query or a Natural Language prompt | API |

## PDFs[​](#pdfs "Direct link to PDFs")

The below document loaders allow you to load PDF documents.

See this guide for a starting point: [How to: load PDF files](/docs/how_to/document_loader_pdf/).

| Document Loader | Description | Package/API |
| --- | --- | --- |
| [PyPDF](pypdfloader) | Uses `pypdf` to load and parse PDFs | Package |
| [Unstructured](unstructured_file) | Uses Unstructured's open source library to load PDFs | Package |
| [Amazon Textract](amazon_textract) | Uses AWS API to load PDFs | API |
| [MathPix](mathpix) | Uses MathPix to load PDFs | Package |
| [PDFPlumber](pdfplumber) | Load PDF files using PDFPlumber | Package |
| [PyPDFDirectry](pypdfdirectory) | Load a directory with PDF files | Package |
| [PyPDFium2](pypdfium2) | Load PDF files using PyPDFium2 | Package |
| [PyMuPDF](pymupdf) | Load PDF files using PyMuPDF | Package |
| [PyMuPDF4LLM](pymupdf4llm) | Load PDF content to Markdown using PyMuPDF4LLM | Package |
| [PDFMiner](pdfminer) | Load PDF files using PDFMiner | Package |
| [Upstage Document Parse Loader](upstage) | Load PDF files using UpstageDocumentParseLoader | Package |
| [Docling](docling) | Load PDF files using Docling | Package |

## Cloud Providers[​](#cloud-providers "Direct link to Cloud Providers")

The below document loaders allow you to load documents from your favorite cloud providers.

| Document Loader | Description | Partner Package | API reference |
| --- | --- | --- | --- |
| [AWS S3 Directory](aws_s3_directory) | Load documents from an AWS S3 directory | ❌ | [S3DirectoryLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.s3_directory.S3DirectoryLoader.html) |
| [AWS S3 File](aws_s3_file) | Load documents from an AWS S3 file | ❌ | [S3FileLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.s3_file.S3FileLoader.html) |
| [Azure AI Data](azure_ai_data) | Load documents from Azure AI services | ❌ | [AzureAIDataLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.azure_ai_data.AzureAIDataLoader.html) |
| [Azure Blob Storage Container](azure_blob_storage_container) | Load documents from an Azure Blob Storage container | ❌ | [AzureBlobStorageContainerLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.azure_blob_storage_container.AzureBlobStorageContainerLoader.html) |
| [Azure Blob Storage File](azure_blob_storage_file) | Load documents from an Azure Blob Storage file | ❌ | [AzureBlobStorageFileLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.azure_blob_storage_file.AzureBlobStorageFileLoader.html) |
| [Dropbox](dropbox) | Load documents from Dropbox | ❌ | [DropboxLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.dropbox.DropboxLoader.html) |
| [Google Cloud Storage Directory](google_cloud_storage_directory) | Load documents from GCS bucket | ✅ | [GCSDirectoryLoader](https://python.langchain.com/api_reference/google_community/gcs_directory/langchain_google_community.gcs_directory.GCSDirectoryLoader.html) |
| [Google Cloud Storage File](google_cloud_storage_file) | Load documents from GCS file object | ✅ | [GCSFileLoader](https://python.langchain.com/api_reference/google_community/gcs_file/langchain_google_community.gcs_file.GCSFileLoader.html) |
| [Google Drive](google_drive) | Load documents from Google Drive (Google Docs only) | ✅ | [GoogleDriveLoader](https://python.langchain.com/api_reference/google_community/drive/langchain_google_community.drive.GoogleDriveLoader.html) |
| [Huawei OBS Directory](huawei_obs_directory) | Load documents from Huawei Object Storage Service Directory | ❌ | [OBSDirectoryLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.obs_directory.OBSDirectoryLoader.html) |
| [Huawei OBS File](huawei_obs_file) | Load documents from Huawei Object Storage Service File | ❌ | [OBSFileLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.obs_file.OBSFileLoader.html) |
| [Microsoft OneDrive](microsoft_onedrive) | Load documents from Microsoft OneDrive | ❌ | [OneDriveLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.onedrive.OneDriveLoader.html) |
| [Microsoft SharePoint](microsoft_sharepoint) | Load documents from Microsoft SharePoint | ❌ | [SharePointLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.sharepoint.SharePointLoader.html) |
| [Tencent COS Directory](tencent_cos_directory) | Load documents from Tencent Cloud Object Storage Directory | ❌ | [TencentCOSDirectoryLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.tencent_cos_directory.TencentCOSDirectoryLoader.html) |
| [Tencent COS File](tencent_cos_file) | Load documents from Tencent Cloud Object Storage File | ❌ | [TencentCOSFileLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.tencent_cos_file.TencentCOSFileLoader.html) |

## Social Platforms[​](#social-platforms "Direct link to Social Platforms")

The below document loaders allow you to load documents from different social media platforms.

| Document Loader | API reference |
| --- | --- |
| [Twitter](twitter) | [TwitterTweetLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.twitter.TwitterTweetLoader.html) |
| [Reddit](RedditPostsLoader) | [RedditPostsLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.reddit.RedditPostsLoader.html) |

## Messaging Services[​](#messaging-services "Direct link to Messaging Services")

The below document loaders allow you to load data from different messaging platforms.

| Document Loader | API reference |
| --- | --- |
| [Telegram](telegram) | [TelegramChatFileLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.telegram.TelegramChatFileLoader.html) |
| [WhatsApp](whatsapp_chat) | [WhatsAppChatLoader](https://python.langchain.com/api_reference/community/chat_loaders/langchain_community.chat_loaders.whatsapp.WhatsAppChatLoader.html) |
| [Discord](discord) | [DiscordChatLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.discord.DiscordChatLoader.html) |
| [Facebook Chat](facebook_chat) | [FacebookChatLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.facebook_chat.FacebookChatLoader.html) |
| [Mastodon](mastodon) | [MastodonTootsLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.mastodon.MastodonTootsLoader.html) |

## Productivity tools[​](#productivity-tools "Direct link to Productivity tools")

The below document loaders allow you to load data from commonly used productivity tools.

| Document Loader | API reference |
| --- | --- |
| [Figma](figma) | [FigmaFileLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.figma.FigmaFileLoader.html) |
| [Notion](notion) | [NotionDirectoryLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.notion.NotionDirectoryLoader.html) |
| [Slack](slack) | [SlackDirectoryLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.slack_directory.SlackDirectoryLoader.html) |
| [Quip](quip) | [QuipLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.quip.QuipLoader.html) |
| [Trello](trello) | [TrelloLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.trello.TrelloLoader.html) |
| [Roam](roam) | [RoamLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.roam.RoamLoader.html) |
| [GitHub](github) | [GithubFileLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.github.GithubFileLoader.html) |

## Common File Types[​](#common-file-types "Direct link to Common File Types")

The below document loaders allow you to load data from common data formats.

| Document Loader | Data Type |
| --- | --- |
| [CSVLoader](csv) | CSV files |
| [DirectoryLoader](../../how_to/document_loader_directory) | All files in a given directory |
| [Unstructured](unstructured_file) | Many file types (see https://docs.unstructured.io/platform/supported-file-types) |
| [JSONLoader](json) | JSON files |
| [BSHTMLLoader](bshtml) | HTML files |
| [DoclingLoader](../../integrations/document_loaders/docling) | Various file types (see https://ds4sd.github.io/docling/) |

## All document loaders[​](#all-document-loaders "Direct link to All document loaders")

| Name | Description |
| --- | --- |
| [acreom](/docs/integrations/document_loaders/acreom) | acreom is a dev-first knowledge base with tasks running on local mark... |
| [AgentQLLoader](/docs/integrations/document_loaders/agentql) | AgentQL's document loader provides structured data extraction from an... |
| [AirbyteLoader](/docs/integrations/document_loaders/airbyte) | Airbyte is a data integration platform for ELT pipelines from APIs, d... |
| [Airtable](/docs/integrations/document_loaders/airtable) | \* Get your API key here. |
| [Alibaba Cloud MaxCompute](/docs/integrations/document_loaders/alibaba_cloud_maxcompute) | Alibaba Cloud MaxCompute (previously known as ODPS) is a general purp... |
| [Amazon Textract](/docs/integrations/document_loaders/amazon_textract) | Amazon Textract is a machine learning (ML) service that automatically... |
| [Apify Dataset](/docs/integrations/document_loaders/apify_dataset) | Apify Dataset is a scalable append-only storage with sequential acces... |
| [ArcGIS](/docs/integrations/document_loaders/arcgis) | This notebook demonstrates the use of the langchaincommunity.document... |
| [ArxivLoader](/docs/integrations/document_loaders/arxiv) | arXiv is an open-access archive for 2 million scholarly articles in t... |
| [AssemblyAI Audio Transcripts](/docs/integrations/document_loaders/assemblyai) | The AssemblyAIAudioTranscriptLoader allows to transcribe audio files ... |
| [AstraDB](/docs/integrations/document_loaders/astradb) | DataStax Astra DB is a serverless |
| [Async Chromium](/docs/integrations/document_loaders/async_chromium) | Chromium is one of the browsers supported by Playwright, a library us... |
| [AsyncHtml](/docs/integrations/document_loaders/async_html) | AsyncHtmlLoader loads raw HTML from a list of URLs concurrently. |
| [Athena](/docs/integrations/document_loaders/athena) | Amazon Athena is a serverless, interactive analytics service built |
| [AWS S3 Directory](/docs/integrations/document_loaders/aws_s3_directory) | Amazon Simple Storage Service (Amazon S3) is an object storage service |
| [AWS S3 File](/docs/integrations/document_loaders/aws_s3_file) | Amazon Simple Storage Service (Amazon S3) is an object storage servic... |
| [AZLyrics](/docs/integrations/document_loaders/azlyrics) | AZLyrics is a large, legal, every day growing collection of lyrics. |
| [Azure AI Data](/docs/integrations/document_loaders/azure_ai_data) | Azure AI Studio provides the capability to upload data assets to clou... |
| [Azure Blob Storage Container](/docs/integrations/document_loaders/azure_blob_storage_container) | Azure Blob Storage is Microsoft's object storage solution for the clo... |
| [Azure Blob Storage File](/docs/integrations/document_loaders/azure_blob_storage_file) | Azure Files offers fully managed file shares in the cloud that are ac... |
| [Azure AI Document Intelligence](/docs/integrations/document_loaders/azure_document_intelligence) | Azure AI Document Intelligence (formerly known as Azure Form Recogniz... |
| [BibTeX](/docs/integrations/document_loaders/bibtex) | BibTeX is a file format and reference management system commonly used... |
| [BiliBili](/docs/integrations/document_loaders/bilibili) | Bilibili is one of the most beloved long-form video sites in China. |
| [Blackboard](/docs/integrations/document_loaders/blackboard) | Blackboard Learn (previously the Blackboard Learning Management Syste... |
| [Blockchain](/docs/integrations/document_loaders/blockchain) | Overview |
| [Box](/docs/integrations/document_loaders/box) | The langchain-box package provides two methods to index your files fr... |
| [Brave Search](/docs/integrations/document_loaders/brave_search) | Brave Search is a search engine developed by Brave Software. |
| [Browserbase](/docs/integrations/document_loaders/browserbase) | Browserbase is a developer platform to reliably run, manage, and moni... |
| [Browserless](/docs/integrations/document_loaders/browserless) | Browserless is a service that allows you to run headless Chrome insta... |
| [BSHTMLLoader](/docs/integrations/document_loaders/bshtml) | This notebook provides a quick overview for getting started with Beau... |
| [Cassandra](/docs/integrations/document_loaders/cassandra) | Cassandra is a NoSQL, row-oriented, highly scalable and highly availa... |
| [ChatGPT Data](/docs/integrations/document_loaders/chatgpt_loader) | ChatGPT is an artificial intelligence (AI) chatbot developed by OpenA... |
| [College Confidential](/docs/integrations/document_loaders/college_confidential) | College Confidential gives information on 3,800+ colleges and univers... |
| [Concurrent Loader](/docs/integrations/document_loaders/concurrent) | Works just like the GenericLoader but concurrently for those who choo... |
| [Confluence](/docs/integrations/document_loaders/confluence) | Confluence is a wiki collaboration platform that saves and organizes ... |
| [CoNLL-U](/docs/integrations/document_loaders/conll-u) | CoNLL-U is revised version of the CoNLL-X format. Annotations are enc... |
| [Copy Paste](/docs/integrations/document_loaders/copypaste) | This notebook covers how to load a document object from something you... |
| [Couchbase](/docs/integrations/document_loaders/couchbase) | Couchbase is an award-winning distributed NoSQL cloud database that d... |
| [CSV](/docs/integrations/document_loaders/csv) | A comma-separated values (CSV) file is a delimited text file that use... |
| [Cube Semantic Layer](/docs/integrations/document_loaders/cube_semantic) | This notebook demonstrates the process of retrieving Cube's data mode... |
| [Datadog Logs](/docs/integrations/document_loaders/datadog_logs) | Datadog is a monitoring and analytics platform for cloud-scale applic... |
| [Dedoc](/docs/integrations/document_loaders/dedoc) | This sample demonstrates the use of Dedoc in combination with LangCha... |
| [Diffbot](/docs/integrations/document_loaders/diffbot) | Diffbot is a suite of ML-based products that make it easy to structur... |
| [Discord](/docs/integrations/document_loaders/discord) | Discord is a VoIP and instant messaging social platform. Users have t... |
| [Docling](/docs/integrations/document_loaders/docling) | Docling parses PDF, DOCX, PPTX, HTML, and other formats into a rich u... |
| [Docugami](/docs/integrations/document_loaders/docugami) | This notebook covers how to load documents from Docugami. It provides... |
| [Docusaurus](/docs/integrations/document_loaders/docusaurus) | Docusaurus is a static-site generator which provides out-of-the-box d... |
| [Dropbox](/docs/integrations/document_loaders/dropbox) | Dropbox is a file hosting service that brings everything-traditional ... |
| [DuckDB](/docs/integrations/document_loaders/duckdb) | DuckDB is an in-process SQL OLAP database management system. |
| [Email](/docs/integrations/document_loaders/email) | This notebook shows how to load email (.eml) or Microsoft Outlook (.m... |
| [EPub](/docs/integrations/document_loaders/epub) | EPUB is an e-book file format that uses the ".epub" file extension. T... |
| [Etherscan](/docs/integrations/document_loaders/etherscan) | Etherscan is the leading blockchain explorer, search, API and analyt... |
| [EverNote](/docs/integrations/document_loaders/evernote) | EverNote is intended for archiving and creating notes in which photos... |
| example\_data |  |
| [Facebook Chat](/docs/integrations/document_loaders/facebook_chat) | Messenger) is an American proprietary instant messaging app and platf... |
| [Fauna](/docs/integrations/document_loaders/fauna) | Fauna is a Document Database. |
| [Figma](/docs/integrations/document_loaders/figma) | Figma is a collaborative web application for interface design. |
| [FireCrawl](/docs/integrations/document_loaders/firecrawl) | FireCrawl crawls and convert any website into LLM-ready data. It craw... |
| [Geopandas](/docs/integrations/document_loaders/geopandas) | Geopandas is an open-source project to make working with geospatial d... |
| [Git](/docs/integrations/document_loaders/git) | Git is a distributed version control system that tracks changes in an... |
| [GitBook](/docs/integrations/document_loaders/gitbook) | GitBook is a modern documentation platform where teams can document e... |
| [GitHub](/docs/integrations/document_loaders/github) | This notebooks shows how you can load issues and pull requests (PRs) ... |
| [Glue Catalog](/docs/integrations/document_loaders/glue_catalog) | The AWS Glue Data Catalog is a centralized metadata repository that a... |
| [Google AlloyDB for PostgreSQL](/docs/integrations/document_loaders/google_alloydb) | AlloyDB is a fully managed relational database service that offers hi... |
| [Google BigQuery](/docs/integrations/document_loaders/google_bigquery) | Google BigQuery is a serverless and cost-effective enterprise data wa... |
| [Google Bigtable](/docs/integrations/document_loaders/google_bigtable) | Bigtable is a key-value and wide-column store, ideal for fast access ... |
| [Google Cloud SQL for SQL server](/docs/integrations/document_loaders/google_cloud_sql_mssql) | Cloud SQL is a fully managed relational database service that offers ... |
| [Google Cloud SQL for MySQL](/docs/integrations/document_loaders/google_cloud_sql_mysql) | Cloud SQL is a fully managed relational database service that offers ... |
| [Google Cloud SQL for PostgreSQL](/docs/integrations/document_loaders/google_cloud_sql_pg) | Cloud SQL for PostgreSQL is a fully-managed database service that hel... |
| [Google Cloud Storage Directory](/docs/integrations/document_loaders/google_cloud_storage_directory) | Google Cloud Storage is a managed service for storing unstructured da... |
| [Google Cloud Storage File](/docs/integrations/document_loaders/google_cloud_storage_file) | Google Cloud Storage is a managed service for storing unstructured da... |
| [Google Firestore in Datastore Mode](/docs/integrations/document_loaders/google_datastore) | Firestore in Datastore Mode is a NoSQL document database built for au... |
| [Google Drive](/docs/integrations/document_loaders/google_drive) | Google Drive is a file storage and synchronization service developed ... |
| [Google El Carro for Oracle Workloads](/docs/integrations/document_loaders/google_el_carro) | Google El Carro Oracle Operator |
| [Google Firestore (Native Mode)](/docs/integrations/document_loaders/google_firestore) | Firestore is a serverless document-oriented database that scales to m... |
| [Google Memorystore for Redis](/docs/integrations/document_loaders/google_memorystore_redis) | Google Memorystore for Redis is a fully-managed service that is power... |
| [Google Spanner](/docs/integrations/document_loaders/google_spanner) | Spanner is a highly scalable database that combines unlimited scalabi... |
| [Google Speech-to-Text Audio Transcripts](/docs/integrations/document_loaders/google_speech_to_text) | The SpeechToTextLoader allows to transcribe audio files with the Goog... |
| [Grobid](/docs/integrations/document_loaders/grobid) | GROBID is a machine learning library for extracting, parsing, and re-... |
| [Gutenberg](/docs/integrations/document_loaders/gutenberg) | Project Gutenberg is an online library of free eBooks. |
| [Hacker News](/docs/integrations/document_loaders/hacker_news) | Hacker News (sometimes abbreviated as HN) is a social news website fo... |
| [Huawei OBS Directory](/docs/integrations/document_loaders/huawei_obs_directory) | The following code demonstrates how to load objects from the Huawei O... |
| [Huawei OBS File](/docs/integrations/document_loaders/huawei_obs_file) | The following code demonstrates how to load an object from the Huawei... |
| [HuggingFace dataset](/docs/integrations/document_loaders/hugging_face_dataset) | The Hugging Face Hub is home to over 5,000 datasets in more than 100 ... |
| [HyperbrowserLoader](/docs/integrations/document_loaders/hyperbrowser) | Hyperbrowser is a platform for running and scaling headless browsers.... |
| [iFixit](/docs/integrations/document_loaders/ifixit) | iFixit is the largest, open repair community on the web. The site con... |
| [Images](/docs/integrations/document_loaders/image) | This covers how to load images into a document format that we can use... |
| [Image captions](/docs/integrations/document_loaders/image_captions) | By default, the loader utilizes the pre-trained Salesforce BLIP image... |
| [IMSDb](/docs/integrations/document_loaders/imsdb) | IMSDb is the Internet Movie Script Database. |
| [Iugu](/docs/integrations/document_loaders/iugu) | Iugu is a Brazilian services and software as a service (SaaS) company... |
| [Joplin](/docs/integrations/document_loaders/joplin) | Joplin is an open-source note-taking app. Capture your thoughts and s... |
| [JSONLoader](/docs/integrations/document_loaders/json) | This notebook provides a quick overview for getting started with JSON... |
| [Jupyter Notebook](/docs/integrations/document_loaders/jupyter_notebook) | Jupyter Notebook (formerly IPython Notebook) is a web-based interacti... |
| [Kinetica](/docs/integrations/document_loaders/kinetica) | This notebooks goes over how to load documents from Kinetica |
| [lakeFS](/docs/integrations/document_loaders/lakefs) | lakeFS provides scalable version control over the data lake, and uses... |
| [LangSmith](/docs/integrations/document_loaders/langsmith) | This notebook provides a quick overview for getting started with the ... |
| [LarkSuite (FeiShu)](/docs/integrations/document_loaders/larksuite) | LarkSuite is an enterprise collaboration platform developed by ByteDa... |
| [LLM Sherpa](/docs/integrations/document_loaders/llmsherpa) | This notebook covers how to use LLM Sherpa to load files of many type... |
| [Mastodon](/docs/integrations/document_loaders/mastodon) | Mastodon is a federated social media and social networking service. |
| [MathPixPDFLoader](/docs/integrations/document_loaders/mathpix) | Inspired by Daniel Gross's snippet here//gist.github.com/danielgross/... |
| [MediaWiki Dump](/docs/integrations/document_loaders/mediawikidump) | MediaWiki XML Dumps contain the content of a wiki (wiki pages with al... |
| [Merge Documents Loader](/docs/integrations/document_loaders/merge_doc) | Merge the documents returned from a set of specified data loaders. |
| [mhtml](/docs/integrations/document_loaders/mhtml) | MHTML is a is used both for emails but also for archived webpages. MH... |
| [Microsoft Excel](/docs/integrations/document_loaders/microsoft_excel) | The UnstructuredExcelLoader is used to load Microsoft Excel files. Th... |
| [Microsoft OneDrive](/docs/integrations/document_loaders/microsoft_onedrive) | Microsoft OneDrive (formerly SkyDrive) is a file hosting service oper... |
| [Microsoft OneNote](/docs/integrations/document_loaders/microsoft_onenote) | This notebook covers how to load documents from OneNote. |
| [Microsoft PowerPoint](/docs/integrations/document_loaders/microsoft_powerpoint) | Microsoft PowerPoint is a presentation program by Microsoft. |
| [Microsoft SharePoint](/docs/integrations/document_loaders/microsoft_sharepoint) | Microsoft SharePoint is a website-based collaboration system that use... |
| [Microsoft Word](/docs/integrations/document_loaders/microsoft_word) | Microsoft Word is a word processor developed by Microsoft. |
| [Near Blockchain](/docs/integrations/document_loaders/mintbase) | Overview |
| [Modern Treasury](/docs/integrations/document_loaders/modern_treasury) | Modern Treasury simplifies complex payment operations. It is a unifie... |
| [MongoDB](/docs/integrations/document_loaders/mongodb) | MongoDB is a NoSQL , document-oriented database that supports JSON-li... |
| [Needle Document Loader](/docs/integrations/document_loaders/needle) | Needle makes it easy to create your RAG pipelines with minimal effort. |
| [News URL](/docs/integrations/document_loaders/news) | This covers how to load HTML news articles from a list of URLs into a... |
| [Notion DB 2/2](/docs/integrations/document_loaders/notion) | Notion is a collaboration platform with modified Markdown support tha... |
| [Nuclia](/docs/integrations/document_loaders/nuclia) | Nuclia automatically indexes your unstructured data from any internal... |
| [Obsidian](/docs/integrations/document_loaders/obsidian) | Obsidian is a powerful and extensible knowledge base |
| [Open Document Format (ODT)](/docs/integrations/document_loaders/odt) | The Open Document Format for Office Applications (ODF), also known as... |
| [Open City Data](/docs/integrations/document_loaders/open_city_data) | Socrata provides an API for city open data. |
| [Oracle Autonomous Database](/docs/integrations/document_loaders/oracleadb_loader) | Oracle autonomous database is a cloud database that uses machine lear... |
| [Oracle AI Vector Search: Document Processing](/docs/integrations/document_loaders/oracleai) | Oracle AI Vector Search is designed for Artificial Intelligence (AI) ... |
| [Org-mode](/docs/integrations/document_loaders/org_mode) | A Org Mode document is a document editing, formatting, and organizing... |
| [Pandas DataFrame](/docs/integrations/document_loaders/pandas_dataframe) | This notebook goes over how to load data from a pandas DataFrame. |
| parsers |  |
| [PDFMinerLoader](/docs/integrations/document_loaders/pdfminer) | This notebook provides a quick overview for getting started with PDFM... |
| [PDFPlumber](/docs/integrations/document_loaders/pdfplumber) | Like PyMuPDF, the output Documents contain detailed metadata about th... |
| [Pebblo Safe DocumentLoader](/docs/integrations/document_loaders/pebblo) | Pebblo enables developers to safely load data and promote their Gen A... |
| [Polars DataFrame](/docs/integrations/document_loaders/polars_dataframe) | This notebook goes over how to load data from a polars DataFrame. |
| [Dell PowerScale Document Loader](/docs/integrations/document_loaders/powerscale) | Dell PowerScale is an enterprise scale out storage system that hosts ... |
| [Psychic](/docs/integrations/document_loaders/psychic) | This notebook covers how to load documents from Psychic. See here for... |
| [PubMed](/docs/integrations/document_loaders/pubmed) | PubMed® by The National Center for Biotechnology Information, Nationa... |
| [PullMdLoader](/docs/integrations/document_loaders/pull_md) | Loader for converting URLs into Markdown using the pull.md service. |
| [PyMuPDFLoader](/docs/integrations/document_loaders/pymupdf) | This notebook provides a quick overview for getting started with PyMu... |
| [PyMuPDF4LLM](/docs/integrations/document_loaders/pymupdf4llm) | This notebook provides a quick overview for getting started with PyMu... |
| [PyPDFDirectoryLoader](/docs/integrations/document_loaders/pypdfdirectory) | This loader loads all PDF files from a specific directory. |
| [PyPDFium2Loader](/docs/integrations/document_loaders/pypdfium2) | This notebook provides a quick overview for getting started with PyPD... |
| [PyPDFLoader](/docs/integrations/document_loaders/pypdfloader) | This notebook provides a quick overview for getting started with PyPD... |
| [PySpark](/docs/integrations/document_loaders/pyspark_dataframe) | This notebook goes over how to load data from a PySpark DataFrame. |
| [Quip](/docs/integrations/document_loaders/quip) | Quip is a collaborative productivity software suite for mobile and We... |
| [ReadTheDocs Documentation](/docs/integrations/document_loaders/readthedocs_documentation) | Read the Docs is an open-sourced free software documentation hosting ... |
| [Recursive URL](/docs/integrations/document_loaders/recursive_url) | The RecursiveUrlLoader lets you recursively scrape all child links fr... |
| [Reddit](/docs/integrations/document_loaders/reddit) | Reddit is an American social news aggregation, content rating, and di... |
| [Roam](/docs/integrations/document_loaders/roam) | ROAM is a note-taking tool for networked thought, designed to create ... |
| [Rockset](/docs/integrations/document_loaders/rockset) | Rockset is a real-time analytics database which enables queries on ma... |
| [rspace](/docs/integrations/document_loaders/rspace) | This notebook shows how to use the RSpace document loader to import r... |
| [RSS Feeds](/docs/integrations/document_loaders/rss) | This covers how to load HTML news articles from a list of RSS feed UR... |
| [RST](/docs/integrations/document_loaders/rst) | A reStructured Text (RST) file is a file format for textual data used... |
| [scrapfly](/docs/integrations/document_loaders/scrapfly) | ScrapFly |
| [ScrapingAnt](/docs/integrations/document_loaders/scrapingant) | Overview |
| [SingleStore](/docs/integrations/document_loaders/singlestore) | The SingleStoreLoader allows you to load documents directly from a Si... |
| [Sitemap](/docs/integrations/document_loaders/sitemap) | Extends from the WebBaseLoader, SitemapLoader loads a sitemap from a ... |
| [Slack](/docs/integrations/document_loaders/slack) | Slack is an instant messaging program. |
| [Snowflake](/docs/integrations/document_loaders/snowflake) | This notebooks goes over how to load documents from Snowflake |
| [Source Code](/docs/integrations/document_loaders/source_code) | This notebook covers how to load source code files using a special ap... |
| [Spider](/docs/integrations/document_loaders/spider) | Spider is the fastest and most affordable crawler and scraper that re... |
| [Spreedly](/docs/integrations/document_loaders/spreedly) | Spreedly is a service that allows you to securely store credit cards ... |
| [Stripe](/docs/integrations/document_loaders/stripe) | Stripe is an Irish-American financial services and software as a serv... |
| [Subtitle](/docs/integrations/document_loaders/subtitle) | The SubRip file format is described on the Matroska multimedia contai... |
| [SurrealDB](/docs/integrations/document_loaders/surrealdb) | SurrealDB is an end-to-end cloud-native database designed for modern ... |
| [Telegram](/docs/integrations/document_loaders/telegram) | Telegram Messenger is a globally accessible freemium, cross-platform,... |
| [Tencent COS Directory](/docs/integrations/document_loaders/tencent_cos_directory) | Tencent Cloud Object Storage (COS) is a distributed |
| [Tencent COS File](/docs/integrations/document_loaders/tencent_cos_file) | Tencent Cloud Object Storage (COS) is a distributed |
| [TensorFlow Datasets](/docs/integrations/document_loaders/tensorflow_datasets) | TensorFlow Datasets is a collection of datasets ready to use, with Te... |
| [TiDB](/docs/integrations/document_loaders/tidb) | TiDB Cloud, is a comprehensive Database-as-a-Service (DBaaS) solution... |
| [2Markdown](/docs/integrations/document_loaders/tomarkdown) | 2markdown service transforms website content into structured markdown... |
| [TOML](/docs/integrations/document_loaders/toml) | TOML is a file format for configuration files. It is intended to be e... |
| [Trello](/docs/integrations/document_loaders/trello) | Trello is a web-based project management and collaboration tool that ... |
| [TSV](/docs/integrations/document_loaders/tsv) | A tab-separated values (TSV) file is a simple, text-based file format... |
| [Twitter](/docs/integrations/document_loaders/twitter) | Twitter is an online social media and social networking service. |
| [Unstructured](/docs/integrations/document_loaders/unstructured_file) | This notebook covers how to use Unstructured document loader to load ... |
| [UnstructuredMarkdownLoader](/docs/integrations/document_loaders/unstructured_markdown) | This notebook provides a quick overview for getting started with Unst... |
| [UnstructuredPDFLoader](/docs/integrations/document_loaders/unstructured_pdfloader) | Overview |
| [Upstage](/docs/integrations/document_loaders/upstage) | This notebook covers how to get started with UpstageDocumentParseLoad... |
| [URL](/docs/integrations/document_loaders/url) | This example covers how to load HTML documents from a list of URLs in... |
| [Vsdx](/docs/integrations/document_loaders/vsdx) | A visio file (with extension .vsdx) is associated with Microsoft Visi... |
| [Weather](/docs/integrations/document_loaders/weather) | OpenWeatherMap is an open-source weather service provider |
| [WebBaseLoader](/docs/integrations/document_loaders/web_base) | This covers how to use WebBaseLoader to load all text from HTML webpa... |
| [WhatsApp Chat](/docs/integrations/document_loaders/whatsapp_chat) | WhatsApp (also called WhatsApp Messenger) is a freeware, cross-platfo... |
| [Wikipedia](/docs/integrations/document_loaders/wikipedia) | Wikipedia is a multilingual free online encyclopedia written and main... |
| [UnstructuredXMLLoader](/docs/integrations/document_loaders/xml) | This notebook provides a quick overview for getting started with Unst... |
| [Xorbits Pandas DataFrame](/docs/integrations/document_loaders/xorbits) | This notebook goes over how to load data from a xorbits.pandas DataFr... |
| [YouTube audio](/docs/integrations/document_loaders/youtube_audio) | Building chat or QA applications on YouTube videos is a topic of high... |
| [YouTube transcripts](/docs/integrations/document_loaders/youtube_transcript) | YouTube is an online video sharing and social media platform created ... |
| [YoutubeLoaderDL](/docs/integrations/document_loaders/yt_dlp) | Loader for Youtube leveraging the yt-dlp library. |
| [Yuque](/docs/integrations/document_loaders/yuque) | Yuque is a professional cloud-based knowledge base for team collabora... |
| [ZeroxPDFLoader](/docs/integrations/document_loaders/zeroxpdfloader) | Overview |

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/index.mdx)