# Source: https://python.langchain.com/docs/integrations/providers/datadog_logs/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Datadog Logs

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/datadog_logs.mdx)

# Datadog Logs

> [Datadog](https://www.datadoghq.com/) is a monitoring and analytics platform for cloud-scale applications.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

```
pip install datadog_api_client  

```

We must initialize the loader with the Datadog API key and APP key, and we need to set up the query to extract the desired logs.

## Document Loader[​](#document-loader "Direct link to Document Loader")

See a [usage example](/docs/integrations/document_loaders/datadog_logs/).

```
from langchain_community.document_loaders import DatadogLogsLoader  

```

**API Reference:**[DatadogLogsLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.datadog_logs.DatadogLogsLoader.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/datadog_logs.mdx)