# Source: https://python.langchain.com/docs/integrations/providers/deepseek/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* DeepSeek

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/deepseek.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/deepseek.ipynb)

# DeepSeek

[DeepSeek](https://www.deepseek.com/) is a Chinese artificial intelligence company that develops LLMs.

```
from langchain_deepseek import ChatDeepSeek  

```

**API Reference:**[ChatDeepSeek](https://python.langchain.com/api_reference/deepseek/chat_models/langchain_deepseek.chat_models.ChatDeepSeek.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/deepseek.ipynb)