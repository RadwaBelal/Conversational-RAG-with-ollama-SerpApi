# Source: https://python.langchain.com/docs/contributing/how_to/

* How-to guides

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/contributing/how_to/index.mdx)

# How-to Guides

* [**Documentation**](/docs/contributing/how_to/documentation/): Help improve our docs, including this one!
* [**Code**](/docs/contributing/how_to/code/): Help us write code, fix bugs, or improve our infrastructure.

## Integrations[​](#integrations "Direct link to Integrations")

* [**Start Here**](/docs/contributing/how_to/integrations/): Help us integrate with your favorite vendors and tools.
* [**Package**](/docs/contributing/how_to/integrations/package/): Publish an integration package to PyPi
* [**Standard Tests**](/docs/contributing/how_to/integrations/standard_tests/): Ensure your integration passes an expected set of tests.

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/contributing/how_to/index.mdx)