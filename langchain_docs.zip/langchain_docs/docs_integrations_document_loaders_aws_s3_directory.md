# Source: https://python.langchain.com/docs/integrations/document_loaders/aws_s3_directory/

* [Components](/docs/integrations/components/)
* [Document loaders](/docs/integrations/document_loaders/)
* AWS S3 Directory

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/aws_s3_directory.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/aws_s3_directory.ipynb)

# AWS S3 Directory

> [Amazon Simple Storage Service (Amazon S3)](https://docs.aws.amazon.com/AmazonS3/latest/userguide/using-folders.html) is an object storage service

> [AWS S3 Directory](https://docs.aws.amazon.com/AmazonS3/latest/userguide/using-folders.html)

This covers how to load document objects from an `AWS S3 Directory` object.

```
%pip install --upgrade --quiet  boto3  

```

```
from langchain_community.document_loaders import S3DirectoryLoader  

```

**API Reference:**[S3DirectoryLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.s3_directory.S3DirectoryLoader.html)

```
loader = S3DirectoryLoader("testing-hwc")  

```

```
loader.load()  

```

## Specifying a prefix[​](#specifying-a-prefix "Direct link to Specifying a prefix")

You can also specify a prefix for more finegrained control over what files to load.

```
loader = S3DirectoryLoader("testing-hwc", prefix="fake")  

```

```
loader.load()  

```

```
[Document(page_content='Lorem ipsum dolor sit amet.', lookup_str='', metadata={'source': 's3://testing-hwc/fake.docx'}, lookup_index=0)]  

```

## Configuring the AWS Boto3 client[​](#configuring-the-aws-boto3-client "Direct link to Configuring the AWS Boto3 client")

You can configure the AWS [Boto3](https://boto3.amazonaws.com/v1/documentation/api/latest/index.html) client by passing
named arguments when creating the S3DirectoryLoader.
This is useful for instance when AWS credentials can't be set as environment variables.
See the [list of parameters](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/core/session.html#boto3.session.Session) that can be configured.

```
loader = S3DirectoryLoader(  
    "testing-hwc", aws_access_key_id="xxxx", aws_secret_access_key="yyyy"  
)  

```

```
loader.load()  

```

## Related[​](#related "Direct link to Related")

* Document loader [conceptual guide](/docs/concepts/document_loaders/)
* Document loader [how-to guides](/docs/how_to/#document-loaders)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/aws_s3_directory.ipynb)