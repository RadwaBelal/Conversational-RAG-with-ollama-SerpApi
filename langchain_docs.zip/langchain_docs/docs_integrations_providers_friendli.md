# Source: https://python.langchain.com/docs/integrations/providers/friendli/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Friendli AI

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/friendli.mdx)

# Friendli AI

> [FriendliAI](https://friendli.ai/) enhances AI application performance and optimizes
> cost savings with scalable, efficient deployment options, tailored for high-demand AI workloads.

## Installation and setup[​](#installation-and-setup "Direct link to Installation and setup")

Install the `friendli-client` python package.

```
pip install -U langchain_community friendli-client  

```

Sign in to [Friendli Suite](https://suite.friendli.ai/) to create a Personal Access Token,
and set it as the `FRIENDLI_TOKEN` environment variable.

## Chat models[​](#chat-models "Direct link to Chat models")

See a [usage example](/docs/integrations/chat/friendli/).

```
from langchain_community.chat_models.friendli import ChatFriendli  
  
chat = ChatFriendli(model='meta-llama-3.1-8b-instruct')  
  
for m in chat.stream("Tell me fun things to do in NYC"):  
    print(m.content, end="", flush=True)  

```

**API Reference:**[ChatFriendli](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.friendli.ChatFriendli.html)

## LLMs[​](#llms "Direct link to LLMs")

See a [usage example](/docs/integrations/llms/friendli/).

```
from langchain_community.llms.friendli import Friendli  
  
llm = Friendli(model='meta-llama-3.1-8b-instruct')  
  
print(llm.invoke("def bubble_sort(): "))  

```

**API Reference:**[Friendli](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.friendli.Friendli.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/friendli.mdx)