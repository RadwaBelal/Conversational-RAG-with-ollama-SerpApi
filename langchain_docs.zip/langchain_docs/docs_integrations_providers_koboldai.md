# Source: https://python.langchain.com/docs/integrations/providers/koboldai/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* KoboldAI

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/koboldai.mdx)

# KoboldAI

> [KoboldAI](https://koboldai.com/) is a free, open-source project that allows users to run AI models locally
> on their own computer.
> It's a browser-based front-end that can be used for writing or role playing with an AI.
> [KoboldAI](https://github.com/KoboldAI/KoboldAI-Client) is a "a browser-based front-end for
> AI-assisted writing with multiple local & remote AI models...".
> It has a public and local API that can be used in LangChain.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

Check out the [installation guide](https://github.com/KoboldAI/KoboldAI-Client).

## LLMs[​](#llms "Direct link to LLMs")

See a [usage example](/docs/integrations/llms/koboldai/).

```
from langchain_community.llms import KoboldApiLLM  

```

**API Reference:**[KoboldApiLLM](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.koboldai.KoboldApiLLM.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/koboldai.mdx)