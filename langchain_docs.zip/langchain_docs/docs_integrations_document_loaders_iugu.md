# Source: https://python.langchain.com/docs/integrations/document_loaders/iugu/

* [Components](/docs/integrations/components/)
* [Document loaders](/docs/integrations/document_loaders/)
* Iugu

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/iugu.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/iugu.ipynb)

# Iugu

> [Iugu](https://www.iugu.com/) is a Brazilian services and software as a service (SaaS) company. It offers payment-processing software and application programming interfaces for e-commerce websites and mobile applications.

This notebook covers how to load data from the `Iugu REST API` into a format that can be ingested into LangChain, along with example usage for vectorization.

```
from langchain.indexes import VectorstoreIndexCreator  
from langchain_community.document_loaders import IuguLoader  

```

**API Reference:**[VectorstoreIndexCreator](https://python.langchain.com/api_reference/langchain/indexes/langchain.indexes.vectorstore.VectorstoreIndexCreator.html) | [IuguLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.iugu.IuguLoader.html)

The Iugu API requires an access token, which can be found inside of the Iugu dashboard.

This document loader also requires a `resource` option which defines what data you want to load.

Following resources are available:

`Documentation` [Documentation](https://dev.iugu.com/reference/metadados)

```
iugu_loader = IuguLoader("charges")  

```

```
# Create a vectorstore retriever from the loader  
# see https://python.langchain.com/en/latest/modules/data_connection/getting_started.html for more details  
  
index = VectorstoreIndexCreator().from_loaders([iugu_loader])  
iugu_doc_retriever = index.vectorstore.as_retriever()  

```

## Related[​](#related "Direct link to Related")

* Document loader [conceptual guide](/docs/concepts/document_loaders/)
* Document loader [how-to guides](/docs/how_to/#document-loaders)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/iugu.ipynb)