# Source: https://python.langchain.com/docs/integrations/providers/confident/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Confident AI

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/confident.mdx)

# Confident AI

> [Confident AI](https://confident-ai.com) is a creator of the `DeepEval`.
>
> [DeepEval](https://github.com/confident-ai/deepeval) is a package for unit testing LLMs.
> Using `DeepEval`, everyone can build robust language models through faster iterations
> using both unit testing and integration testing. `DeepEval provides support for each step in the iteration
> from synthetic data creation to testing.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

You need to get the [DeepEval API credentials](https://app.confident-ai.com).

You need to install the `DeepEval` Python package:

```
pip install deepeval  

```

## Callbacks[​](#callbacks "Direct link to Callbacks")

See an [example](/docs/integrations/callbacks/confident/).

```
from langchain.callbacks.confident_callback import DeepEvalCallbackHandler  

```

**API Reference:**[DeepEvalCallbackHandler](https://python.langchain.com/api_reference/community/callbacks/langchain_community.callbacks.confident_callback.DeepEvalCallbackHandler.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/confident.mdx)