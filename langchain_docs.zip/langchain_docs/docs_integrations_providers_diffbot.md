# Source: https://python.langchain.com/docs/integrations/providers/diffbot/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Diffbot

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/diffbot.mdx)

# Diffbot

> [Diffbot](https://docs.diffbot.com/docs) is a suite of ML-based products that make it easy to structure and integrate web data.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

[Get a free Diffbot API token](https://app.diffbot.com/get-started/) and [follow these instructions](https://docs.diffbot.com/reference/authentication) to authenticate your requests.

## Document Loader[​](#document-loader "Direct link to Document Loader")

Diffbot's [Extract API](https://docs.diffbot.com/reference/extract-introduction) is a service that structures and normalizes data from web pages.

Unlike traditional web scraping tools, `Diffbot Extract` doesn't require any rules to read the content on a page. It uses a computer vision model to classify a page into one of 20 possible types, and then transforms raw HTML markup into JSON. The resulting structured JSON follows a consistent [type-based ontology](https://docs.diffbot.com/docs/ontology), which makes it easy to extract data from multiple different web sources with the same schema.

See a [usage example](/docs/integrations/document_loaders/diffbot/).

```
from langchain_community.document_loaders import DiffbotLoader  

```

**API Reference:**[DiffbotLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.diffbot.DiffbotLoader.html)

## Graphs[​](#graphs "Direct link to Graphs")

Diffbot's [Natural Language Processing API](https://www.diffbot.com/products/natural-language/) allows for the extraction of entities, relationships, and semantic meaning from unstructured text data.

See a [usage example](/docs/integrations/graphs/diffbot/).

```
from langchain_experimental.graph_transformers.diffbot import DiffbotGraphTransformer  

```

**API Reference:**[DiffbotGraphTransformer](https://python.langchain.com/api_reference/experimental/graph_transformers/langchain_experimental.graph_transformers.diffbot.DiffbotGraphTransformer.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/diffbot.mdx)