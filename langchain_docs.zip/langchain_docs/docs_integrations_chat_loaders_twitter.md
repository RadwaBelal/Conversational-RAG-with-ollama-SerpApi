# Source: https://python.langchain.com/docs/integrations/chat_loaders/twitter/

* [Components](/docs/integrations/components/)
* Other
* [Chat loaders](/docs/integrations/chat_loaders/)
* Twitter (via Apify)

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/chat_loaders/twitter.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/chat_loaders/twitter.ipynb)

# Twitter (via Apify)

This notebook shows how to load chat messages from Twitter to fine-tune on. We do this by utilizing Apify.

First, use Apify to export tweets. An example

```
import json  
  
from langchain_community.adapters.openai import convert_message_to_dict  
from langchain_core.messages import AIMessage  

```

**API Reference:**[convert\_message\_to\_dict](https://python.langchain.com/api_reference/community/adapters/langchain_community.adapters.openai.convert_message_to_dict.html) | [AIMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.ai.AIMessage.html)

```
with open("example_data/dataset_twitter-scraper_2023-08-23_22-13-19-740.json") as f:  
    data = json.load(f)  

```

```
# Filter out tweets that reference other tweets, because it's a bit weird  
tweets = [d["full_text"] for d in data if "t.co" not in d["full_text"]]  
# Create them as AI messages  
messages = [AIMessage(content=t) for t in tweets]  
# Add in a system message at the start  
# TODO: we could try to extract the subject from the tweets, and put that in the system message.  
system_message = {"role": "system", "content": "write a tweet"}  
data = [[system_message, convert_message_to_dict(m)] for m in messages]  

```

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/chat_loaders/twitter.ipynb)