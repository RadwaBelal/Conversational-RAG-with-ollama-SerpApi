# Source: https://python.langchain.com/docs/integrations/providers/ibm/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* IBM

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/ibm.mdx)

# IBM

The `LangChain` integrations related to [IBM watsonx.ai](https://www.ibm.com/products/watsonx-ai) platform.

IBM® watsonx.ai™ AI studio is part of the IBM [watsonx](https://www.ibm.com/watsonx)™ AI and data platform, bringing together new generative
AI capabilities powered by [foundation models](https://www.ibm.com/products/watsonx-ai/foundation-models) and traditional machine learning (ML)
into a powerful studio spanning the AI lifecycle. Tune and guide models with your enterprise data to meet your needs with easy-to-use tools for
building and refining performant prompts. With watsonx.ai, you can build AI applications in a fraction of the time and with a fraction of the data.
Watsonx.ai offers:

* **Multi-model variety and flexibility:** Choose from IBM-developed, open-source and third-party models, or build your own model.
* **Differentiated client protection:** IBM stands behind IBM-developed models and indemnifies the client against third-party IP claims.
* **End-to-end AI governance:** Enterprises can scale and accelerate the impact of AI with trusted data across the business, using data wherever it resides.
* **Hybrid, multi-cloud deployments:** IBM provides the flexibility to integrate and deploy your AI workloads into your hybrid-cloud stack of choice.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

Install the integration package with

```
pip install -qU langchain-ibm  

```

Get an IBM watsonx.ai api key and set it as an environment variable (`WATSONX_APIKEY`)

```
import os  
  
os.environ["WATSONX_APIKEY"] = "your IBM watsonx.ai api key"  

```

## Chat Model[​](#chat-model "Direct link to Chat Model")

### ChatWatsonx[​](#chatwatsonx "Direct link to ChatWatsonx")

See a [usage example](/docs/integrations/chat/ibm_watsonx/).

```
from langchain_ibm import ChatWatsonx  

```

**API Reference:**[ChatWatsonx](https://python.langchain.com/api_reference/ibm/chat_models/langchain_ibm.chat_models.ChatWatsonx.html)

## LLMs[​](#llms "Direct link to LLMs")

### WatsonxLLM[​](#watsonxllm "Direct link to WatsonxLLM")

See a [usage example](/docs/integrations/llms/ibm_watsonx/).

```
from langchain_ibm import WatsonxLLM  

```

**API Reference:**[WatsonxLLM](https://python.langchain.com/api_reference/ibm/llms/langchain_ibm.llms.WatsonxLLM.html)

## Embedding Models[​](#embedding-models "Direct link to Embedding Models")

### WatsonxEmbeddings[​](#watsonxembeddings "Direct link to WatsonxEmbeddings")

See a [usage example](/docs/integrations/text_embedding/ibm_watsonx/).

```
from langchain_ibm import WatsonxEmbeddings  

```

**API Reference:**[WatsonxEmbeddings](https://python.langchain.com/api_reference/ibm/embeddings/langchain_ibm.embeddings.WatsonxEmbeddings.html)

## Reranker[​](#reranker "Direct link to Reranker")

### WatsonxRerank[​](#watsonxrerank "Direct link to WatsonxRerank")

See a [usage example](/docs/integrations/retrievers/ibm_watsonx_ranker/).

```
from langchain_ibm import WatsonxRerank  

```

**API Reference:**[WatsonxRerank](https://python.langchain.com/api_reference/ibm/rerank/langchain_ibm.rerank.WatsonxRerank.html)

## Toolkit[​](#toolkit "Direct link to Toolkit")

### WatsonxToolkit[​](#watsonxtoolkit "Direct link to WatsonxToolkit")

See a [usage example](/docs/integrations/tools/ibm_watsonx/).

```
from langchain_ibm import WatsonxToolkit  

```

**API Reference:**[WatsonxToolkit](https://python.langchain.com/api_reference/ibm/toolkit/langchain_ibm.toolkit.WatsonxToolkit.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/ibm.mdx)