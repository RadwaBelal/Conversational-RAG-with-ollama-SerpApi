# Source: https://python.langchain.com/docs/integrations/providers/aws/

* [Providers](/docs/integrations/providers/)
* AWS

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/aws.mdx)

# AWS

The `LangChain` integrations related to [Amazon AWS](https://aws.amazon.com/) platform.

First-party AWS integrations are available in the `langchain_aws` package.

```
pip install langchain-aws  

```

And there are also some community integrations available in the `langchain_community` package with the `boto3` optional dependency.

```
pip install langchain-community boto3  

```

## Chat models[​](#chat-models "Direct link to Chat models")

### Bedrock Chat[​](#bedrock-chat "Direct link to Bedrock Chat")

> [Amazon Bedrock](https://aws.amazon.com/bedrock/) is a fully managed service that offers a choice of
> high-performing foundation models (FMs) from leading AI companies like `AI21 Labs`, `Anthropic`, `Cohere`,
> `Meta`, `Stability AI`, and `Amazon` via a single API, along with a broad set of capabilities you need to
> build generative AI applications with security, privacy, and responsible AI. Using `Amazon Bedrock`,
> you can easily experiment with and evaluate top FMs for your use case, privately customize them with
> your data using techniques such as fine-tuning and `Retrieval Augmented Generation` (`RAG`), and build
> agents that execute tasks using your enterprise systems and data sources. Since `Amazon Bedrock` is
> serverless, you don't have to manage any infrastructure, and you can securely integrate and deploy
> generative AI capabilities into your applications using the AWS services you are already familiar with.

See a [usage example](/docs/integrations/chat/bedrock/).

```
from langchain_aws import ChatBedrock  

```

**API Reference:**[ChatBedrock](https://python.langchain.com/api_reference/aws/chat_models/langchain_aws.chat_models.bedrock.ChatBedrock.html)

### Bedrock Converse[​](#bedrock-converse "Direct link to Bedrock Converse")

AWS Bedrock maintains a [Converse API](https://docs.aws.amazon.com/bedrock/latest/APIReference/API_runtime_Converse.html)
that provides a unified conversational interface for Bedrock models. This API does not
yet support custom models. You can see a list of all
[models that are supported here](https://docs.aws.amazon.com/bedrock/latest/userguide/conversation-inference.html).

info

We recommend the Converse API for users who do not need to use custom models. It can be accessed using [ChatBedrockConverse](https://python.langchain.com/api_reference/aws/chat_models/langchain_aws.chat_models.bedrock_converse.ChatBedrockConverse.html).

See a [usage example](/docs/integrations/chat/bedrock/).

```
from langchain_aws import ChatBedrockConverse  

```

**API Reference:**[ChatBedrockConverse](https://python.langchain.com/api_reference/aws/chat_models/langchain_aws.chat_models.bedrock_converse.ChatBedrockConverse.html)

## LLMs[​](#llms "Direct link to LLMs")

### Bedrock[​](#bedrock "Direct link to Bedrock")

See a [usage example](/docs/integrations/llms/bedrock/).

```
from langchain_aws import BedrockLLM  

```

**API Reference:**[BedrockLLM](https://python.langchain.com/api_reference/aws/llms/langchain_aws.llms.bedrock.BedrockLLM.html)

### Amazon API Gateway[​](#amazon-api-gateway "Direct link to Amazon API Gateway")

> [Amazon API Gateway](https://aws.amazon.com/api-gateway/) is a fully managed service that makes it easy for
> developers to create, publish, maintain, monitor, and secure APIs at any scale. APIs act as the "front door"
> for applications to access data, business logic, or functionality from your backend services. Using
> `API Gateway`, you can create RESTful APIs and WebSocket APIs that enable real-time two-way communication
> applications. `API Gateway` supports containerized and serverless workloads, as well as web applications.
>
> `API Gateway` handles all the tasks involved in accepting and processing up to hundreds of thousands of
> concurrent API calls, including traffic management, CORS support, authorization and access control,
> throttling, monitoring, and API version management. `API Gateway` has no minimum fees or startup costs.
> You pay for the API calls you receive and the amount of data transferred out and, with the `API Gateway`
> tiered pricing model, you can reduce your cost as your API usage scales.

See a [usage example](/docs/integrations/llms/amazon_api_gateway/).

```
from langchain_community.llms import AmazonAPIGateway  

```

**API Reference:**[AmazonAPIGateway](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.amazon_api_gateway.AmazonAPIGateway.html)

### SageMaker Endpoint[​](#sagemaker-endpoint "Direct link to SageMaker Endpoint")

> [Amazon SageMaker](https://aws.amazon.com/sagemaker/) is a system that can build, train, and deploy
> machine learning (ML) models with fully managed infrastructure, tools, and workflows.

We use `SageMaker` to host our model and expose it as the `SageMaker Endpoint`.

See a [usage example](/docs/integrations/llms/sagemaker/).

```
from langchain_aws import SagemakerEndpoint  

```

**API Reference:**[SagemakerEndpoint](https://python.langchain.com/api_reference/aws/llms/langchain_aws.llms.sagemaker_endpoint.SagemakerEndpoint.html)

## Embedding Models[​](#embedding-models "Direct link to Embedding Models")

### Bedrock[​](#bedrock-1 "Direct link to Bedrock")

See a [usage example](/docs/integrations/text_embedding/bedrock/).

```
from langchain_aws import BedrockEmbeddings  

```

**API Reference:**[BedrockEmbeddings](https://python.langchain.com/api_reference/aws/embeddings/langchain_aws.embeddings.bedrock.BedrockEmbeddings.html)

### SageMaker Endpoint[​](#sagemaker-endpoint-1 "Direct link to SageMaker Endpoint")

See a [usage example](/docs/integrations/text_embedding/sagemaker-endpoint/).

```
from langchain_community.embeddings import SagemakerEndpointEmbeddings  
from langchain_community.llms.sagemaker_endpoint import ContentHandlerBase  

```

**API Reference:**[SagemakerEndpointEmbeddings](https://python.langchain.com/api_reference/community/embeddings/langchain_community.embeddings.sagemaker_endpoint.SagemakerEndpointEmbeddings.html) | [ContentHandlerBase](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.sagemaker_endpoint.ContentHandlerBase.html)

## Document loaders[​](#document-loaders "Direct link to Document loaders")

### AWS S3 Directory and File[​](#aws-s3-directory-and-file "Direct link to AWS S3 Directory and File")

> [Amazon Simple Storage Service (Amazon S3)](https://docs.aws.amazon.com/AmazonS3/latest/userguide/using-folders.html)
> is an object storage service.
> [AWS S3 Directory](https://docs.aws.amazon.com/AmazonS3/latest/userguide/using-folders.html)
> [AWS S3 Buckets](https://docs.aws.amazon.com/AmazonS3/latest/userguide/UsingBucket.html)

See a [usage example for S3DirectoryLoader](/docs/integrations/document_loaders/aws_s3_directory/).

See a [usage example for S3FileLoader](/docs/integrations/document_loaders/aws_s3_file/).

```
from langchain_community.document_loaders import S3DirectoryLoader, S3FileLoader  

```

**API Reference:**[S3DirectoryLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.s3_directory.S3DirectoryLoader.html) | [S3FileLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.s3_file.S3FileLoader.html)

### Amazon Textract[​](#amazon-textract "Direct link to Amazon Textract")

> [Amazon Textract](https://docs.aws.amazon.com/managedservices/latest/userguide/textract.html) is a machine
> learning (ML) service that automatically extracts text, handwriting, and data from scanned documents.

See a [usage example](/docs/integrations/document_loaders/amazon_textract/).

```
from langchain_community.document_loaders import AmazonTextractPDFLoader  

```

**API Reference:**[AmazonTextractPDFLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.pdf.AmazonTextractPDFLoader.html)

### Amazon Athena[​](#amazon-athena "Direct link to Amazon Athena")

> [Amazon Athena](https://aws.amazon.com/athena/) is a serverless, interactive analytics service built
> on open-source frameworks, supporting open-table and file formats.

See a [usage example](/docs/integrations/document_loaders/athena/).

```
from langchain_community.document_loaders.athena import AthenaLoader  

```

**API Reference:**[AthenaLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.athena.AthenaLoader.html)

### AWS Glue[​](#aws-glue "Direct link to AWS Glue")

> The [AWS Glue Data Catalog](https://docs.aws.amazon.com/en_en/glue/latest/dg/catalog-and-crawler.html) is a centralized metadata
> repository that allows you to manage, access, and share metadata about
> your data stored in AWS. It acts as a metadata store for your data assets,
> enabling various AWS services and your applications to query and connect
> to the data they need efficiently.

See a [usage example](/docs/integrations/document_loaders/glue_catalog/).

```
from langchain_community.document_loaders.glue_catalog import GlueCatalogLoader  

```

**API Reference:**[GlueCatalogLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.glue_catalog.GlueCatalogLoader.html)

## Vector stores[​](#vector-stores "Direct link to Vector stores")

### Amazon OpenSearch Service[​](#amazon-opensearch-service "Direct link to Amazon OpenSearch Service")

> [Amazon OpenSearch Service](https://aws.amazon.com/opensearch-service/) performs
> interactive log analytics, real-time application monitoring, website search, and more. `OpenSearch` is
> an open source,
> distributed search and analytics suite derived from `Elasticsearch`. `Amazon OpenSearch Service` offers the
> latest versions of `OpenSearch`, support for many versions of `Elasticsearch`, as well as
> visualization capabilities powered by `OpenSearch Dashboards` and `Kibana`.

We need to install several python libraries.

```
pip install boto3 requests requests-aws4auth  

```

See a [usage example](/docs/integrations/vectorstores/opensearch/#using-aos-amazon-opensearch-service).

```
from langchain_community.vectorstores import OpenSearchVectorSearch  

```

**API Reference:**[OpenSearchVectorSearch](https://python.langchain.com/api_reference/community/vectorstores/langchain_community.vectorstores.opensearch_vector_search.OpenSearchVectorSearch.html)

### Amazon DocumentDB Vector Search[​](#amazon-documentdb-vector-search "Direct link to Amazon DocumentDB Vector Search")

> [Amazon DocumentDB (with MongoDB Compatibility)](https://docs.aws.amazon.com/documentdb/) makes it easy to set up, operate, and scale MongoDB-compatible databases in the cloud.
> With Amazon DocumentDB, you can run the same application code and use the same drivers and tools that you use with MongoDB.
> Vector search for Amazon DocumentDB combines the flexibility and rich querying capability of a JSON-based document database with the power of vector search.

#### Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

See [detail configuration instructions](/docs/integrations/vectorstores/documentdb/).

We need to install the `pymongo` python package.

```
pip install pymongo  

```

#### Deploy DocumentDB on AWS[​](#deploy-documentdb-on-aws "Direct link to Deploy DocumentDB on AWS")

[Amazon DocumentDB (with MongoDB Compatibility)](https://docs.aws.amazon.com/documentdb/) is a fast, reliable, and fully managed database service. Amazon DocumentDB makes it easy to set up, operate, and scale MongoDB-compatible databases in the cloud.

AWS offers services for computing, databases, storage, analytics, and other functionality. For an overview of all AWS services, see [Cloud Computing with Amazon Web Services](https://aws.amazon.com/what-is-aws/).

See a [usage example](/docs/integrations/vectorstores/documentdb/).

```
from langchain_community.vectorstores import DocumentDBVectorSearch  

```

**API Reference:**[DocumentDBVectorSearch](https://python.langchain.com/api_reference/community/vectorstores/langchain_community.vectorstores.documentdb.DocumentDBVectorSearch.html)

### Amazon MemoryDB[​](#amazon-memorydb "Direct link to Amazon MemoryDB")

[Amazon MemoryDB](https://aws.amazon.com/memorydb/) is a durable, in-memory database service that delivers ultra-fast performance. MemoryDB is compatible with Redis OSS, a popular open source data store,
enabling you to quickly build applications using the same flexible and friendly Redis OSS APIs, and commands that they already use today.

InMemoryVectorStore class provides a vectorstore to connect with Amazon MemoryDB.

```
from langchain_aws.vectorstores.inmemorydb import InMemoryVectorStore  
  
vds = InMemoryVectorStore.from_documents(  
            chunks,  
            embeddings,  
            redis_url="rediss://cluster_endpoint:6379/ssl=True ssl_cert_reqs=none",  
            vector_schema=vector_schema,  
            index_name=INDEX_NAME,  
        )  

```

**API Reference:**[InMemoryVectorStore](https://python.langchain.com/api_reference/aws/vectorstores/langchain_aws.vectorstores.inmemorydb.base.InMemoryVectorStore.html)

See a [usage example](/docs/integrations/vectorstores/memorydb/).

## Retrievers[​](#retrievers "Direct link to Retrievers")

### Amazon Kendra[​](#amazon-kendra "Direct link to Amazon Kendra")

> [Amazon Kendra](https://docs.aws.amazon.com/kendra/latest/dg/what-is-kendra.html) is an intelligent search service
> provided by `Amazon Web Services` (`AWS`). It utilizes advanced natural language processing (NLP) and machine
> learning algorithms to enable powerful search capabilities across various data sources within an organization.
> `Kendra` is designed to help users find the information they need quickly and accurately,
> improving productivity and decision-making.

> With `Kendra`, we can search across a wide range of content types, including documents, FAQs, knowledge bases,
> manuals, and websites. It supports multiple languages and can understand complex queries, synonyms, and
> contextual meanings to provide highly relevant search results.

We need to install the `langchain-aws` library.

```
pip install langchain-aws  

```

See a [usage example](/docs/integrations/retrievers/amazon_kendra_retriever/).

```
from langchain_aws import AmazonKendraRetriever  

```

**API Reference:**[AmazonKendraRetriever](https://python.langchain.com/api_reference/aws/retrievers/langchain_aws.retrievers.kendra.AmazonKendraRetriever.html)

### Amazon Bedrock (Knowledge Bases)[​](#amazon-bedrock-knowledge-bases "Direct link to Amazon Bedrock (Knowledge Bases)")

> [Knowledge bases for Amazon Bedrock](https://aws.amazon.com/bedrock/knowledge-bases/) is an
> `Amazon Web Services` (`AWS`) offering which lets you quickly build RAG applications by using your
> private data to customize foundation model response.

We need to install the `langchain-aws` library.

```
pip install langchain-aws  

```

See a [usage example](/docs/integrations/retrievers/bedrock/).

```
from langchain_aws import AmazonKnowledgeBasesRetriever  

```

**API Reference:**[AmazonKnowledgeBasesRetriever](https://python.langchain.com/api_reference/aws/retrievers/langchain_aws.retrievers.bedrock.AmazonKnowledgeBasesRetriever.html)

## Tools[​](#tools "Direct link to Tools")

### AWS Lambda[​](#aws-lambda "Direct link to AWS Lambda")

> [`Amazon AWS Lambda`](https://aws.amazon.com/pm/lambda/) is a serverless computing service provided by
> `Amazon Web Services` (`AWS`). It helps developers to build and run applications and services without
> provisioning or managing servers. This serverless architecture enables you to focus on writing and
> deploying code, while AWS automatically takes care of scaling, patching, and managing the
> infrastructure required to run your applications.

We need to install `boto3` python library.

```
pip install boto3  

```

See a [usage example](/docs/integrations/tools/awslambda/).

## Memory[​](#memory "Direct link to Memory")

### AWS DynamoDB[​](#aws-dynamodb "Direct link to AWS DynamoDB")

> [AWS DynamoDB](https://awscli.amazonaws.com/v2/documentation/api/latest/reference/dynamodb/index.html)
> is a fully managed `NoSQL` database service that provides fast and predictable performance with seamless scalability.

We have to configure the [AWS CLI](https://docs.aws.amazon.com/cli/latest/userguide/cli-chap-configure.html).

We need to install the `boto3` library.

```
pip install boto3  

```

See a [usage example](/docs/integrations/memory/aws_dynamodb/).

```
from langchain_community.chat_message_histories import DynamoDBChatMessageHistory  

```

**API Reference:**[DynamoDBChatMessageHistory](https://python.langchain.com/api_reference/community/chat_message_histories/langchain_community.chat_message_histories.dynamodb.DynamoDBChatMessageHistory.html)

## Graphs[​](#graphs "Direct link to Graphs")

### Amazon Neptune[​](#amazon-neptune "Direct link to Amazon Neptune")

> [Amazon Neptune](https://aws.amazon.com/neptune/)
> is a high-performance graph analytics and serverless database for superior scalability and availability.

For the Cypher and SPARQL integrations below, we need to install the `langchain-aws` library.

```
pip install langchain-aws  

```

### Amazon Neptune with Cypher[​](#amazon-neptune-with-cypher "Direct link to Amazon Neptune with Cypher")

See a [usage example](/docs/integrations/graphs/amazon_neptune_open_cypher/).

```
from langchain_aws.graphs import NeptuneGraph  
from langchain_aws.graphs import NeptuneAnalyticsGraph  
from langchain_aws.chains import create_neptune_opencypher_qa_chain  

```

**API Reference:**[NeptuneGraph](https://python.langchain.com/api_reference/aws/graphs/langchain_aws.graphs.neptune_graph.NeptuneGraph.html) | [NeptuneAnalyticsGraph](https://python.langchain.com/api_reference/aws/graphs/langchain_aws.graphs.neptune_graph.NeptuneAnalyticsGraph.html) | [create\_neptune\_opencypher\_qa\_chain](https://python.langchain.com/api_reference/aws/chains/langchain_aws.chains.graph_qa.neptune_cypher.create_neptune_opencypher_qa_chain.html)

### Amazon Neptune with SPARQL[​](#amazon-neptune-with-sparql "Direct link to Amazon Neptune with SPARQL")

See a [usage example](/docs/integrations/graphs/amazon_neptune_sparql/).

```
from langchain_aws.graphs import NeptuneRdfGraph  
from langchain_aws.chains import create_neptune_sparql_qa_chain  

```

**API Reference:**[NeptuneRdfGraph](https://python.langchain.com/api_reference/aws/graphs/langchain_aws.graphs.neptune_rdf_graph.NeptuneRdfGraph.html) | [create\_neptune\_sparql\_qa\_chain](https://python.langchain.com/api_reference/aws/chains/langchain_aws.chains.graph_qa.neptune_sparql.create_neptune_sparql_qa_chain.html)

## Callbacks[​](#callbacks "Direct link to Callbacks")

### Bedrock token usage[​](#bedrock-token-usage "Direct link to Bedrock token usage")

```
from langchain_community.callbacks.bedrock_anthropic_callback import BedrockAnthropicTokenUsageCallbackHandler  

```

**API Reference:**[BedrockAnthropicTokenUsageCallbackHandler](https://python.langchain.com/api_reference/community/callbacks/langchain_community.callbacks.bedrock_anthropic_callback.BedrockAnthropicTokenUsageCallbackHandler.html)

### SageMaker Tracking[​](#sagemaker-tracking "Direct link to SageMaker Tracking")

> [Amazon SageMaker](https://aws.amazon.com/sagemaker/) is a fully managed service that is used to quickly
> and easily build, train and deploy machine learning (ML) models.

> [Amazon SageMaker Experiments](https://docs.aws.amazon.com/sagemaker/latest/dg/experiments.html) is a capability
> of `Amazon SageMaker` that lets you organize, track,
> compare and evaluate ML experiments and model versions.

We need to install several python libraries.

```
pip install google-search-results sagemaker  

```

See a [usage example](/docs/integrations/callbacks/sagemaker_tracking/).

```
from langchain_community.callbacks import SageMakerCallbackHandler  

```

**API Reference:**[SageMakerCallbackHandler](https://python.langchain.com/api_reference/community/callbacks/langchain_community.callbacks.sagemaker_callback.SageMakerCallbackHandler.html)

## Chains[​](#chains "Direct link to Chains")

### Amazon Comprehend Moderation Chain[​](#amazon-comprehend-moderation-chain "Direct link to Amazon Comprehend Moderation Chain")

> [Amazon Comprehend](https://aws.amazon.com/comprehend/) is a natural-language processing (NLP) service that
> uses machine learning to uncover valuable insights and connections in text.

We need to install the `boto3` and `nltk` libraries.

```
pip install boto3 nltk  

```

See a [usage example](https://python.langchain.com/v0.1/docs/guides/productionization/safety/amazon_comprehend_chain/).

```
from langchain_experimental.comprehend_moderation import AmazonComprehendModerationChain  

```

**API Reference:**[AmazonComprehendModerationChain](https://python.langchain.com/api_reference/experimental/comprehend_moderation/langchain_experimental.comprehend_moderation.amazon_comprehend_moderation.AmazonComprehendModerationChain.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/aws.mdx)