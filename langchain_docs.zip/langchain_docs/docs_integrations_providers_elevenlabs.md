# Source: https://python.langchain.com/docs/integrations/providers/elevenlabs/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* ElevenLabs

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/elevenlabs.mdx)

# ElevenLabs

> [ElevenLabs](https://elevenlabs.io/about) is a voice AI research & deployment company
> with a mission to make content universally accessible in any language & voice.
>
> `ElevenLabs` creates the most realistic, versatile and contextually-aware
> AI audio, providing the ability to generate speech in hundreds of
> new and existing voices in 29 languages.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

First, you need to set up an ElevenLabs account. You can follow the
[instructions here](https://docs.elevenlabs.io/welcome/introduction).

Install the Python package:

```
pip install elevenlabs  

```

## Tools[​](#tools "Direct link to Tools")

See a [usage example](/docs/integrations/tools/eleven_labs_tts/).

```
from langchain_community.tools import ElevenLabsText2SpeechTool  

```

**API Reference:**[ElevenLabsText2SpeechTool](https://python.langchain.com/api_reference/community/tools/langchain_community.tools.eleven_labs.text2speech.ElevenLabsText2SpeechTool.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/elevenlabs.mdx)