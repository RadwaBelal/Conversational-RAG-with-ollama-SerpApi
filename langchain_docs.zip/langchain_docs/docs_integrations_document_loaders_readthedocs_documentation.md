# Source: https://python.langchain.com/docs/integrations/document_loaders/readthedocs_documentation/

* [Components](/docs/integrations/components/)
* [Document loaders](/docs/integrations/document_loaders/)
* ReadTheDocs Documentation

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/readthedocs_documentation.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/readthedocs_documentation.ipynb)

# ReadTheDocs Documentation

> [Read the Docs](https://readthedocs.org/) is an open-sourced free software documentation hosting platform. It generates documentation written with the `Sphinx` documentation generator.

This notebook covers how to load content from HTML that was generated as part of a `Read-The-Docs` build.

For an example of this in the wild, see [here](https://github.com/langchain-ai/chat-langchain).

This assumes that the HTML has already been scraped into a folder. This can be done by uncommenting and running the following command

```
%pip install --upgrade --quiet  beautifulsoup4  

```

```
#!wget -r -A.html -P rtdocs https://python.langchain.com/en/latest/  

```

```
from langchain_community.document_loaders import ReadTheDocsLoader  

```

**API Reference:**[ReadTheDocsLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.readthedocs.ReadTheDocsLoader.html)

```
loader = ReadTheDocsLoader("rtdocs")  

```

```
docs = loader.load()  

```

## Related[​](#related "Direct link to Related")

* Document loader [conceptual guide](/docs/concepts/document_loaders/)
* Document loader [how-to guides](/docs/how_to/#document-loaders)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/readthedocs_documentation.ipynb)