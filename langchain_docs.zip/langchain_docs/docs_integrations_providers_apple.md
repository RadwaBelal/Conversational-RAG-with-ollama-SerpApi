# Source: https://python.langchain.com/docs/integrations/providers/apple/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Apple

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/apple.mdx)

# Apple

> [Apple Inc. (Wikipedia)](https://en.wikipedia.org/wiki/Apple_Inc.) is an American
> multinational corporation and technology company.
>
> [iMessage (Wikipedia)](https://en.wikipedia.org/wiki/IMessage) is an instant
> messaging service developed by Apple Inc. and launched in 2011.
> `iMessage` functions exclusively on Apple platforms.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

See [setup instructions](/docs/integrations/chat_loaders/imessage/).

## Chat loader[​](#chat-loader "Direct link to Chat loader")

It loads chat sessions from the `iMessage` `chat.db` `SQLite` file.

See a [usage example](/docs/integrations/chat_loaders/imessage/).

```
from langchain_community.chat_loaders.imessage import IMessageChatLoader  

```

**API Reference:**[IMessageChatLoader](https://python.langchain.com/api_reference/community/chat_loaders/langchain_community.chat_loaders.imessage.IMessageChatLoader.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/apple.mdx)