# Source: https://python.langchain.com/docs/integrations/providers/dropbox/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Dropbox

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/dropbox.mdx)

# Dropbox

> [Dropbox](https://en.wikipedia.org/wiki/Dropbox) is a file hosting service that brings everything-traditional
> files, cloud content, and web shortcuts together in one place.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

See the detailed [installation guide](/docs/integrations/document_loaders/dropbox/#prerequisites).

```
pip install -U dropbox  

```

## Document Loader[​](#document-loader "Direct link to Document Loader")

See a [usage example](/docs/integrations/document_loaders/dropbox/).

```
from langchain_community.document_loaders import DropboxLoader  

```

**API Reference:**[DropboxLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.dropbox.DropboxLoader.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/dropbox.mdx)