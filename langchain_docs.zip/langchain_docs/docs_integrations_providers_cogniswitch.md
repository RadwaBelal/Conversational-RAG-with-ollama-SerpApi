# Source: https://python.langchain.com/docs/integrations/providers/cogniswitch/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* CogniSwitch

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/cogniswitch.mdx)

# CogniSwitch

> [CogniSwitch](https://www.cogniswitch.ai/aboutus) is an API based data platform that
> enhances enterprise data by extracting entities, concepts and their relationships
> thereby converting this data into a multidimensional format and storing it in
> a database that can accommodate these enhancements. In our case the data is stored
> in a knowledge graph. This enhanced data is now ready for consumption by LLMs and
> other GenAI applications ensuring the data is consumable and context can be maintained.
> Thereby eliminating hallucinations and delivering accuracy.

## Toolkit[​](#toolkit "Direct link to Toolkit")

See [installation instructions and usage example](/docs/integrations/tools/cogniswitch/).

```
from langchain_community.agent_toolkits import CogniswitchToolkit  

```

**API Reference:**[CogniswitchToolkit](https://python.langchain.com/api_reference/community/agent_toolkits/langchain_community.agent_toolkits.cogniswitch.toolkit.CogniswitchToolkit.html)

## Tools[​](#tools "Direct link to Tools")

### CogniswitchKnowledgeRequest[​](#cogniswitchknowledgerequest "Direct link to CogniswitchKnowledgeRequest")

> Tool that uses the CogniSwitch service to answer questions.

```
from langchain_community.tools.cogniswitch.tool import CogniswitchKnowledgeRequest  

```

**API Reference:**[CogniswitchKnowledgeRequest](https://python.langchain.com/api_reference/community/tools/langchain_community.tools.cogniswitch.tool.CogniswitchKnowledgeRequest.html)

### CogniswitchKnowledgeSourceFile[​](#cogniswitchknowledgesourcefile "Direct link to CogniswitchKnowledgeSourceFile")

> Tool that uses the CogniSwitch services to store data from file.

```
from langchain_community.tools.cogniswitch.tool import CogniswitchKnowledgeSourceFile  

```

**API Reference:**[CogniswitchKnowledgeSourceFile](https://python.langchain.com/api_reference/community/tools/langchain_community.tools.cogniswitch.tool.CogniswitchKnowledgeSourceFile.html)

### CogniswitchKnowledgeSourceURL[​](#cogniswitchknowledgesourceurl "Direct link to CogniswitchKnowledgeSourceURL")

> Tool that uses the CogniSwitch services to store data from a URL.

```
from langchain_community.tools.cogniswitch.tool import CogniswitchKnowledgeSourceURL  

```

**API Reference:**[CogniswitchKnowledgeSourceURL](https://python.langchain.com/api_reference/community/tools/langchain_community.tools.cogniswitch.tool.CogniswitchKnowledgeSourceURL.html)

### CogniswitchKnowledgeStatus[​](#cogniswitchknowledgestatus "Direct link to CogniswitchKnowledgeStatus")

> Tool that uses the CogniSwitch services to get the status of the document or url uploaded.

```
from langchain_community.tools.cogniswitch.tool import CogniswitchKnowledgeStatus  

```

**API Reference:**[CogniswitchKnowledgeStatus](https://python.langchain.com/api_reference/community/tools/langchain_community.tools.cogniswitch.tool.CogniswitchKnowledgeStatus.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/cogniswitch.mdx)