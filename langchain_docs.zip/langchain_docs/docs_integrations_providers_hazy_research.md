# Source: https://python.langchain.com/docs/integrations/providers/hazy_research/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Hazy Research

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/hazy_research.mdx)

# Hazy Research

This page covers how to use the Hazy Research ecosystem within LangChain.
It is broken into two parts: installation and setup, and then references to specific Hazy Research wrappers.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

* To use the `manifest`, install it with `pip install manifest-ml`

## Wrappers[​](#wrappers "Direct link to Wrappers")

### LLM[​](#llm "Direct link to LLM")

There exists an LLM wrapper around Hazy Research's `manifest` library.
`manifest` is a python library which is itself a wrapper around many model providers, and adds in caching, history, and more.

To use this wrapper:

```
from langchain_community.llms.manifest import ManifestWrapper  

```

**API Reference:**[ManifestWrapper](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.manifest.ManifestWrapper.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/hazy_research.mdx)