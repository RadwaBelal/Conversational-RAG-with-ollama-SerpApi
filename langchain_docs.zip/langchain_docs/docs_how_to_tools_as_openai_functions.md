# Source: https://python.langchain.com/docs/how_to/tools_as_openai_functions/

* [How-to guides](/docs/how_to/)
* How to convert tools to OpenAI Functions

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/how_to/tools_as_openai_functions.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/how_to/tools_as_openai_functions.ipynb)

# How to convert tools to OpenAI Functions

This notebook goes over how to use LangChain [tools](/docs/concepts/tools/) as OpenAI functions.

```
%pip install -qU langchain-community langchain-openai  

```

```
from langchain_community.tools import MoveFileTool  
from langchain_core.messages import HumanMessage  
from langchain_core.utils.function_calling import convert_to_openai_function  
from langchain_openai import ChatOpenAI  

```

**API Reference:**[MoveFileTool](https://python.langchain.com/api_reference/community/tools/langchain_community.tools.file_management.move.MoveFileTool.html) | [HumanMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.human.HumanMessage.html) | [convert\_to\_openai\_function](https://python.langchain.com/api_reference/core/utils/langchain_core.utils.function_calling.convert_to_openai_function.html) | [ChatOpenAI](https://python.langchain.com/api_reference/openai/chat_models/langchain_openai.chat_models.base.ChatOpenAI.html)

```
model = ChatOpenAI(model="gpt-3.5-turbo")  

```

```
tools = [MoveFileTool()]  
functions = [convert_to_openai_function(t) for t in tools]  

```

```
functions[0]  

```

```
{'name': 'move_file',  
 'description': 'Move or rename a file from one location to another',  
 'parameters': {'type': 'object',  
  'properties': {'source_path': {'description': 'Path of the file to move',  
    'type': 'string'},  
   'destination_path': {'description': 'New path for the moved file',  
    'type': 'string'}},  
  'required': ['source_path', 'destination_path']}}  

```

```
message = model.invoke(  
    [HumanMessage(content="move file foo to bar")], functions=functions  
)  

```

```
message  

```

```
AIMessage(content='', additional_kwargs={'function_call': {'arguments': '{\n  "source_path": "foo",\n  "destination_path": "bar"\n}', 'name': 'move_file'}})  

```

```
message.additional_kwargs["function_call"]  

```

```
{'name': 'move_file',  
 'arguments': '{\n  "source_path": "foo",\n  "destination_path": "bar"\n}'}  

```

With OpenAI chat models we can also automatically bind and convert function-like objects with `bind_functions`

```
model_with_functions = model.bind_functions(tools)  
model_with_functions.invoke([HumanMessage(content="move file foo to bar")])  

```

```
AIMessage(content='', additional_kwargs={'function_call': {'arguments': '{\n  "source_path": "foo",\n  "destination_path": "bar"\n}', 'name': 'move_file'}})  

```

Or we can use the update OpenAI API that uses `tools` and `tool_choice` instead of `functions` and `function_call` by using `ChatOpenAI.bind_tools`:

```
model_with_tools = model.bind_tools(tools)  
model_with_tools.invoke([HumanMessage(content="move file foo to bar")])  

```

```
AIMessage(content='', additional_kwargs={'tool_calls': [{'id': 'call_btkY3xV71cEVAOHnNa5qwo44', 'function': {'arguments': '{\n  "source_path": "foo",\n  "destination_path": "bar"\n}', 'name': 'move_file'}, 'type': 'function'}]})  

```

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/how_to/tools_as_openai_functions.ipynb)