# Source: https://python.langchain.com/docs/integrations/providers/abso/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Abso

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/abso.md)

# Abso

[Abso](https://abso.ai/#router) is an open-source LLM proxy that automatically routes requests between fast and slow models based on prompt complexity. It uses various heuristics to chose the proper model. It's very fast and has low latency.

## Installation and setup[​](#installation-and-setup "Direct link to Installation and setup")

```
pip install langchain-abso  

```

## Chat Model[​](#chat-model "Direct link to Chat Model")

See usage details [here](/docs/integrations/chat/abso/)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/abso.md)