# Source: https://python.langchain.com/docs/integrations/providers/anyscale/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Anyscale

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/anyscale.mdx)

# Anyscale

> [Anyscale](https://www.anyscale.com) is a platform to run, fine tune and scale LLMs via production-ready APIs.
> [Anyscale Endpoints](https://docs.anyscale.com/endpoints/overview) serve many open-source models in a cost-effective way.

`Anyscale` also provides [an example](https://docs.anyscale.com/endpoints/model-serving/examples/langchain-integration)
how to setup `LangChain` with `Anyscale` for advanced chat agents.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

* Get an Anyscale Service URL, route and API key and set them as environment variables (`ANYSCALE_SERVICE_URL`,`ANYSCALE_SERVICE_ROUTE`, `ANYSCALE_SERVICE_TOKEN`).
* Please see [the Anyscale docs](https://www.anyscale.com/get-started) for more details.

We have to install the `openai` package:

```
pip install openai  

```

## LLM[​](#llm "Direct link to LLM")

See a [usage example](/docs/integrations/llms/anyscale/).

```
from langchain_community.llms.anyscale import Anyscale  

```

**API Reference:**[Anyscale](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.anyscale.Anyscale.html)

## Chat Models[​](#chat-models "Direct link to Chat Models")

See a [usage example](/docs/integrations/chat/anyscale/).

```
from langchain_community.chat_models.anyscale import ChatAnyscale  

```

**API Reference:**[ChatAnyscale](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.anyscale.ChatAnyscale.html)

## Embeddings[​](#embeddings "Direct link to Embeddings")

See a [usage example](/docs/integrations/text_embedding/anyscale/).

```
from langchain_community.embeddings import AnyscaleEmbeddings  

```

**API Reference:**[AnyscaleEmbeddings](https://python.langchain.com/api_reference/community/embeddings/langchain_community.embeddings.anyscale.AnyscaleEmbeddings.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/anyscale.mdx)