# Source: https://python.langchain.com/docs/how_to/pydantic_compatibility/

* [How-to guides](/docs/how_to/)
* How to use LangChain with different Pydantic versions

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/how_to/pydantic_compatibility.md)

# How to use LangChain with different Pydantic versions

As of the `0.3` release, LangChain uses Pydantic 2 internally.

Users should install Pydantic 2 and are advised to **avoid** using the `pydantic.v1` namespace of Pydantic 2 with
LangChain APIs.

If you're working with prior versions of LangChain, please see the following guide
on [Pydantic compatibility](https://python.langchain.com/v0.2/docs/how_to/pydantic_compatibility).

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/how_to/pydantic_compatibility.md)