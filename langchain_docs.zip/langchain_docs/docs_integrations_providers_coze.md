# Source: https://python.langchain.com/docs/integrations/providers/coze/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Coze

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/coze.mdx)

# Coze

[Coze](https://www.coze.com/) is an AI chatbot development platform that enables
the creation and deployment of chatbots for handling diverse conversations across
various applications.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

First, you need to get the `API_KEY` from the [Coze](https://www.coze.com/) website.

## Chat models[​](#chat-models "Direct link to Chat models")

See a [usage example](/docs/integrations/chat/coze/).

```
from langchain_community.chat_models import ChatCoze  

```

**API Reference:**[ChatCoze](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.coze.ChatCoze.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/coze.mdx)