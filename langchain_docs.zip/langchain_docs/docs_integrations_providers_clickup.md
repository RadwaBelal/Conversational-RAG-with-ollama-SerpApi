# Source: https://python.langchain.com/docs/integrations/providers/clickup/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* ClickUp

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/clickup.mdx)

# ClickUp

> [ClickUp](https://clickup.com/) is an all-in-one productivity platform that provides small and large teams across industries with flexible and customizable work management solutions, tools, and functions.
>
> It is a cloud-based project management solution for businesses of all sizes featuring communication and collaboration tools to help achieve organizational goals.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

1. Create a [ClickUp App](https://help.clickup.com/hc/en-us/articles/6303422883095-Create-your-own-app-with-the-ClickUp-API)
2. Follow [these steps](https://clickup.com/api/developer-portal/authentication/) to get your client\_id and client\_secret.

## Toolkits[​](#toolkits "Direct link to Toolkits")

```
from langchain_community.agent_toolkits.clickup.toolkit import ClickupToolkit  
from langchain_community.utilities.clickup import ClickupAPIWrapper  

```

**API Reference:**[ClickupToolkit](https://python.langchain.com/api_reference/community/agent_toolkits/langchain_community.agent_toolkits.clickup.toolkit.ClickupToolkit.html) | [ClickupAPIWrapper](https://python.langchain.com/api_reference/community/utilities/langchain_community.utilities.clickup.ClickupAPIWrapper.html)

See a [usage example](/docs/integrations/tools/clickup/).

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/clickup.mdx)