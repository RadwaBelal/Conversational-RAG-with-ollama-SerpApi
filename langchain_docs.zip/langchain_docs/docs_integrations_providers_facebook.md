# Source: https://python.langchain.com/docs/integrations/providers/facebook/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Facebook - Meta

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/facebook.mdx)

# Facebook - Meta

> [Meta Platforms, Inc.](https://www.facebook.com/), doing business as `Meta`, formerly
> named `Facebook, Inc.`, and `TheFacebook, Inc.`, is an American multinational technology
> conglomerate. The company owns and operates `Facebook`, `Instagram`, `Threads`,
> and `WhatsApp`, among other products and services.

## Embedding models[​](#embedding-models "Direct link to Embedding models")

### LASER[​](#laser "Direct link to LASER")

> [LASER](https://github.com/facebookresearch/LASER) is a Python library developed by
> the `Meta AI Research` team and used for
> creating multilingual sentence embeddings for
> [over 147 languages as of 2/25/2024](https://github.com/facebookresearch/flores/blob/main/flores200/README.md#languages-in-flores-200)

```
pip install laser_encoders  

```

See a [usage example](/docs/integrations/text_embedding/laser/).

```
from langchain_community.embeddings.laser import LaserEmbeddings  

```

**API Reference:**[LaserEmbeddings](https://python.langchain.com/api_reference/community/embeddings/langchain_community.embeddings.laser.LaserEmbeddings.html)

## Document loaders[​](#document-loaders "Direct link to Document loaders")

### Facebook Messenger[​](#facebook-messenger "Direct link to Facebook Messenger")

> [Messenger](https://en.wikipedia.org/wiki/Messenger_(software)) is an instant messaging app and
> platform developed by `Meta Platforms`. Originally developed as `Facebook Chat` in 2008, the company revamped its
> messaging service in 2010.

See a [usage example](/docs/integrations/document_loaders/facebook_chat/).

```
from langchain_community.document_loaders import FacebookChatLoader  

```

**API Reference:**[FacebookChatLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.facebook_chat.FacebookChatLoader.html)

## Vector stores[​](#vector-stores "Direct link to Vector stores")

### Facebook Faiss[​](#facebook-faiss "Direct link to Facebook Faiss")

> [Facebook AI Similarity Search (Faiss)](https://engineering.fb.com/2017/03/29/data-infrastructure/faiss-a-library-for-efficient-similarity-search/)
> is a library for efficient similarity search and clustering of dense vectors. It contains algorithms that
> search in sets of vectors of any size, up to ones that possibly do not fit in RAM. It also contains supporting
> code for evaluation and parameter tuning.

[Faiss documentation](https://faiss.ai/).

We need to install `faiss` python package.

```
pip install faiss-gpu # For CUDA 7.5+ supported GPU's.  

```

OR

```
pip install faiss-cpu # For CPU Installation  

```

See a [usage example](/docs/integrations/vectorstores/faiss/).

```
from langchain_community.vectorstores import FAISS  

```

**API Reference:**[FAISS](https://python.langchain.com/api_reference/community/vectorstores/langchain_community.vectorstores.faiss.FAISS.html)

## Chat loaders[​](#chat-loaders "Direct link to Chat loaders")

### Facebook Messenger[​](#facebook-messenger-1 "Direct link to Facebook Messenger")

> [Messenger](https://en.wikipedia.org/wiki/Messenger_(software)) is an instant messaging app and
> platform developed by `Meta Platforms`. Originally developed as `Facebook Chat` in 2008, the company revamped its
> messaging service in 2010.

See a [usage example](/docs/integrations/chat_loaders/facebook/).

```
from langchain_community.chat_loaders.facebook_messenger import (  
    FolderFacebookMessengerChatLoader,  
    SingleFileFacebookMessengerChatLoader,  
)  

```

**API Reference:**[FolderFacebookMessengerChatLoader](https://python.langchain.com/api_reference/community/chat_loaders/langchain_community.chat_loaders.facebook_messenger.FolderFacebookMessengerChatLoader.html) | [SingleFileFacebookMessengerChatLoader](https://python.langchain.com/api_reference/community/chat_loaders/langchain_community.chat_loaders.facebook_messenger.SingleFileFacebookMessengerChatLoader.html)

### Facebook WhatsApp[​](#facebook-whatsapp "Direct link to Facebook WhatsApp")

See a [usage example](/docs/integrations/chat_loaders/whatsapp/).

```
from langchain_community.chat_loaders.whatsapp import WhatsAppChatLoader  

```

**API Reference:**[WhatsAppChatLoader](https://python.langchain.com/api_reference/community/chat_loaders/langchain_community.chat_loaders.whatsapp.WhatsAppChatLoader.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/facebook.mdx)