# Source: https://python.langchain.com/docs/integrations/providers/jaguar/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Jaguar

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/jaguar.mdx)

# Jaguar

This page describes how to use Jaguar vector database within LangChain.
It contains three sections: introduction, installation and setup, and Jaguar API.

## Introduction[​](#introduction "Direct link to Introduction")

Jaguar vector database has the following characteristics:

1. It is a distributed vector database
2. The “ZeroMove” feature of JaguarDB enables instant horizontal scalability
3. Multimodal: embeddings, text, images, videos, PDFs, audio, time series, and geospatial
4. All-masters: allows both parallel reads and writes
5. Anomaly detection capabilities
6. RAG support: combines LLM with proprietary and real-time data
7. Shared metadata: sharing of metadata across multiple vector indexes
8. Distance metrics: Euclidean, Cosine, InnerProduct, Manhatten, Chebyshev, Hamming, Jeccard, Minkowski

[Overview of Jaguar scalable vector database](http://www.jaguardb.com)

You can run JaguarDB in docker container; or download the software and run on-cloud or off-cloud.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

* Install the JaguarDB on one host or multiple hosts
* Install the Jaguar HTTP Gateway server on one host
* Install the JaguarDB HTTP Client package

The steps are described in [Jaguar Documents](http://www.jaguardb.com/support.html)

Environment Variables in client programs:

export OPENAI\_API\_KEY="......"
export JAGUAR\_API\_KEY="......"

## Jaguar API[​](#jaguar-api "Direct link to Jaguar API")

Together with LangChain, a Jaguar client class is provided by importing it in Python:

```
from langchain_community.vectorstores.jaguar import Jaguar  

```

**API Reference:**[Jaguar](https://python.langchain.com/api_reference/community/vectorstores/langchain_community.vectorstores.jaguar.Jaguar.html)

Supported API functions of the Jaguar class are:

* `add_texts`
* `add_documents`
* `from_texts`
* `from_documents`
* `similarity_search`
* `is_anomalous`
* `create`
* `delete`
* `clear`
* `drop`
* `login`
* `logout`

For more details of the Jaguar API, please refer to [this notebook](/docs/integrations/vectorstores/jaguar/)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/jaguar.mdx)