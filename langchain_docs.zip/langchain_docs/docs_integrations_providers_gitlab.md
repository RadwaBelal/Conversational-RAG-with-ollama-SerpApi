# Source: https://python.langchain.com/docs/integrations/providers/gitlab/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* GitLab

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/gitlab.mdx)

# GitLab

> [GitLab Inc.](https://about.gitlab.com/) is an open-core company
> that operates `GitLab`, a DevOps software package that can develop,
> secure, and operate software. `GitLab` includes a distributed version
> control based on Git, including features such as access control, bug tracking,
> software feature requests, task management, and wikis for every project,
> as well as snippets.

## Tools/Toolkits[​](#toolstoolkits "Direct link to Tools/Toolkits")

### GitLabToolkit[​](#gitlabtoolkit "Direct link to GitLabToolkit")

The `Gitlab` toolkit contains tools that enable an LLM agent to interact with a gitlab repository.

The toolkit is a wrapper for the `python-gitlab` library.

See a [usage example](/docs/integrations/tools/gitlab/).

```
from langchain_community.agent_toolkits.gitlab.toolkit import GitLabToolkit  

```

**API Reference:**[GitLabToolkit](https://python.langchain.com/api_reference/community/agent_toolkits/langchain_community.agent_toolkits.gitlab.toolkit.GitLabToolkit.html)

### GitLabAction[​](#gitlabaction "Direct link to GitLabAction")

Tool for interacting with the GitLab API.

```
from langchain_community.tools.gitlab.tool import GitLabAction  

```

**API Reference:**[GitLabAction](https://python.langchain.com/api_reference/community/tools/langchain_community.tools.gitlab.tool.GitLabAction.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/gitlab.mdx)