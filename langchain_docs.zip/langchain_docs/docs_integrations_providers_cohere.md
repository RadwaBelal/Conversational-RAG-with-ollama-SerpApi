# Source: https://python.langchain.com/docs/integrations/providers/cohere/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Cohere

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/cohere.mdx)

# Cohere

> [Cohere](https://cohere.ai/about) is a Canadian startup that provides natural language processing models
> that help companies improve human-machine interactions.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

* Install the Python SDK :

```
pip install langchain-cohere  

```

Get a [Cohere api key](https://dashboard.cohere.ai/) and set it as an environment variable (`COHERE_API_KEY`)

## Cohere langchain integrations[​](#cohere-langchain-integrations "Direct link to Cohere langchain integrations")

| API | description | Endpoint docs | Import | Example usage |
| --- | --- | --- | --- | --- |
| Chat | Build chat bots | [chat](https://docs.cohere.com/reference/chat) | `from langchain_cohere import ChatCohere` | [cohere.ipynb](/docs/integrations/chat/cohere/) |
| LLM | Generate text | [generate](https://docs.cohere.com/reference/generate) | `from langchain_cohere.llms import Cohere` | [cohere.ipynb](/docs/integrations/llms/cohere/) |
| RAG Retriever | Connect to external data sources | [chat + rag](https://docs.cohere.com/reference/chat) | `from langchain.retrievers import CohereRagRetriever` | [cohere.ipynb](/docs/integrations/retrievers/cohere/) |
| Text Embedding | Embed strings to vectors | [embed](https://docs.cohere.com/reference/embed) | `from langchain_cohere import CohereEmbeddings` | [cohere.ipynb](/docs/integrations/text_embedding/cohere/) |
| Rerank Retriever | Rank strings based on relevance | [rerank](https://docs.cohere.com/reference/rerank) | `from langchain.retrievers.document_compressors import CohereRerank` | [cohere.ipynb](/docs/integrations/retrievers/cohere-reranker/) |

## Quick copy examples[​](#quick-copy-examples "Direct link to Quick copy examples")

### Chat[​](#chat "Direct link to Chat")

```
from langchain_cohere import ChatCohere  
from langchain_core.messages import HumanMessage  
chat = ChatCohere()  
messages = [HumanMessage(content="knock knock")]  
print(chat.invoke(messages))  

```

**API Reference:**[ChatCohere](https://python.langchain.com/api_reference/cohere/chat_models/langchain_cohere.chat_models.ChatCohere.html) | [HumanMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.human.HumanMessage.html)

Usage of the Cohere [chat model](/docs/integrations/chat/cohere/)

### LLM[​](#llm "Direct link to LLM")

```
from langchain_cohere.llms import Cohere  
  
llm = Cohere()  
print(llm.invoke("Come up with a pet name"))  

```

**API Reference:**[Cohere](https://python.langchain.com/api_reference/cohere/llms/langchain_cohere.llms.Cohere.html)

Usage of the Cohere (legacy) [LLM model](/docs/integrations/llms/cohere/)

### Tool calling[​](#tool-calling "Direct link to Tool calling")

```
from langchain_cohere import ChatCohere  
from langchain_core.messages import (  
    HumanMessage,  
    ToolMessage,  
)  
from langchain_core.tools import tool  
  
@tool  
def magic_function(number: int) -> int:  
    """Applies a magic operation to an integer  
  
    Args:  
        number: Number to have magic operation performed on  
    """  
    return number + 10  
  
def invoke_tools(tool_calls, messages):  
    for tool_call in tool_calls:  
        selected_tool = {"magic_function":magic_function}[  
            tool_call["name"].lower()  
        ]  
        tool_output = selected_tool.invoke(tool_call["args"])  
        messages.append(ToolMessage(tool_output, tool_call_id=tool_call["id"]))  
    return messages  
  
tools = [magic_function]  
  
llm = ChatCohere()  
llm_with_tools = llm.bind_tools(tools=tools)  
messages = [  
    HumanMessage(  
        content="What is the value of magic_function(2)?"  
    )  
]  
  
res = llm_with_tools.invoke(messages)  
while res.tool_calls:  
    messages.append(res)  
    messages = invoke_tools(res.tool_calls, messages)  
    res = llm_with_tools.invoke(messages)  
  
print(res.content)  

```

**API Reference:**[ChatCohere](https://python.langchain.com/api_reference/cohere/chat_models/langchain_cohere.chat_models.ChatCohere.html) | [HumanMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.human.HumanMessage.html) | [ToolMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.tool.ToolMessage.html) | [tool](https://python.langchain.com/api_reference/core/tools/langchain_core.tools.convert.tool.html)

Tool calling with Cohere LLM can be done by binding the necessary tools to the llm as seen above.
An alternative, is to support multi hop tool calling with the ReAct agent as seen below.

### ReAct Agent[​](#react-agent "Direct link to ReAct Agent")

The agent is based on the paper
[ReAct: Synergizing Reasoning and Acting in Language Models](https://arxiv.org/abs/2210.03629).

```
from langchain_community.tools.tavily_search import TavilySearchResults  
from langchain_cohere import ChatCohere, create_cohere_react_agent  
from langchain_core.prompts import ChatPromptTemplate  
from langchain.agents import AgentExecutor  
  
llm = ChatCohere()  
  
internet_search = TavilySearchResults(max_results=4)  
internet_search.name = "internet_search"  
internet_search.description = "Route a user query to the internet"  
  
prompt = ChatPromptTemplate.from_template("{input}")  
  
agent = create_cohere_react_agent(  
    llm,  
    [internet_search],  
    prompt  
)  
  
agent_executor = AgentExecutor(agent=agent, tools=[internet_search], verbose=True)  
  
agent_executor.invoke({  
    "input": "In what year was the company that was founded as Sound of Music added to the S&P 500?",  
})  

```

**API Reference:**[TavilySearchResults](https://python.langchain.com/api_reference/community/tools/langchain_community.tools.tavily_search.tool.TavilySearchResults.html) | [ChatCohere](https://python.langchain.com/api_reference/cohere/chat_models/langchain_cohere.chat_models.ChatCohere.html) | [create\_cohere\_react\_agent](https://python.langchain.com/api_reference/cohere/react_multi_hop/langchain_cohere.react_multi_hop.agent.create_cohere_react_agent.html) | [ChatPromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.chat.ChatPromptTemplate.html) | [AgentExecutor](https://python.langchain.com/api_reference/langchain/agents/langchain.agents.agent.AgentExecutor.html)

The ReAct agent can be used to call multiple tools in sequence.

### RAG Retriever[​](#rag-retriever "Direct link to RAG Retriever")

```
from langchain_cohere import ChatCohere  
from langchain.retrievers import CohereRagRetriever  
from langchain_core.documents import Document  
  
rag = CohereRagRetriever(llm=ChatCohere())  
print(rag.invoke("What is cohere ai?"))  

```

**API Reference:**[ChatCohere](https://python.langchain.com/api_reference/cohere/chat_models/langchain_cohere.chat_models.ChatCohere.html) | [CohereRagRetriever](https://python.langchain.com/api_reference/community/retrievers/langchain_community.retrievers.cohere_rag_retriever.CohereRagRetriever.html) | [Document](https://python.langchain.com/api_reference/core/documents/langchain_core.documents.base.Document.html)

Usage of the Cohere [RAG Retriever](/docs/integrations/retrievers/cohere/)

### Text Embedding[​](#text-embedding "Direct link to Text Embedding")

```
from langchain_cohere import CohereEmbeddings  
  
embeddings = CohereEmbeddings(model="embed-english-light-v3.0")  
print(embeddings.embed_documents(["This is a test document."]))  

```

**API Reference:**[CohereEmbeddings](https://python.langchain.com/api_reference/cohere/embeddings/langchain_cohere.embeddings.CohereEmbeddings.html)

Usage of the Cohere [Text Embeddings model](/docs/integrations/text_embedding/cohere/)

### Reranker[​](#reranker "Direct link to Reranker")

Usage of the Cohere [Reranker](/docs/integrations/retrievers/cohere-reranker/)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/cohere.mdx)