# Source: https://python.langchain.com/docs/integrations/llms/stochasticai/

* [Components](/docs/integrations/components/)
* Other
* [LLMs](/docs/integrations/llms/)
* StochasticAI

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/llms/stochasticai.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/llms/stochasticai.ipynb)

# StochasticAI

> [Stochastic Acceleration Platform](https://docs.stochastic.ai/docs/introduction/) aims to simplify the life cycle of a Deep Learning model. From uploading and versioning the model, through training, compression and acceleration to putting it into production.

This example goes over how to use LangChain to interact with `StochasticAI` models.

You have to get the API\_KEY and the API\_URL [here](https://app.stochastic.ai/workspace/profile/settings?tab=profile).

```
from getpass import getpass  
  
STOCHASTICAI_API_KEY = getpass()  

```

```
 ········  

```

```
import os  
  
os.environ["STOCHASTICAI_API_KEY"] = STOCHASTICAI_API_KEY  

```

```
YOUR_API_URL = getpass()  

```

```
 ········  

```

```
from langchain.chains import LLMChain  
from langchain_community.llms import StochasticAI  
from langchain_core.prompts import PromptTemplate  

```

**API Reference:**[LLMChain](https://python.langchain.com/api_reference/langchain/chains/langchain.chains.llm.LLMChain.html) | [StochasticAI](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.stochasticai.StochasticAI.html) | [PromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.prompt.PromptTemplate.html)

```
template = """Question: {question}  
  
Answer: Let's think step by step."""  
  
prompt = PromptTemplate.from_template(template)  

```

```
llm = StochasticAI(api_url=YOUR_API_URL)  

```

```
llm_chain = LLMChain(prompt=prompt, llm=llm)  

```

```
question = "What NFL team won the Super Bowl in the year Justin Beiber was born?"  
  
llm_chain.run(question)  

```

```
"\n\nStep 1: In 1999, the St. Louis Rams won the Super Bowl.\n\nStep 2: In 1999, Beiber was born.\n\nStep 3: The Rams were in Los Angeles at the time.\n\nStep 4: So they didn't play in the Super Bowl that year.\n"  

```

## Related[​](#related "Direct link to Related")

* LLM [conceptual guide](/docs/concepts/text_llms/)
* LLM [how-to guides](/docs/how_to/#llms)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/llms/stochasticai.ipynb)