# Source: https://python.langchain.com/docs/integrations/providers/iugu/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Iugu

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/iugu.mdx)

# Iugu

> [Iugu](https://www.iugu.com/) is a Brazilian services and software as a service (SaaS)
> company. It offers payment-processing software and application programming
> interfaces for e-commerce websites and mobile applications.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

The `Iugu API` requires an access token, which can be found inside of the `Iugu` dashboard.

## Document Loader[​](#document-loader "Direct link to Document Loader")

See a [usage example](/docs/integrations/document_loaders/iugu/).

```
from langchain_community.document_loaders import IuguLoader  

```

**API Reference:**[IuguLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.iugu.IuguLoader.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/iugu.mdx)