# Source: https://python.langchain.com/docs/integrations/chat/yandex/

* [Components](/docs/integrations/components/)
* [Chat models](/docs/integrations/chat/)
* YandexGPT

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/yandex.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/yandex.ipynb)

# ChatYandexGPT

This notebook goes over how to use Langchain with [YandexGPT](https://cloud.yandex.com/en/services/yandexgpt) chat model.

To use, you should have the `yandexcloud` python package installed.

```
%pip install --upgrade --quiet  yandexcloud  

```

First, you should [create service account](https://cloud.yandex.com/en/docs/iam/operations/sa/create) with the `ai.languageModels.user` role.

Next, you have two authentication options:

* [IAM token](https://cloud.yandex.com/en/docs/iam/operations/iam-token/create-for-sa).
  You can specify the token in a constructor parameter `iam_token` or in an environment variable `YC_IAM_TOKEN`.
* [API key](https://cloud.yandex.com/en/docs/iam/operations/api-key/create)
  You can specify the key in a constructor parameter `api_key` or in an environment variable `YC_API_KEY`.

To specify the model you can use `model_uri` parameter, see [the documentation](https://cloud.yandex.com/en/docs/yandexgpt/concepts/models#yandexgpt-generation) for more details.

By default, the latest version of `yandexgpt-lite` is used from the folder specified in the parameter `folder_id` or `YC_FOLDER_ID` environment variable.

```
from langchain_community.chat_models import ChatYandexGPT  
from langchain_core.messages import HumanMessage, SystemMessage  

```

**API Reference:**[ChatYandexGPT](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.yandex.ChatYandexGPT.html) | [HumanMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.human.HumanMessage.html) | [SystemMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.system.SystemMessage.html)

```
chat_model = ChatYandexGPT()  

```

```
answer = chat_model.invoke(  
    [  
        SystemMessage(  
            content="You are a helpful assistant that translates English to French."  
        ),  
        HumanMessage(content="I love programming."),  
    ]  
)  
answer  

```

```
AIMessage(content='Je adore le programmement.')  

```

## Related[​](#related "Direct link to Related")

* Chat model [conceptual guide](/docs/concepts/chat_models/)
* Chat model [how-to guides](/docs/how_to/#chat-models)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/chat/yandex.ipynb)