# Source: https://python.langchain.com/docs/integrations/providers/docarray/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* DocArray

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/docarray.mdx)

# DocArray

> [DocArray](https://docarray.jina.ai/) is a library for nested, unstructured, multimodal data in transit,
> including text, image, audio, video, 3D mesh, etc. It allows deep-learning engineers to efficiently process,
> embed, search, recommend, store, and transfer multimodal data with a Pythonic API.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

We need to install `docarray` python package.

```
pip install docarray  

```

## Vector Store[​](#vector-store "Direct link to Vector Store")

LangChain provides an access to the `In-memory` and `HNSW` vector stores from the `DocArray` library.

See a [usage example](/docs/integrations/vectorstores/docarray_hnsw/).

```
from langchain_community.vectorstores import DocArrayHnswSearch  

```

**API Reference:**[DocArrayHnswSearch](https://python.langchain.com/api_reference/community/vectorstores/langchain_community.vectorstores.docarray.hnsw.DocArrayHnswSearch.html)

See a [usage example](/docs/integrations/vectorstores/docarray_in_memory/).

```
from langchain_community.vectorstores DocArrayInMemorySearch  

```

## Retriever[​](#retriever "Direct link to Retriever")

See a [usage example](/docs/integrations/retrievers/docarray_retriever/).

```
from langchain_community.retrievers import DocArrayRetriever  

```

**API Reference:**[DocArrayRetriever](https://python.langchain.com/api_reference/community/retrievers/langchain_community.retrievers.docarray.DocArrayRetriever.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/docarray.mdx)