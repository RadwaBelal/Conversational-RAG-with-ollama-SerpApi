# Source: https://python.langchain.com/docs/integrations/providers/falkordb/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* FalkorDB

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/falkordb.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/falkordb.ipynb)

# FalkorDB

> What is `FalkorDB`?

> * FalkorDB is an `open-source database management system` that specializes in graph database technology.
> * FalkorDB allows you to represent and store data in nodes and edges, making it ideal for handling connected data and relationships.
> * FalkorDB Supports OpenCypher query language with proprietary extensions, making it easy to interact with and query your graph data.
> * With FalkorDB, you can achieve high-performance `graph traversals and queries`, suitable for production-level systems.

> Get started with FalkorDB by visiting [their website](https://docs.falkordb.com/).

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

* Install the Python SDK with `pip install falkordb langchain-falkordb`

## VectorStore[​](#vectorstore "Direct link to VectorStore")

The FalkorDB vector index is used as a vectorstore,
whether for semantic search or example selection.

```
from langchain_community.vectorstores.falkordb_vector import FalkorDBVector  

```

**API Reference:**[FalkorDBVector](https://python.langchain.com/api_reference/community/vectorstores/langchain_community.vectorstores.falkordb_vector.FalkorDBVector.html)

or

```
from langchain_falkordb.vectorstore import FalkorDBVector  

```

See a [usage example](/docs/integrations/vectorstores/falkordbvector/)

## Memory[​](#memory "Direct link to Memory")

See a [usage example](/docs/integrations/memory/falkordb_chat_message_history/).

```
from langchain_falkordb.message_history import (  
    FalkorDBChatMessageHistory,  
)  

```

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/falkordb.ipynb)