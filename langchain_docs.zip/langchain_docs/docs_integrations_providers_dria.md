# Source: https://python.langchain.com/docs/integrations/providers/dria/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Dria

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/dria.mdx)

# Dria

> [Dria](https://dria.co/) is a hub of public RAG models for developers to
> both contribute and utilize a shared embedding lake.

See more details about the LangChain integration with Dria
at [this page](https://dria.co/docs/integrations/langchain).

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

You have to install a python package:

```
pip install dria  

```

You have to get an API key from Dria. You can get it by signing up at [Dria](https://dria.co/).

## Retrievers[​](#retrievers "Direct link to Retrievers")

See a [usage example](/docs/integrations/retrievers/dria_index/).

```
from langchain_community.retrievers import DriaRetriever  

```

**API Reference:**[DriaRetriever](https://python.langchain.com/api_reference/community/retrievers/langchain_community.retrievers.dria_index.DriaRetriever.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/dria.mdx)