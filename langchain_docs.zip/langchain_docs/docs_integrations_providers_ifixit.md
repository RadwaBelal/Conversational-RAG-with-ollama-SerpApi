# Source: https://python.langchain.com/docs/integrations/providers/ifixit/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* iFixit

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/ifixit.mdx)

# iFixit

> [iFixit](https://www.ifixit.com) is the largest, open repair community on the web. The site contains nearly 100k
> repair manuals, 200k Questions & Answers on 42k devices, and all the data is licensed under `CC-BY-NC-SA 3.0`.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

There isn't any special setup for it.

## Document Loader[​](#document-loader "Direct link to Document Loader")

See a [usage example](/docs/integrations/document_loaders/ifixit/).

```
from langchain_community.document_loaders import IFixitLoader  

```

**API Reference:**[IFixitLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.ifixit.IFixitLoader.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/ifixit.mdx)