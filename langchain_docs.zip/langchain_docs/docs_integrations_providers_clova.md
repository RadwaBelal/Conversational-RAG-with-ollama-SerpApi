# Source: https://python.langchain.com/docs/integrations/providers/clova/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Clova

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/clova.mdx)

# Clova

> [CLOVA Studio](https://api.ncloud-docs.com/docs/ai-naver-clovastudio-summary) is a service
> of [Naver Cloud Platform](https://www.ncloud.com/) that uses `HyperCLOVA` language models,
> a hyperscale AI technology, to output phrases generated through AI technology based on user input.

## Embedding models[​](#embedding-models "Direct link to Embedding models")

See [installation instructions and usage example](/docs/integrations/text_embedding/clova/).

```
from langchain_community.embeddings import ClovaEmbeddings  

```

**API Reference:**[ClovaEmbeddings](https://python.langchain.com/api_reference/community/embeddings/langchain_community.embeddings.clova.ClovaEmbeddings.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/clova.mdx)