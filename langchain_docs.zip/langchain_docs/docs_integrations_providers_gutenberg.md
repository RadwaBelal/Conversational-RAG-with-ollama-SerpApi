# Source: https://python.langchain.com/docs/integrations/providers/gutenberg/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Gutenberg

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/gutenberg.mdx)

# Gutenberg

> [Project Gutenberg](https://www.gutenberg.org/about/) is an online library of free eBooks.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

There isn't any special setup for it.

## Document Loader[​](#document-loader "Direct link to Document Loader")

See a [usage example](/docs/integrations/document_loaders/gutenberg/).

```
from langchain_community.document_loaders import GutenbergLoader  

```

**API Reference:**[GutenbergLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.gutenberg.GutenbergLoader.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/gutenberg.mdx)