# Source: https://python.langchain.com/docs/how_to/toolkits/

* [How-to guides](/docs/how_to/)
* How to use toolkits

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/how_to/toolkits.mdx)

# How to use toolkits

Toolkits are collections of tools that are designed to be used together for specific tasks. They have convenient loading methods.

All Toolkits expose a `get_tools` method which returns a list of tools.
You can therefore do:

```
# Initialize a toolkit  
toolkit = ExampleTookit(...)  
  
# Get list of tools  
tools = toolkit.get_tools()  
  
# Create agent  
agent = create_agent_method(llm, tools, prompt)  

```

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/how_to/toolkits.mdx)