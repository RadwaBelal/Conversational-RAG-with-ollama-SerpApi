# Source: https://python.langchain.com/docs/integrations/providers/acreom/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Acreom

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/acreom.mdx)

# Acreom

[acreom](https://acreom.com) is a dev-first knowledge base with tasks running on local `markdown` files.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

No installation is required.

## Document Loader[​](#document-loader "Direct link to Document Loader")

See a [usage example](/docs/integrations/document_loaders/acreom/).

```
from langchain_community.document_loaders import AcreomLoader  

```

**API Reference:**[AcreomLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.acreom.AcreomLoader.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/acreom.mdx)