# Source: https://python.langchain.com/docs/integrations/providers/ads4gpts/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* ADS4GPTs

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/ads4gpts.mdx)

# ADS4GPTs

> [ADS4GPTs](https://www.ads4gpts.com/) is building the open monetization backbone of the AI-Native internet. It helps AI applications monetize through advertising with a UX and Privacy first approach.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

### Using pip[​](#using-pip "Direct link to Using pip")

You can install the package directly from PyPI:

```
pip install ads4gpts-langchain  

```

### From Source[​](#from-source "Direct link to From Source")

Alternatively, install from source:

```
git clone https://github.com/ADS4GPTs/ads4gpts.git  
cd ads4gpts/libs/python-sdk/ads4gpts-langchain  
pip install .  

```

## Prerequisites[​](#prerequisites "Direct link to Prerequisites")

* Python 3.11+
* ADS4GPTs API Key ([Obtain API Key](https://www.ads4gpts.com))

## Environment Variables[​](#environment-variables "Direct link to Environment Variables")

Set the following environment variables for API authentication:

```
export ADS4GPTS_API_KEY='your-ads4gpts-api-key'  

```

Alternatively, API keys can be passed directly when initializing classes or stored in a `.env` file.

## Tools[​](#tools "Direct link to Tools")

ADS4GPTs provides two main tools for monetization:

### Ads4gptsInlineSponsoredResponseTool[​](#ads4gptsinlinesponsoredresponsetool "Direct link to Ads4gptsInlineSponsoredResponseTool")

This tool fetches native, sponsored responses that can be seamlessly integrated within your AI application's outputs.

```
from ads4gpts_langchain import Ads4gptsInlineSponsoredResponseTool  

```

### Ads4gptsSuggestedPromptTool[​](#ads4gptssuggestedprompttool "Direct link to Ads4gptsSuggestedPromptTool")

Generates sponsored prompt suggestions to enhance user engagement and provide monetization opportunities.

```
from ads4gpts_langchain import Ads4gptsSuggestedPromptTool  

```

### Ads4gptsInlineConversationalTool[​](#ads4gptsinlineconversationaltool "Direct link to Ads4gptsInlineConversationalTool")

Delivers conversational sponsored content that naturally fits within chat interfaces and dialogs.

```
from ads4gpts_langchain import Ads4gptsInlineConversationalTool  

```

### Ads4gptsInlineBannerTool[​](#ads4gptsinlinebannertool "Direct link to Ads4gptsInlineBannerTool")

Provides inline banner advertisements that can be displayed within your AI application's response.

```
from ads4gpts_langchain import Ads4gptsInlineBannerTool  

```

### Ads4gptsSuggestedBannerTool[​](#ads4gptssuggestedbannertool "Direct link to Ads4gptsSuggestedBannerTool")

Generates banner advertisement suggestions that can be presented to users as recommended content.

```
from ads4gpts_langchain import Ads4gptsSuggestedBannerTool  

```

## Toolkit[​](#toolkit "Direct link to Toolkit")

The `Ads4gptsToolkit` combines these tools for convenient access in LangChain applications.

```
from ads4gpts_langchain import Ads4gptsToolkit  

```

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/ads4gpts.mdx)