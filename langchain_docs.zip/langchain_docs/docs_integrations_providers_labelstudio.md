# Source: https://python.langchain.com/docs/integrations/providers/labelstudio/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Label Studio

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/labelstudio.mdx)

# Label Studio

> [Label Studio](https://labelstud.io/guide/get_started) is an open-source data labeling platform that provides LangChain with flexibility when it comes to labeling data for fine-tuning large language models (LLMs). It also enables the preparation of custom training data and the collection and evaluation of responses through human feedback.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

See the [Label Studio installation guide](https://labelstud.io/guide/install) for installation options.

We need to install the `label-studio` and `label-studio-sdk-python` Python packages:

```
pip install label-studio label-studio-sdk  

```

## Callbacks[​](#callbacks "Direct link to Callbacks")

See a [usage example](/docs/integrations/callbacks/labelstudio/).

```
from langchain.callbacks import LabelStudioCallbackHandler  

```

**API Reference:**[LabelStudioCallbackHandler](https://python.langchain.com/api_reference/community/callbacks/langchain_community.callbacks.labelstudio_callback.LabelStudioCallbackHandler.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/labelstudio.mdx)