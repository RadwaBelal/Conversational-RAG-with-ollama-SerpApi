# Source: https://python.langchain.com/docs/contributing/tutorials/

* Tutorials

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/contributing/tutorials/index.mdx)

# Tutorials

More coming soon! We are working on tutorials to help you make your first contribution to the project.

* [**Make your first docs PR**](/docs/contributing/tutorials/docs/)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/contributing/tutorials/index.mdx)