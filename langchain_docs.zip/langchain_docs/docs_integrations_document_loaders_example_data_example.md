# Source: https://python.langchain.com/docs/integrations/document_loaders/example_data/example/

* [Components](/docs/integrations/components/)
* [Document loaders](/docs/integrations/document_loaders/)
* example\_data
* Sample Markdown Document

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/example_data/example.md)

# Sample Markdown Document

## Introduction[​](#introduction "Direct link to Introduction")

Welcome to this sample Markdown document. Markdown is a lightweight markup language used for formatting text. It's widely used for documentation, readme files, and more.

## Features[​](#features "Direct link to Features")

### Headers[​](#headers "Direct link to Headers")

Markdown supports multiple levels of headers:

* **Header 1**: `# Header 1`
* **Header 2**: `## Header 2`
* **Header 3**: `### Header 3`

### Lists[​](#lists "Direct link to Lists")

#### Unordered List[​](#unordered-list "Direct link to Unordered List")

* Item 1
* Item 2
  + Subitem 2.1
  + Subitem 2.2

#### Ordered List[​](#ordered-list "Direct link to Ordered List")

1. First item
2. Second item
3. Third item

### Links[​](#links "Direct link to Links")

[OpenAI](https://www.openai.com) is an AI research organization.

### Images[​](#images "Direct link to Images")

Here's an example image:

![Sample Image](https://via.placeholder.com/150)

### Code[​](#code "Direct link to Code")

#### Inline Code[​](#inline-code "Direct link to Inline Code")

Use `code` for inline code snippets.

#### Code Block[​](#code-block "Direct link to Code Block")

```
def greet(name):  
    return f"Hello, {name}!"  
  
print(greet("World"))  

```

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/example_data/example.md)