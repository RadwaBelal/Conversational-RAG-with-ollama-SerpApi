# Source: https://python.langchain.com/docs/integrations/providers/cognee/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Cognee

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/cognee.mdx)

# Cognee

Cognee implements scalable, modular ECL (Extract, Cognify, Load) pipelines that allow
you to interconnect and retrieve past conversations, documents, and audio
transcriptions while reducing hallucinations, developer effort, and cost.

Cognee merges graph and vector databases to uncover hidden relationships and new
patterns in your data. You can automatically model, load and retrieve entities and
objects representing your business domain and analyze their relationships, uncovering
insights that neither vector stores nor graph stores alone can provide.

Try it in a Google Colab [notebook](https://colab.research.google.com/drive/1g-Qnx6l_ecHZi0IOw23rg0qC4TYvEvWZ?usp=sharing) or have a look at the [documentation](https://docs.cognee.ai).

If you have questions, join cognee [Discord](https://discord.gg/NQPKmU5CCg) community.

Have you seen cognee's [starter repo](https://github.com/topoteretes/cognee-starter)? Check it out!

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

```
pip install langchain-cognee  

```

## Retrievers[​](#retrievers "Direct link to Retrievers")

See detail on available retrievers [here](/docs/integrations/retrievers/cognee/).

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/cognee.mdx)