# Source: https://python.langchain.com/docs/integrations/chat/octoai/

* [Components](/docs/integrations/components/)
* [Chat models](/docs/integrations/chat/)
* ChatOctoAI

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/octoai.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/octoai.ipynb)

# ChatOctoAI

[OctoAI](https://docs.octoai.cloud/docs) offers easy access to efficient compute and enables users to integrate their choice of AI models into applications. The `OctoAI` compute service helps you run, tune, and scale AI applications easily.

This notebook demonstrates the use of `langchain.chat_models.ChatOctoAI` for [OctoAI endpoints](https://octoai.cloud/text).

## Setup[​](#setup "Direct link to Setup")

To run our example app, there are two simple steps to take:

1. Get an API Token from [your OctoAI account page](https://octoai.cloud/settings).
2. Paste your API token in in the code cell below or use the `octoai_api_token` keyword argument.

Note: If you want to use a different model than the [available models](https://octoai.cloud/text?selectedTags=Chat), you can containerize the model and make a custom OctoAI endpoint yourself, by following [Build a Container from Python](https://octo.ai/docs/bring-your-own-model/advanced-build-a-container-from-scratch-in-python) and [Create a Custom Endpoint from a Container](https://octo.ai/docs/bring-your-own-model/create-custom-endpoints-from-a-container/create-custom-endpoints-from-a-container) and then updating your `OCTOAI_API_BASE` environment variable.

```
import os  
  
os.environ["OCTOAI_API_TOKEN"] = "OCTOAI_API_TOKEN"  

```

```
from langchain_community.chat_models import ChatOctoAI  
from langchain_core.messages import HumanMessage, SystemMessage  

```

**API Reference:**[ChatOctoAI](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.octoai.ChatOctoAI.html) | [HumanMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.human.HumanMessage.html) | [SystemMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.system.SystemMessage.html)

## Example[​](#example "Direct link to Example")

```
chat = ChatOctoAI(max_tokens=300, model_name="mixtral-8x7b-instruct")  

```

```
messages = [  
    SystemMessage(content="You are a helpful assistant."),  
    HumanMessage(content="Tell me about Leonardo da Vinci briefly."),  
]  
print(chat(messages).content)  

```

Leonardo da Vinci (1452-1519) was an Italian polymath who is often considered one of the greatest painters in history. However, his genius extended far beyond art. He was also a scientist, inventor, mathematician, engineer, anatomist, geologist, and cartographer.

Da Vinci is best known for his paintings such as the Mona Lisa, The Last Supper, and The Virgin of the Rocks. His scientific studies were ahead of his time, and his notebooks contain detailed drawings and descriptions of various machines, human anatomy, and natural phenomena.

Despite never receiving a formal education, da Vinci's insatiable curiosity and observational skills made him a pioneer in many fields. His work continues to inspire and influence artists, scientists, and thinkers today.

## Related[​](#related "Direct link to Related")

* Chat model [conceptual guide](/docs/concepts/chat_models/)
* Chat model [how-to guides](/docs/how_to/#chat-models)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/chat/octoai.ipynb)