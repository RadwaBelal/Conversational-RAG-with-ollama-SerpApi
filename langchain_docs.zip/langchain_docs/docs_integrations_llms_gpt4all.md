# Source: https://python.langchain.com/docs/integrations/llms/gpt4all/

* [Components](/docs/integrations/components/)
* Other
* [LLMs](/docs/integrations/llms/)
* GPT4All

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/llms/gpt4all.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/llms/gpt4all.ipynb)

# GPT4All

[GitHub:nomic-ai/gpt4all](https://github.com/nomic-ai/gpt4all) an ecosystem of open-source chatbots trained on a massive collections of clean assistant data including code, stories and dialogue.

This example goes over how to use LangChain to interact with `GPT4All` models.

```
%pip install --upgrade --quiet langchain-community gpt4all  

```

### Import GPT4All[​](#import-gpt4all "Direct link to Import GPT4All")

```
from langchain_community.llms import GPT4All  
from langchain_core.prompts import PromptTemplate  

```

**API Reference:**[GPT4All](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.gpt4all.GPT4All.html) | [PromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.prompt.PromptTemplate.html)

### Set Up Question to pass to LLM[​](#set-up-question-to-pass-to-llm "Direct link to Set Up Question to pass to LLM")

```
template = """Question: {question}  
  
Answer: Let's think step by step."""  
  
prompt = PromptTemplate.from_template(template)  

```

### Specify Model[​](#specify-model "Direct link to Specify Model")

To run locally, download a compatible ggml-formatted model.

The [gpt4all page](https://gpt4all.io/index.html) has a useful `Model Explorer` section:

* Select a model of interest
* Download using the UI and move the `.bin` to the `local_path` (noted below)

For more info, visit <https://github.com/nomic-ai/gpt4all>.

---

This integration does not yet support streaming in chunks via the [`.stream()`](https://python.langchain.com/docs/how_to/streaming/) method. The below example uses a callback handler with `streaming=True`:

```
local_path = (  
    "./models/Meta-Llama-3-8B-Instruct.Q4_0.gguf"  # replace with your local file path  
)  

```

```
from langchain_core.callbacks import BaseCallbackHandler  
  
count = 0  
  
  
class MyCustomHandler(BaseCallbackHandler):  
    def on_llm_new_token(self, token: str, **kwargs) -> None:  
        global count  
        if count < 10:  
            print(f"Token: {token}")  
            count += 1  
  
  
# Verbose is required to pass to the callback manager  
llm = GPT4All(model=local_path, callbacks=[MyCustomHandler()], streaming=True)  
  
# If you want to use a custom model add the backend parameter  
# Check https://docs.gpt4all.io/gpt4all_python.html for supported backends  
# llm = GPT4All(model=local_path, backend="gptj", callbacks=callbacks, streaming=True)  
  
chain = prompt | llm  
  
question = "What NFL team won the Super Bowl in the year Justin Bieber was born?"  
  
# Streamed tokens will be logged/aggregated via the passed callback  
res = chain.invoke({"question": question})  

```

**API Reference:**[BaseCallbackHandler](https://python.langchain.com/api_reference/core/callbacks/langchain_core.callbacks.base.BaseCallbackHandler.html)

```
Token:  Justin  
Token:  Bieber  
Token:  was  
Token:  born  
Token:  on  
Token:  March  
Token:    
Token: 1  
Token: ,  
Token:  

```

## Related[​](#related "Direct link to Related")

* LLM [conceptual guide](/docs/concepts/text_llms/)
* LLM [how-to guides](/docs/how_to/#llms)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/llms/gpt4all.ipynb)