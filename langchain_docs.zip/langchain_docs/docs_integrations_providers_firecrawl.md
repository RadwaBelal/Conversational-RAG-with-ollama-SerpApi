# Source: https://python.langchain.com/docs/integrations/providers/firecrawl/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* FireCrawl

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/firecrawl.mdx)

# FireCrawl

> [FireCrawl](https://firecrawl.dev/?ref=langchain) crawls and converts any website into LLM-ready data.
> It crawls all accessible subpages and give you clean markdown
> and metadata for each. No sitemap required.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

Install the python SDK:

```
pip install firecrawl-py==0.0.20  

```

## Document loader[​](#document-loader "Direct link to Document loader")

See a [usage example](/docs/integrations/document_loaders/firecrawl/).

```
from langchain_community.document_loaders import FireCrawlLoader  

```

**API Reference:**[FireCrawlLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.firecrawl.FireCrawlLoader.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/firecrawl.mdx)