# Source: https://python.langchain.com/docs/integrations/providers/clickhouse/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* ClickHouse

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/clickhouse.mdx)

# ClickHouse

> [ClickHouse](https://clickhouse.com/) is the fast and resource efficient open-source database for real-time
> apps and analytics with full SQL support and a wide range of functions to assist users in writing analytical queries.
> It has data structures and distance search functions (like `L2Distance`) as well as
> [approximate nearest neighbor search indexes](https://clickhouse.com/docs/en/engines/table-engines/mergetree-family/annindexes)
> That enables ClickHouse to be used as a high performance and scalable vector database to store and search vectors with SQL.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

We need to install `clickhouse-connect` python package.

```
pip install clickhouse-connect  

```

## Vector Store[​](#vector-store "Direct link to Vector Store")

See a [usage example](/docs/integrations/vectorstores/clickhouse/).

```
from langchain_community.vectorstores import Clickhouse, ClickhouseSettings  

```

**API Reference:**[Clickhouse](https://python.langchain.com/api_reference/community/vectorstores/langchain_community.vectorstores.clickhouse.Clickhouse.html) | [ClickhouseSettings](https://python.langchain.com/api_reference/community/vectorstores/langchain_community.vectorstores.clickhouse.ClickhouseSettings.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/clickhouse.mdx)