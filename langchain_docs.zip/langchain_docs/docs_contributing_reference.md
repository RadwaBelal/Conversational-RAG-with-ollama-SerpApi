# Source: https://python.langchain.com/docs/contributing/reference/

* Reference & FAQ

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/contributing/reference/index.mdx)

# Reference

* [**Repository Structure**](/docs/contributing/reference/repo_structure/): Understand the high level structure of the repository.
* [**Review Process**](/docs/contributing/reference/review_process/): Learn about the review process for pull requests.
* [**Frequently Asked Questions (FAQ)**](/docs/contributing/reference/faq/): Get answers to common questions about contributing.

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/contributing/reference/index.mdx)