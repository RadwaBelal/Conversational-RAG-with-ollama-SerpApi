# Source: https://python.langchain.com/docs/how_to/tool_calling_parallel/

* [How-to guides](/docs/how_to/)
* How to disable parallel tool calling

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/how_to/tool_calling_parallel.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/how_to/tool_calling_parallel.ipynb)

# How to disable parallel tool calling

Provider-specific

This API is currently only supported by OpenAI and Anthropic.

OpenAI tool calling performs tool calling in parallel by default. That means that if we ask a question like "What is the weather in Tokyo, New York, and Chicago?" and we have a tool for getting the weather, it will call the tool 3 times in parallel. We can force it to call only a single tool once by using the `parallel_tool_call` parameter.

First let's set up our tools and model:

```
from langchain_core.tools import tool  
  
  
@tool  
def add(a: int, b: int) -> int:  
    """Adds a and b."""  
    return a + b  
  
  
@tool  
def multiply(a: int, b: int) -> int:  
    """Multiplies a and b."""  
    return a * b  
  
  
tools = [add, multiply]  

```

**API Reference:**[tool](https://python.langchain.com/api_reference/core/tools/langchain_core.tools.convert.tool.html)

```
import os  
from getpass import getpass  
  
from langchain.chat_models import init_chat_model  
  
if "OPENAI_API_KEY" not in os.environ:  
    os.environ["OPENAI_API_KEY"] = getpass()  
  
llm = init_chat_model("openai:gpt-4.1-mini")  

```

**API Reference:**[init\_chat\_model](https://python.langchain.com/api_reference/langchain/chat_models/langchain.chat_models.base.init_chat_model.html)

Now let's show a quick example of how disabling parallel tool calls work:

```
llm_with_tools = llm.bind_tools(tools, parallel_tool_calls=False)  
llm_with_tools.invoke("Please call the first tool two times").tool_calls  

```

```
[{'name': 'add',  
  'args': {'a': 2, 'b': 2},  
  'id': 'call_Hh4JOTCDM85Sm9Pr84VKrWu5'}]  

```

As we can see, even though we explicitly told the model to call a tool twice, by disabling parallel tool calls the model was constrained to only calling one.

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/how_to/tool_calling_parallel.ipynb)