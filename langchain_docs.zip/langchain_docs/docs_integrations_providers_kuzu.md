# Source: https://python.langchain.com/docs/integrations/providers/kuzu/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Kùzu

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/kuzu.mdx)

# Kùzu

> [Kùzu](https://kuzudb.com/) is an embeddable, scalable, extremely fast graph database.
> It is permissively licensed with an MIT license, and you can see its source code [here](https://github.com/kuzudb/kuzu).

> Key characteristics of Kùzu:
>
> * Performance and scalability: Implements modern, state-of-the-art join algorithms for graphs.
> * Usability: Very easy to set up and get started with, as there are no servers (embedded architecture).
> * Interoperability: Can conveniently scan and copy data from external columnar formats, CSV, JSON and relational databases.
> * Structured property graph model: Implements the property graph model, with added structure.
> * Cypher support: Allows convenient querying of the graph in Cypher, a declarative query language.

> Get started with Kùzu by visiting their [documentation](https://docs.kuzudb.com/).

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

Install the Python SDK as follows:

```
pip install -U langchain-kuzu  

```

## Usage[​](#usage "Direct link to Usage")

## Graphs[​](#graphs "Direct link to Graphs")

See a [usage example](/docs/integrations/graphs/kuzu_db/).

```
from langchain_kuzu.graphs.kuzu_graph import KuzuGraph  

```

## Chains[​](#chains "Direct link to Chains")

See a [usage example](/docs/integrations/graphs/kuzu_db/#creating-kuzuqachain).

```
from langchain_kuzu.chains.graph_qa.kuzu import KuzuQAChain  

```

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/kuzu.mdx)