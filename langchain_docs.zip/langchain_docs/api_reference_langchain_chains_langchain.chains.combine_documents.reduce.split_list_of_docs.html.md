# Source: https://python.langchain.com/api_reference/langchain/chains/langchain.chains.combine_documents.reduce.split_list_of_docs.html

# split\_list\_of\_docs[#](#split-list-of-docs "Link to this heading")

langchain.chains.combine\_documents.reduce.split\_list\_of\_docs( : *docs: list[[Document](../../core/documents/langchain_core.documents.base.Document.html#langchain_core.documents.base.Document "langchain_core.documents.base.Document")]*, : *length\_func: Callable*, : *token\_max: int*, : *\*\*kwargs: Any*, ) → list[list[[Document](../../core/documents/langchain_core.documents.base.Document.html#langchain_core.documents.base.Document "langchain_core.documents.base.Document")]][[source]](../../_modules/langchain/chains/combine_documents/reduce.html#split_list_of_docs)[#](#langchain.chains.combine_documents.reduce.split_list_of_docs "Link to this definition")
:   Split Documents into subsets that each meet a cumulative length constraint.

    Parameters:
    :   * **docs** (*list**[*[*Document*](../../core/documents/langchain_core.documents.base.Document.html#langchain_core.documents.base.Document "langchain_core.documents.base.Document")*]*) – The full list of Documents.
        * **length\_func** (*Callable*) – Function for computing the cumulative length of a set of Documents.
        * **token\_max** (*int*) – The maximum cumulative length of any subset of Documents.
        * **\*\*kwargs** (*Any*) – Arbitrary additional keyword params to pass to each call of the
          length\_func.

    Returns:
    :   A List[List[Document]].

    Return type:
    :   list[list[[*Document*](../../core/documents/langchain_core.documents.base.Document.html#langchain_core.documents.base.Document "langchain_core.documents.base.Document")]]

Examples using split\_list\_of\_docs

* [# Basic example (short documents)](https://python.langchain.com/docs/versions/migrating_chains/map_reduce_chain/)
* [How to summarize text through parallelization](https://python.langchain.com/docs/how_to/summarize_map_reduce/)
* [Summarize Text](https://python.langchain.com/docs/tutorials/summarization/)