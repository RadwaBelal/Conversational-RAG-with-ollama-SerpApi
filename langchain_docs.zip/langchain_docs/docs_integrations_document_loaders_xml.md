# Source: https://python.langchain.com/docs/integrations/document_loaders/xml/

* [Components](/docs/integrations/components/)
* [Document loaders](/docs/integrations/document_loaders/)
* UnstructuredXMLLoader

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/xml.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/xml.ipynb)

# UnstructuredXMLLoader

This notebook provides a quick overview for getting started with UnstructuredXMLLoader [document loader](https://python.langchain.com/docs/concepts/document_loaders). The `UnstructuredXMLLoader` is used to load `XML` files. The loader works with `.xml` files. The page content will be the text extracted from the XML tags.

## Overview[​](#overview "Direct link to Overview")

### Integration details[​](#integration-details "Direct link to Integration details")

| Class | Package | Local | Serializable | [JS support](https://js.langchain.com/docs/integrations/document_loaders/file_loaders/unstructured/) |
| --- | --- | --- | --- | --- |
| [UnstructuredXMLLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.xml.UnstructuredXMLLoader.html) | [langchain\_community](https://python.langchain.com/api_reference/community/index.html) | ✅ | ❌ | ✅ |

### Loader features[​](#loader-features "Direct link to Loader features")

| Source | Document Lazy Loading | Native Async Support |
| --- | --- | --- |
| UnstructuredXMLLoader | ✅ | ❌ |

## Setup[​](#setup "Direct link to Setup")

To access UnstructuredXMLLoader document loader you'll need to install the `langchain-community` integration package.

### Credentials[​](#credentials "Direct link to Credentials")

No credentials are needed to use the UnstructuredXMLLoader

To enable automated tracing of your model calls, set your [LangSmith](https://docs.smith.langchain.com/) API key:

```
# os.environ["LANGSMITH_API_KEY"] = getpass.getpass("Enter your LangSmith API key: ")  
# os.environ["LANGSMITH_TRACING"] = "true"  

```

### Installation[​](#installation "Direct link to Installation")

Install **langchain\_community**.

```
%pip install -qU langchain_community  

```

## Initialization[​](#initialization "Direct link to Initialization")

Now we can instantiate our model object and load documents:

```
from langchain_community.document_loaders import UnstructuredXMLLoader  
  
loader = UnstructuredXMLLoader(  
    "./example_data/factbook.xml",  
)  

```

**API Reference:**[UnstructuredXMLLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.xml.UnstructuredXMLLoader.html)

## Load[​](#load "Direct link to Load")

```
docs = loader.load()  
docs[0]  

```

```
Document(metadata={'source': './example_data/factbook.xml'}, page_content='United States\n\nWashington, DC\n\nJoe Biden\n\nBaseball\n\nCanada\n\nOttawa\n\nJustin Trudeau\n\nHockey\n\nFrance\n\nParis\n\nEmmanuel Macron\n\nSoccer\n\nTrinidad & Tobado\n\nPort of Spain\n\nKeith Rowley\n\nTrack & Field')  

```

```
print(docs[0].metadata)  

```

```
{'source': './example_data/factbook.xml'}  

```

## Lazy Load[​](#lazy-load "Direct link to Lazy Load")

```
page = []  
for doc in loader.lazy_load():  
    page.append(doc)  
    if len(page) >= 10:  
        # do some paged operation, e.g.  
        # index.upsert(page)  
  
        page = []  

```

## API reference[​](#api-reference "Direct link to API reference")

For detailed documentation of all \_\_ModuleName\_\_Loader features and configurations head to the API reference: <https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.xml.UnstructuredXMLLoader.html>

## Related[​](#related "Direct link to Related")

* Document loader [conceptual guide](/docs/concepts/document_loaders/)
* Document loader [how-to guides](/docs/how_to/#document-loaders)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/xml.ipynb)