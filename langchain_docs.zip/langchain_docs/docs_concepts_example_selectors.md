# Source: https://python.langchain.com/docs/concepts/example_selectors/

* [Conceptual guide](/docs/concepts/)
* Example selectors

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/concepts/example_selectors.mdx)

# Example selectors

Prerequisites

* [Chat models](/docs/concepts/chat_models/)
* [Few-shot prompting](/docs/concepts/few_shot_prompting/)

## Overview[​](#overview "Direct link to Overview")

One common prompting technique for achieving better performance is to include examples as part of the prompt. This is known as [few-shot prompting](/docs/concepts/few_shot_prompting/).

This gives the [language model](/docs/concepts/chat_models/) concrete examples of how it should behave.
Sometimes these examples are hardcoded into the prompt, but for more advanced situations it may be nice to dynamically select them.

**Example Selectors** are classes responsible for selecting and then formatting examples into prompts.

## Related resources[​](#related-resources "Direct link to Related resources")

* [Example selector how-to guides](/docs/how_to/#example-selectors)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/concepts/example_selectors.mdx)