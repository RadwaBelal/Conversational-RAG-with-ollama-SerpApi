# Source: https://python.langchain.com/docs/integrations/providers/evernote/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* EverNote

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/evernote.mdx)

# EverNote

> [EverNote](https://evernote.com/) is intended for archiving and creating notes in which photos, audio and saved web content can be embedded. Notes are stored in virtual "notebooks" and can be tagged, annotated, edited, searched, and exported.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

First, you need to install `lxml` and `html2text` python packages.

```
pip install lxml  
pip install html2text  

```

## Document Loader[​](#document-loader "Direct link to Document Loader")

See a [usage example](/docs/integrations/document_loaders/evernote/).

```
from langchain_community.document_loaders import EverNoteLoader  

```

**API Reference:**[EverNoteLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.evernote.EverNoteLoader.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/evernote.mdx)