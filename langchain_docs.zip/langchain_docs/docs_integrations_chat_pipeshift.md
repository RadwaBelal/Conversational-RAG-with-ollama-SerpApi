# Source: https://python.langchain.com/docs/integrations/chat/pipeshift/

* [Components](/docs/integrations/components/)
* [Chat models](/docs/integrations/chat/)
* Pipeshift

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/pipeshift.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/pipeshift.ipynb)

# ChatPipeshift

This will help you getting started with Pipeshift [chat models](/docs/concepts/chat_models/). For detailed documentation of all ChatPipeshift features and configurations head to the [API reference](https://dashboard.pipeshift.com/docs).

## Overview[​](#overview "Direct link to Overview")

### Integration details[​](#integration-details "Direct link to Integration details")

| Class | Package | Local | Serializable | JS support | Package downloads | Package latest |
| --- | --- | --- | --- | --- | --- | --- |
| [ChatPipeshift](https://dashboard.pipeshift.com/docs) | [langchain-pipeshift](https://pypi.org/project/langchain-pipeshift/) | ❌ | - | ❌ | PyPI - Downloads | PyPI - Version |

### Model features[​](#model-features "Direct link to Model features")

| [Tool calling](/docs/how_to/tool_calling/) | [Structured output](/docs/how_to/structured_output/) | JSON mode | [Image input](/docs/how_to/multimodal_inputs/) | Audio input | Video input | [Token-level streaming](/docs/how_to/chat_streaming/) | Native async | [Token usage](/docs/how_to/chat_token_usage_tracking/) | [Logprobs](/docs/how_to/logprobs/) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ❌ | ❌ | ✅ | ✅ | ❌ | ❌ | ✅ | ✅ | ✅ | - |

## Setup[​](#setup "Direct link to Setup")

To access Pipeshift models you'll need to create an account on Pipeshift, get an API key, and install the `langchain-pipeshift` integration package.

### Credentials[​](#credentials "Direct link to Credentials")

Head to [Pipeshift](https://dashboard.pipeshift.com) to sign up to Pipeshift and generate an API key. Once you've done this set the PIPESHIFT\_API\_KEY environment variable:

```
import getpass  
import os  
  
if not os.getenv("PIPESHIFT_API_KEY"):  
    os.environ["PIPESHIFT_API_KEY"] = getpass.getpass("Enter your Pipeshift API key: ")  

```

If you want to get automated tracing of your model calls you can also set your [LangSmith](https://docs.smith.langchain.com/) API key by uncommenting below:

```
# os.environ["LANGSMITH_TRACING"] = "true"  
# os.environ["LANGSMITH_API_KEY"] = getpass.getpass("Enter your LangSmith API key: ")  

```

### Installation[​](#installation "Direct link to Installation")

The LangChain Pipeshift integration lives in the `langchain-pipeshift` package:

```
%pip install -qU langchain-pipeshift  

```

```
Note: you may need to restart the kernel to use updated packages.  

```

## Instantiation[​](#instantiation "Direct link to Instantiation")

Now we can instantiate our model object and generate chat completions:

```
from langchain_pipeshift import ChatPipeshift  
  
llm = ChatPipeshift(  
    model="meta-llama/Meta-Llama-3.1-8B-Instruct",  
    temperature=0,  
    max_tokens=512,  
    # other params...  
)  

```

## Invocation[​](#invocation "Direct link to Invocation")

```
messages = [  
    (  
        "system",  
        "You are a helpful assistant that translates English to French. Translate the user sentence.",  
    ),  
    ("human", "I love programming."),  
]  
ai_msg = llm.invoke(messages)  
ai_msg  

```

```
AIMessage(content='Here is the translation:\n\nJe suis amoureux du programme. \n\nHowever, a more common translation would be:\n\nJ\'aime programmer.\n\nNote that "Je suis amoureux" typically implies romantic love, whereas "J\'aime" is a more casual way to express affection or enjoyment for an activity, in this case, programming.', additional_kwargs={}, response_metadata={}, id='run-5cad8e5c-d089-44a8-8dcd-22736cde7d7b-0')  

```

```
print(ai_msg.content)  

```

```
Here is the translation:  
  
Je suis amoureux du programme.   
  
However, a more common translation would be:  
  
J'aime programmer.  
  
Note that "Je suis amoureux" typically implies romantic love, whereas "J'aime" is a more casual way to express affection or enjoyment for an activity, in this case, programming.  

```

## Chaining[​](#chaining "Direct link to Chaining")

We can [chain](/docs/how_to/sequence/) our model with a prompt template like so:

```
from langchain_core.prompts import ChatPromptTemplate  
  
prompt = ChatPromptTemplate(  
    [  
        (  
            "system",  
            "You are a helpful assistant that translates {input_language} to {output_language}.",  
        ),  
        ("human", "{input}"),  
    ]  
)  
  
chain = prompt | llm  
chain.invoke(  
    {  
        "input_language": "English",  
        "output_language": "German",  
        "input": "I love programming.",  
    }  
)  

```

**API Reference:**[ChatPromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.chat.ChatPromptTemplate.html)

```
AIMessage(content="Das ist schön! Du liebst Programmieren! (That's great! You love programming!)\n\nWould you like to know the German translation of a specific programming-related term or phrase, or would you like me to help you with something else?", additional_kwargs={}, response_metadata={}, id='run-8a4b7d56-23d9-43a7-8fb2-e05f556d94bd-0')  

```

## API reference[​](#api-reference "Direct link to API reference")

For detailed documentation of all ChatPipeshift features and configurations head to the API reference: <https://dashboard.pipeshift.com/docs>

## Related[​](#related "Direct link to Related")

* Chat model [conceptual guide](/docs/concepts/chat_models/)
* Chat model [how-to guides](/docs/how_to/#chat-models)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/chat/pipeshift.ipynb)