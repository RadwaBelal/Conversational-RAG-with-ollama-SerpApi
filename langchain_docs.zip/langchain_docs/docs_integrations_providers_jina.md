# Source: https://python.langchain.com/docs/integrations/providers/jina/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Jina AI

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/jina.mdx)

# Jina AI

> [Jina AI](https://jina.ai/about-us) is a search AI company. `Jina` helps businesses and developers unlock multimodal data with a better search.

caution

For proper compatibility, please ensure you are using the `openai` SDK at version **0.x**.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

* Get a Jina AI API token from [here](https://jina.ai/embeddings/) and set it as an environment variable (`JINA_API_TOKEN`)

## Chat Models[​](#chat-models "Direct link to Chat Models")

```
from langchain_community.chat_models import JinaChat  

```

**API Reference:**[JinaChat](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.jinachat.JinaChat.html)

See a [usage examples](/docs/integrations/chat/jinachat/).

## Embedding Models[​](#embedding-models "Direct link to Embedding Models")

You can check the list of available models from [here](https://jina.ai/embeddings/)

```
from langchain_community.embeddings import JinaEmbeddings  

```

**API Reference:**[JinaEmbeddings](https://python.langchain.com/api_reference/community/embeddings/langchain_community.embeddings.jina.JinaEmbeddings.html)

See a [usage examples](/docs/integrations/text_embedding/jina/).

## Document Transformers[​](#document-transformers "Direct link to Document Transformers")

### Jina Rerank[​](#jina-rerank "Direct link to Jina Rerank")

```
from langchain_community.document_compressors import JinaRerank  

```

**API Reference:**[JinaRerank](https://python.langchain.com/api_reference/community/document_compressors/langchain_community.document_compressors.jina_rerank.JinaRerank.html)

See a [usage examples](/docs/integrations/document_transformers/jina_rerank/).

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/jina.mdx)