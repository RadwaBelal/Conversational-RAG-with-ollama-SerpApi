# Source: https://python.langchain.com/docs/integrations/components/

[## 🗃️ Chat models

87 items](/docs/integrations/chat/)

[## 🗃️ Retrievers

65 items](/docs/integrations/retrievers/)

[## 🗃️ Tools/Toolkits

136 items](/docs/integrations/tools/)

[## 🗃️ Document loaders

196 items](/docs/integrations/document_loaders/)

[## 🗃️ Vector stores

118 items](/docs/integrations/vectorstores/)

[## 🗃️ Embedding models

86 items](/docs/integrations/text_embedding/)

[## 🗃️ Other

9 items](/docs/integrations/llms/)