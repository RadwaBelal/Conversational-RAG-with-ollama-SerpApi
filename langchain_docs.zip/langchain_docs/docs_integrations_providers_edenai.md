# Source: https://python.langchain.com/docs/integrations/providers/edenai/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Eden AI

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/edenai.mdx)

# Eden AI

> [Eden AI](https://docs.edenai.co/docs/getting-started-with-eden-ai) user interface (UI)
> is designed for handling the AI projects. With `Eden AI Portal`,
> you can perform no-code AI using the best engines for the market.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

Accessing the Eden AI API requires an API key, which you can get by
[creating an account](https://app.edenai.run/user/register) and
heading [here](https://app.edenai.run/admin/account/settings).

## LLMs[​](#llms "Direct link to LLMs")

See a [usage example](/docs/integrations/llms/edenai/).

```
from langchain_community.llms import EdenAI  
  

```

**API Reference:**[EdenAI](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.edenai.EdenAI.html)

## Chat models[​](#chat-models "Direct link to Chat models")

See a [usage example](/docs/integrations/chat/edenai/).

```
from langchain_community.chat_models.edenai import ChatEdenAI  

```

**API Reference:**[ChatEdenAI](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.edenai.ChatEdenAI.html)

## Embedding models[​](#embedding-models "Direct link to Embedding models")

See a [usage example](/docs/integrations/text_embedding/edenai/).

```
from langchain_community.embeddings.edenai import EdenAiEmbeddings  

```

**API Reference:**[EdenAiEmbeddings](https://python.langchain.com/api_reference/community/embeddings/langchain_community.embeddings.edenai.EdenAiEmbeddings.html)

## Tools[​](#tools "Direct link to Tools")

Eden AI provides a list of tools that grants your Agent the ability to do multiple tasks, such as:

* speech to text
* text to speech
* text explicit content detection
* image explicit content detection
* object detection
* OCR invoice parsing
* OCR ID parsing

See a [usage example](/docs/integrations/tools/edenai_tools/).

```
from langchain_community.tools.edenai import (  
    EdenAiExplicitImageTool,  
    EdenAiObjectDetectionTool,  
    EdenAiParsingIDTool,  
    EdenAiParsingInvoiceTool,  
    EdenAiSpeechToTextTool,  
    EdenAiTextModerationTool,  
    EdenAiTextToSpeechTool,  
)  

```

**API Reference:**[EdenAiExplicitImageTool](https://python.langchain.com/api_reference/community/tools/langchain_community.tools.edenai.image_explicitcontent.EdenAiExplicitImageTool.html) | [EdenAiObjectDetectionTool](https://python.langchain.com/api_reference/community/tools/langchain_community.tools.edenai.image_objectdetection.EdenAiObjectDetectionTool.html) | [EdenAiParsingIDTool](https://python.langchain.com/api_reference/community/tools/langchain_community.tools.edenai.ocr_identityparser.EdenAiParsingIDTool.html) | [EdenAiParsingInvoiceTool](https://python.langchain.com/api_reference/community/tools/langchain_community.tools.edenai.ocr_invoiceparser.EdenAiParsingInvoiceTool.html) | [EdenAiSpeechToTextTool](https://python.langchain.com/api_reference/community/tools/langchain_community.tools.edenai.audio_speech_to_text.EdenAiSpeechToTextTool.html) | [EdenAiTextModerationTool](https://python.langchain.com/api_reference/community/tools/langchain_community.tools.edenai.text_moderation.EdenAiTextModerationTool.html) | [EdenAiTextToSpeechTool](https://python.langchain.com/api_reference/community/tools/langchain_community.tools.edenai.audio_text_to_speech.EdenAiTextToSpeechTool.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/edenai.mdx)