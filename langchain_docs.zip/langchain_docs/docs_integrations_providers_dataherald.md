# Source: https://python.langchain.com/docs/integrations/providers/dataherald/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Dataherald

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/dataherald.mdx)

# Dataherald

> [Dataherald](https://www.dataherald.com) is a natural language-to-SQL.

This page covers how to use the `Dataherald API` within LangChain.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

* Install requirements with

```
pip install dataherald  

```

* Go to dataherald and sign up [here](https://www.dataherald.com)
* Create an app and get your `API KEY`
* Set your `API KEY` as an environment variable `DATAHERALD_API_KEY`

## Wrappers[​](#wrappers "Direct link to Wrappers")

### Utility[​](#utility "Direct link to Utility")

There exists a DataheraldAPIWrapper utility which wraps this API. To import this utility:

```
from langchain_community.utilities.dataherald import DataheraldAPIWrapper  

```

**API Reference:**[DataheraldAPIWrapper](https://python.langchain.com/api_reference/community/utilities/langchain_community.utilities.dataherald.DataheraldAPIWrapper.html)

For a more detailed walkthrough of this wrapper, see [this notebook](/docs/integrations/tools/dataherald/).

### Tool[​](#tool "Direct link to Tool")

You can use the tool in an agent like this:

```
from langchain_community.utilities.dataherald import DataheraldAPIWrapper  
from langchain_community.tools.dataherald.tool import DataheraldTextToSQL  
from langchain_openai import ChatOpenAI  
from langchain import hub  
from langchain.agents import AgentExecutor, create_react_agent, load_tools  
  
api_wrapper = DataheraldAPIWrapper(db_connection_id="<db_connection_id>")  
tool = DataheraldTextToSQL(api_wrapper=api_wrapper)  
llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0)  
prompt = hub.pull("hwchase17/react")  
agent = create_react_agent(llm, tools, prompt)  
agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True, handle_parsing_errors=True)  
agent_executor.invoke({"input":"Return the sql for this question: How many employees are in the company?"})  

```

**API Reference:**[DataheraldAPIWrapper](https://python.langchain.com/api_reference/community/utilities/langchain_community.utilities.dataherald.DataheraldAPIWrapper.html) | [DataheraldTextToSQL](https://python.langchain.com/api_reference/community/tools/langchain_community.tools.dataherald.tool.DataheraldTextToSQL.html) | [ChatOpenAI](https://python.langchain.com/api_reference/openai/chat_models/langchain_openai.chat_models.base.ChatOpenAI.html) | [hub](https://python.langchain.com/api_reference/langchain/hub/langchain.hub.hub.html) | [AgentExecutor](https://python.langchain.com/api_reference/langchain/agents/langchain.agents.agent.AgentExecutor.html) | [create\_react\_agent](https://python.langchain.com/api_reference/langchain/agents/langchain.agents.react.agent.create_react_agent.html) | [load\_tools](https://python.langchain.com/api_reference/community/agent_toolkits/langchain_community.agent_toolkits.load_tools.load_tools.html)

Output

```
> Entering new AgentExecutor chain...  
I need to use a tool that can convert this question into SQL.  
Action: dataherald  
Action Input: How many employees are in the company?Answer: SELECT  
    COUNT(*) FROM employeesI now know the final answer  
Final Answer: SELECT  
    COUNT(*)  
FROM  
    employees  
  
> Finished chain.  
{'input': 'Return the sql for this question: How many employees are in the company?', 'output': "SELECT \n    COUNT(*)\nFROM \n    employees"}  

```

For more information on tools, see [this page](/docs/how_to/tools_builtin/).

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/dataherald.mdx)