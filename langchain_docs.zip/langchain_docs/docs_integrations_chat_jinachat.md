# Source: https://python.langchain.com/docs/integrations/chat/jinachat/

* [Components](/docs/integrations/components/)
* [Chat models](/docs/integrations/chat/)
* JinaChat

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/jinachat.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/jinachat.ipynb)

# JinaChat

This notebook covers how to get started with JinaChat chat models.

```
from langchain_community.chat_models import JinaChat  
from langchain_core.messages import HumanMessage, SystemMessage  
from langchain_core.prompts.chat import (  
    ChatPromptTemplate,  
    HumanMessagePromptTemplate,  
    SystemMessagePromptTemplate,  
)  

```

**API Reference:**[JinaChat](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.jinachat.JinaChat.html) | [HumanMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.human.HumanMessage.html) | [SystemMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.system.SystemMessage.html) | [ChatPromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.chat.ChatPromptTemplate.html) | [HumanMessagePromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.chat.HumanMessagePromptTemplate.html) | [SystemMessagePromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.chat.SystemMessagePromptTemplate.html)

```
chat = JinaChat(temperature=0)  

```

```
messages = [  
    SystemMessage(  
        content="You are a helpful assistant that translates English to French."  
    ),  
    HumanMessage(  
        content="Translate this sentence from English to French. I love programming."  
    ),  
]  
chat(messages)  

```

```
AIMessage(content="J'aime programmer.", additional_kwargs={}, example=False)  

```

You can make use of templating by using a `MessagePromptTemplate`. You can build a `ChatPromptTemplate` from one or more `MessagePromptTemplates`. You can use `ChatPromptTemplate`'s `format_prompt` -- this returns a `PromptValue`, which you can convert to a string or Message object, depending on whether you want to use the formatted value as input to an llm or chat model.

For convenience, there is a `from_template` method exposed on the template. If you were to use this template, this is what it would look like:

```
template = (  
    "You are a helpful assistant that translates {input_language} to {output_language}."  
)  
system_message_prompt = SystemMessagePromptTemplate.from_template(template)  
human_template = "{text}"  
human_message_prompt = HumanMessagePromptTemplate.from_template(human_template)  

```

```
chat_prompt = ChatPromptTemplate.from_messages(  
    [system_message_prompt, human_message_prompt]  
)  
  
# get a chat completion from the formatted messages  
chat(  
    chat_prompt.format_prompt(  
        input_language="English", output_language="French", text="I love programming."  
    ).to_messages()  
)  

```

```
AIMessage(content="J'aime programmer.", additional_kwargs={}, example=False)  

```

## Related[​](#related "Direct link to Related")

* Chat model [conceptual guide](/docs/concepts/chat_models/)
* Chat model [how-to guides](/docs/how_to/#chat-models)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/chat/jinachat.ipynb)