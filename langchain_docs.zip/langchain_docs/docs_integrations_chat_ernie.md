# Source: https://python.langchain.com/docs/integrations/chat/ernie/

* [Components](/docs/integrations/components/)
* [Chat models](/docs/integrations/chat/)
* Ernie Bot Chat

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/ernie.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/ernie.ipynb)

# ErnieBotChat

[ERNIE-Bot](https://cloud.baidu.com/doc/WENXINWORKSHOP/s/jlil56u11) is a large language model developed by Baidu, covering a huge amount of Chinese data.
This notebook covers how to get started with ErnieBot chat models.

**Deprecated Warning**

We recommend users using `langchain_community.chat_models.ErnieBotChat`
to use `langchain_community.chat_models.QianfanChatEndpoint` instead.

documentation for `QianfanChatEndpoint` is [here](/docs/integrations/chat/baidu_qianfan_endpoint/).

they are 4 why we recommend users to use `QianfanChatEndpoint`:

1. `QianfanChatEndpoint` support more LLM in the Qianfan platform.
2. `QianfanChatEndpoint` support streaming mode.
3. `QianfanChatEndpoint` support function calling usgage.
4. `ErnieBotChat` is lack of maintenance and deprecated.

Some tips for migration:

* change `ernie_client_id` to `qianfan_ak`, also change `ernie_client_secret` to `qianfan_sk`.
* install `qianfan` package. like `pip install qianfan`
* change `ErnieBotChat` to `QianfanChatEndpoint`.

```
from langchain_community.chat_models.baidu_qianfan_endpoint import QianfanChatEndpoint  
  
chat = QianfanChatEndpoint(  
    qianfan_ak="your qianfan ak",  
    qianfan_sk="your qianfan sk",  
)  

```

**API Reference:**[QianfanChatEndpoint](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.baidu_qianfan_endpoint.QianfanChatEndpoint.html)

## Usage[​](#usage "Direct link to Usage")

```
from langchain_community.chat_models import ErnieBotChat  
from langchain_core.messages import HumanMessage  
  
chat = ErnieBotChat(  
    ernie_client_id="YOUR_CLIENT_ID", ernie_client_secret="YOUR_CLIENT_SECRET"  
)  

```

**API Reference:**[ErnieBotChat](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.ernie.ErnieBotChat.html) | [HumanMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.human.HumanMessage.html)

or you can set `client_id` and `client_secret` in your environment variables

```
export ERNIE_CLIENT_ID=YOUR_CLIENT_ID  
export ERNIE_CLIENT_SECRET=YOUR_CLIENT_SECRET  

```

```
chat([HumanMessage(content="hello there, who are you?")])  

```

```
AIMessage(content='Hello, I am an artificial intelligence language model. My purpose is to help users answer questions or provide information. What can I do for you?', additional_kwargs={}, example=False)  

```

## Related[​](#related "Direct link to Related")

* Chat model [conceptual guide](/docs/concepts/chat_models/)
* Chat model [how-to guides](/docs/how_to/#chat-models)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/chat/ernie.ipynb)