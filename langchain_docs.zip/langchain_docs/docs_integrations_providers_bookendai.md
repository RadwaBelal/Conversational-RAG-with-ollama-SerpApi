# Source: https://python.langchain.com/docs/integrations/providers/bookendai/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* bookend.ai

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/bookendai.mdx)

# bookend.ai

LangChain implements an integration with embeddings provided by [bookend.ai](https://bookend.ai/).

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

You need to register and get the `API_KEY`
from the [bookend.ai](https://bookend.ai/) website.

## Embedding model[​](#embedding-model "Direct link to Embedding model")

See a [usage example](/docs/integrations/text_embedding/bookend/).

```
from langchain_community.embeddings import BookendEmbeddings  

```

**API Reference:**[BookendEmbeddings](https://python.langchain.com/api_reference/community/embeddings/langchain_community.embeddings.bookend.BookendEmbeddings.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/bookendai.mdx)