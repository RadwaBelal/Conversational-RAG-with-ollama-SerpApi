# Source: https://python.langchain.com/docs/integrations/providers/embedchain/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Embedchain

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/embedchain.mdx)

# Embedchain

> [Embedchain](https://github.com/embedchain/embedchain) is a RAG framework to create
> data pipelines. It loads, indexes, retrieves and syncs all the data.
>
> It is available as an [open source package](https://github.com/embedchain/embedchain)
> and as a [hosted platform solution](https://app.embedchain.ai/).

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

Install the package using pip:

```
pip install embedchain  

```

## Retriever[​](#retriever "Direct link to Retriever")

See a [usage example](/docs/integrations/retrievers/embedchain/).

```
from langchain_community.retrievers import EmbedchainRetriever  

```

**API Reference:**[EmbedchainRetriever](https://python.langchain.com/api_reference/community/retrievers/langchain_community.retrievers.embedchain.EmbedchainRetriever.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/embedchain.mdx)