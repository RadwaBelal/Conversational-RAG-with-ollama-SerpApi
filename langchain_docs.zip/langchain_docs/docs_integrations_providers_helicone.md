# Source: https://python.langchain.com/docs/integrations/providers/helicone/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Helicone

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/helicone.mdx)

# Helicone

This page covers how to use the [Helicone](https://helicone.ai) ecosystem within LangChain.

## What is Helicone?[​](#what-is-helicone "Direct link to What is Helicone?")

Helicone is an [open-source](https://github.com/Helicone/helicone) observability platform that proxies your OpenAI traffic and provides you key insights into your spend, latency and usage.

![Screenshot of the Helicone dashboard showing average requests per day, response time, tokens per response, total cost, and a graph of requests over time.](/assets/images/HeliconeDashboard-970ab0eafd8e923ccf955c5403158aae.png "Helicone Dashboard")

## Quick start[​](#quick-start "Direct link to Quick start")

With your LangChain environment you can just add the following parameter.

```
export OPENAI_API_BASE="https://oai.hconeai.com/v1"  

```

Now head over to [helicone.ai](https://www.helicone.ai/signup) to create your account, and add your OpenAI API key within our dashboard to view your logs.

![Interface for entering and managing OpenAI API keys in the Helicone dashboard.](/assets/images/HeliconeKeys-9ff580101e3a63ee05e2fa67b8def03c.png "Helicone API Key Input")

## How to enable Helicone caching[​](#how-to-enable-helicone-caching "Direct link to How to enable Helicone caching")

```
from langchain_openai import OpenAI  
import openai  
openai.api_base = "https://oai.hconeai.com/v1"  
  
llm = OpenAI(temperature=0.9, headers={"Helicone-Cache-Enabled": "true"})  
text = "What is a helicone?"  
print(llm.invoke(text))  

```

**API Reference:**[OpenAI](https://python.langchain.com/api_reference/openai/llms/langchain_openai.llms.base.OpenAI.html)

[Helicone caching docs](https://docs.helicone.ai/advanced-usage/caching)

## How to use Helicone custom properties[​](#how-to-use-helicone-custom-properties "Direct link to How to use Helicone custom properties")

```
from langchain_openai import OpenAI  
import openai  
openai.api_base = "https://oai.hconeai.com/v1"  
  
llm = OpenAI(temperature=0.9, headers={  
        "Helicone-Property-Session": "24",  
        "Helicone-Property-Conversation": "support_issue_2",  
        "Helicone-Property-App": "mobile",  
      })  
text = "What is a helicone?"  
print(llm.invoke(text))  

```

**API Reference:**[OpenAI](https://python.langchain.com/api_reference/openai/llms/langchain_openai.llms.base.OpenAI.html)

[Helicone property docs](https://docs.helicone.ai/advanced-usage/custom-properties)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/helicone.mdx)