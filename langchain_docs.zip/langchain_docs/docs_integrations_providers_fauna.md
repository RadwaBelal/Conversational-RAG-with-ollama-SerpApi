# Source: https://python.langchain.com/docs/integrations/providers/fauna/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Fauna

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/fauna.mdx)

# Fauna

> [Fauna](https://fauna.com/) is a distributed document-relational database
> that combines the flexibility of documents with the power of a relational,
> ACID compliant database that scales across regions, clouds or the globe.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

We have to get the secret key.
See the detailed [guide](https://docs.fauna.com/fauna/current/learn/security_model/).

We have to install the `fauna` package.

```
pip install -U fauna  

```

## Document Loader[​](#document-loader "Direct link to Document Loader")

See a [usage example](/docs/integrations/document_loaders/fauna/).

```
from langchain_community.document_loaders.fauna import FaunaLoader  

```

**API Reference:**[FaunaLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.fauna.FaunaLoader.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/fauna.mdx)