# Source: https://python.langchain.com/docs/integrations/document_loaders/stripe/

* [Components](/docs/integrations/components/)
* [Document loaders](/docs/integrations/document_loaders/)
* Stripe

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/stripe.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/stripe.ipynb)

# Stripe

> [Stripe](https://stripe.com/en-ca) is an Irish-American financial services and software as a service (SaaS) company. It offers payment-processing software and application programming interfaces for e-commerce websites and mobile applications.

This notebook covers how to load data from the `Stripe REST API` into a format that can be ingested into LangChain, along with example usage for vectorization.

```
from langchain.indexes import VectorstoreIndexCreator  
from langchain_community.document_loaders import StripeLoader  

```

**API Reference:**[VectorstoreIndexCreator](https://python.langchain.com/api_reference/langchain/indexes/langchain.indexes.vectorstore.VectorstoreIndexCreator.html) | [StripeLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.stripe.StripeLoader.html)

The Stripe API requires an access token, which can be found inside of the Stripe dashboard.

This document loader also requires a `resource` option which defines what data you want to load.

Following resources are available:

`balance_transations` [Documentation](https://stripe.com/docs/api/balance_transactions/list)

`charges` [Documentation](https://stripe.com/docs/api/charges/list)

`customers` [Documentation](https://stripe.com/docs/api/customers/list)

`events` [Documentation](https://stripe.com/docs/api/events/list)

`refunds` [Documentation](https://stripe.com/docs/api/refunds/list)

`disputes` [Documentation](https://stripe.com/docs/api/disputes/list)

```
stripe_loader = StripeLoader("charges")  

```

```
# Create a vectorstore retriever from the loader  
# see https://python.langchain.com/en/latest/modules/data_connection/getting_started.html for more details  
  
index = VectorstoreIndexCreator().from_loaders([stripe_loader])  
stripe_doc_retriever = index.vectorstore.as_retriever()  

```

## Related[​](#related "Direct link to Related")

* Document loader [conceptual guide](/docs/concepts/document_loaders/)
* Document loader [how-to guides](/docs/how_to/#document-loaders)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/stripe.ipynb)