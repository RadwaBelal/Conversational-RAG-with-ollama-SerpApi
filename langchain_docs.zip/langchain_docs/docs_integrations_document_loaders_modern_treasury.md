# Source: https://python.langchain.com/docs/integrations/document_loaders/modern_treasury/

* [Components](/docs/integrations/components/)
* [Document loaders](/docs/integrations/document_loaders/)
* Modern Treasury

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/modern_treasury.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/modern_treasury.ipynb)

# Modern Treasury

> [Modern Treasury](https://www.moderntreasury.com/) simplifies complex payment operations. It is a unified platform to power products and processes that move money.
>
> * Connect to banks and payment systems
> * Track transactions and balances in real-time
> * Automate payment operations for scale

This notebook covers how to load data from the `Modern Treasury REST API` into a format that can be ingested into LangChain, along with example usage for vectorization.

```
from langchain.indexes import VectorstoreIndexCreator  
from langchain_community.document_loaders import ModernTreasuryLoader  

```

**API Reference:**[VectorstoreIndexCreator](https://python.langchain.com/api_reference/langchain/indexes/langchain.indexes.vectorstore.VectorstoreIndexCreator.html) | [ModernTreasuryLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.modern_treasury.ModernTreasuryLoader.html)

The Modern Treasury API requires an organization ID and API key, which can be found in the Modern Treasury dashboard within developer settings.

This document loader also requires a `resource` option which defines what data you want to load.

Following resources are available:

`payment_orders` [Documentation](https://docs.moderntreasury.com/reference/payment-order-object)

`expected_payments` [Documentation](https://docs.moderntreasury.com/reference/expected-payment-object)

`returns` [Documentation](https://docs.moderntreasury.com/reference/return-object)

`incoming_payment_details` [Documentation](https://docs.moderntreasury.com/reference/incoming-payment-detail-object)

`counterparties` [Documentation](https://docs.moderntreasury.com/reference/counterparty-object)

`internal_accounts` [Documentation](https://docs.moderntreasury.com/reference/internal-account-object)

`external_accounts` [Documentation](https://docs.moderntreasury.com/reference/external-account-object)

`transactions` [Documentation](https://docs.moderntreasury.com/reference/transaction-object)

`ledgers` [Documentation](https://docs.moderntreasury.com/reference/ledger-object)

`ledger_accounts` [Documentation](https://docs.moderntreasury.com/reference/ledger-account-object)

`ledger_transactions` [Documentation](https://docs.moderntreasury.com/reference/ledger-transaction-object)

`events` [Documentation](https://docs.moderntreasury.com/reference/events)

`invoices` [Documentation](https://docs.moderntreasury.com/reference/invoices)

```
modern_treasury_loader = ModernTreasuryLoader("payment_orders")  

```

```
# Create a vectorstore retriever from the loader  
# see https://python.langchain.com/en/latest/modules/data_connection/getting_started.html for more details  
  
index = VectorstoreIndexCreator().from_loaders([modern_treasury_loader])  
modern_treasury_doc_retriever = index.vectorstore.as_retriever()  

```

## Related[​](#related "Direct link to Related")

* Document loader [conceptual guide](/docs/concepts/document_loaders/)
* Document loader [how-to guides](/docs/how_to/#document-loaders)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/modern_treasury.ipynb)