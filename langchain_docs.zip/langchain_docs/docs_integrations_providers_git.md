# Source: https://python.langchain.com/docs/integrations/providers/git/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Git

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/git.mdx)

# Git

> [Git](https://en.wikipedia.org/wiki/Git) is a distributed version control system that tracks changes in any set of computer files, usually used for coordinating work among programmers collaboratively developing source code during software development.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

First, you need to install `GitPython` python package.

```
pip install GitPython  

```

## Document Loader[​](#document-loader "Direct link to Document Loader")

See a [usage example](/docs/integrations/document_loaders/git/).

```
from langchain_community.document_loaders import GitLoader  

```

**API Reference:**[GitLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.git.GitLoader.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/git.mdx)