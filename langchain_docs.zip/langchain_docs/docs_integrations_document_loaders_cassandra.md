# Source: https://python.langchain.com/docs/integrations/document_loaders/cassandra/

* [Components](/docs/integrations/components/)
* [Document loaders](/docs/integrations/document_loaders/)
* Cassandra

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/cassandra.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/cassandra.ipynb)

# Cassandra

[Cassandra](https://cassandra.apache.org/) is a NoSQL, row-oriented, highly scalable and highly available database.Starting with version 5.0, the database ships with [vector search capabilities](https://cassandra.apache.org/doc/trunk/cassandra/vector-search/overview.html).

## Overview[​](#overview "Direct link to Overview")

The Cassandra Document Loader returns a list of Langchain Documents from a Cassandra database.

You must either provide a CQL query or a table name to retrieve the documents.
The Loader takes the following parameters:

* table: (Optional) The table to load the data from.
* session: (Optional) The cassandra driver session. If not provided, the cassio resolved session will be used.
* keyspace: (Optional) The keyspace of the table. If not provided, the cassio resolved keyspace will be used.
* query: (Optional) The query used to load the data.
* page\_content\_mapper: (Optional) a function to convert a row to string page content. The default converts the row to JSON.
* metadata\_mapper: (Optional) a function to convert a row to metadata dict.
* query\_parameters: (Optional) The query parameters used when calling session.execute .
* query\_timeout: (Optional) The query timeout used when calling session.execute .
* query\_custom\_payload: (Optional) The query custom\_payload used when calling `session.execute`.
* query\_execution\_profile: (Optional) The query execution\_profile used when calling `session.execute`.
* query\_host: (Optional) The query host used when calling `session.execute`.
* query\_execute\_as: (Optional) The query execute\_as used when calling `session.execute`.

## Load documents with the Document Loader[​](#load-documents-with-the-document-loader "Direct link to Load documents with the Document Loader")

```
from langchain_community.document_loaders import CassandraLoader  

```

**API Reference:**[CassandraLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.cassandra.CassandraLoader.html)

### Init from a cassandra driver Session[​](#init-from-a-cassandra-driver-session "Direct link to Init from a cassandra driver Session")

You need to create a `cassandra.cluster.Session` object, as described in the [Cassandra driver documentation](https://docs.datastax.com/en/developer/python-driver/latest/api/cassandra/cluster/#module-cassandra.cluster). The details vary (e.g. with network settings and authentication), but this might be something like:

```
from cassandra.cluster import Cluster  
  
cluster = Cluster()  
session = cluster.connect()  

```

You need to provide the name of an existing keyspace of the Cassandra instance:

```
CASSANDRA_KEYSPACE = input("CASSANDRA_KEYSPACE = ")  

```

Creating the document loader:

```
loader = CassandraLoader(  
    table="movie_reviews",  
    session=session,  
    keyspace=CASSANDRA_KEYSPACE,  
)  

```

```
docs = loader.load()  

```

```
docs[0]  

```

```
Document(page_content='Row(_id=\'659bdffa16cbc4586b11a423\', title=\'Dangerous Men\', reviewtext=\'"Dangerous Men,"  the picture\\\'s production notes inform, took 26 years to reach the big screen. After having seen it, I wonder: What was the rush?\')', metadata={'table': 'movie_reviews', 'keyspace': 'default_keyspace'})  

```

### Init from cassio[​](#init-from-cassio "Direct link to Init from cassio")

It's also possible to use cassio to configure the session and keyspace.

```
import cassio  
  
cassio.init(contact_points="127.0.0.1", keyspace=CASSANDRA_KEYSPACE)  
  
loader = CassandraLoader(  
    table="movie_reviews",  
)  
  
docs = loader.load()  

```

#### Attribution statement[​](#attribution-statement "Direct link to Attribution statement")

> Apache Cassandra, Cassandra and Apache are either registered trademarks or trademarks of the [Apache Software Foundation](http://www.apache.org/) in the United States and/or other countries.

## Related[​](#related "Direct link to Related")

* Document loader [conceptual guide](/docs/concepts/document_loaders/)
* Document loader [how-to guides](/docs/how_to/#document-loaders)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/cassandra.ipynb)