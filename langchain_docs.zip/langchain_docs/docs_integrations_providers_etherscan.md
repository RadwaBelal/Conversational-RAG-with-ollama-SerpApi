# Source: https://python.langchain.com/docs/integrations/providers/etherscan/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Etherscan

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/etherscan.mdx)

# Etherscan

> [Etherscan](https://docs.etherscan.io/) is the leading blockchain explorer,
> search, API and analytics platform for `Ethereum`, a decentralized smart contracts platform.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

See the detailed [installation guide](/docs/integrations/document_loaders/etherscan/).

## Document Loader[​](#document-loader "Direct link to Document Loader")

See a [usage example](/docs/integrations/document_loaders/etherscan/).

```
from langchain_community.document_loaders import EtherscanLoader  

```

**API Reference:**[EtherscanLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.etherscan.EtherscanLoader.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/etherscan.mdx)