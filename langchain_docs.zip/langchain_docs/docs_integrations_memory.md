# Source: https://python.langchain.com/docs/integrations/memory/

[## 📄️ Astra DB

DataStax Astra DB is a serverless](/docs/integrations/memory/astradb_chat_message_history/)

[## 📄️ AWS DynamoDB

Amazon AWS DynamoDB is a fully managed NoSQL database service that provides fast and predictable performance with seamless scalability.](/docs/integrations/memory/aws_dynamodb/)

[## 📄️ Cassandra

Apache Cassandra® is a NoSQL, row-oriented, highly scalable and highly available database, well suited for storing large amounts of data.](/docs/integrations/memory/cassandra_chat_message_history/)

[## 📄️ Couchbase

Couchbase is an award-winning distributed NoSQL cloud database that delivers unmatched versatility, performance, scalability, and financial value for all of your cloud, mobile, AI, and edge computing applications. Couchbase embraces AI with coding assistance for developers and vector search for their applications.](/docs/integrations/memory/couchbase_chat_message_history/)

[## 📄️ Elasticsearch

Elasticsearch is a distributed, RESTful search and analytics engine, capable of performing both vector and lexical search. It is built on top of the Apache Lucene library.](/docs/integrations/memory/elasticsearch_chat_message_history/)

[## 📄️ FalkorDB

FalkorDB is an open-source graph database management system, renowned for its efficient management of highly connected data. Unlike traditional databases that store data in tables, FalkorDB uses a graph structure with nodes, edges, and properties to represent and store data. This design allows for high-performance queries on complex data relationships.](/docs/integrations/memory/falkordb_chat_message_history/)

[## 📄️ Google AlloyDB for PostgreSQL

Google Cloud AlloyDB for PostgreSQL is a fully managed PostgreSQL compatible database service for your most demanding enterprise workloads. AlloyDB combines the best of Google Cloud with PostgreSQL, for superior performance, scale, and availability. Extend your database application to build AI-powered experiences leveraging AlloyDB Langchain integrations.](/docs/integrations/memory/google_alloydb/)

[## 📄️ Google Bigtable

Google Cloud Bigtable is a key-value and wide-column store, ideal for fast access to structured, semi-structured, or unstructured data. Extend your database application to build AI-powered experiences leveraging Bigtable's Langchain integrations.](/docs/integrations/memory/google_bigtable/)

[## 📄️ Google El Carro Oracle

Google Cloud El Carro Oracle offers a way to run Oracle databases in Kubernetes as a portable, open source, community-driven, no vendor lock-in container orchestration system. El Carro provides a powerful declarative API for comprehensive and consistent configuration and deployment as well as for real-time operations and monitoring. Extend your Oracle database's capabilities to build AI-powered experiences by leveraging the El Carro Langchain integration.](/docs/integrations/memory/google_el_carro/)

[## 📄️ Google Firestore (Native Mode)

Google Cloud Firestore is a serverless document-oriented database that scales to meet any demand. Extend your database application to build AI-powered experiences leveraging Firestore's Langchain integrations.](/docs/integrations/memory/google_firestore/)

[## 📄️ Google Firestore (Datastore Mode)

Google Cloud Firestore in Datastore is a serverless document-oriented database that scales to meet any demand. Extend your database application to build AI-powered experiences leveraging Datastore's Langchain integrations.](/docs/integrations/memory/google_firestore_datastore/)

[## 📄️ Google Memorystore for Redis

Google Cloud Memorystore for Redis is a fully-managed service that is powered by the Redis in-memory data store to build application caches that provide sub-millisecond data access. Extend your database application to build AI-powered experiences leveraging Memorystore for Redis's Langchain integrations.](/docs/integrations/memory/google_memorystore_redis/)

[## 📄️ Google Spanner

Google Cloud Spanner is a highly scalable database that combines unlimited scalability with relational semantics, such as secondary indexes, strong consistency, schemas, and SQL providing 99.999% availability in one easy solution.](/docs/integrations/memory/google_spanner/)

[## 📄️ Google SQL for SQL Server

Google Cloud SQL is a fully managed relational database service that offers high performance, seamless integration, and impressive scalability. It offers MySQL, PostgreSQL, and SQL Server database engines. Extend your database application to build AI-powered experiences leveraging Cloud SQL's Langchain integrations.](/docs/integrations/memory/google_sql_mssql/)

[## 📄️ Google SQL for MySQL

Cloud Cloud SQL is a fully managed relational database service that offers high performance, seamless integration, and impressive scalability. It offers MySQL, PostgreSQL, and SQL Server database engines. Extend your database application to build AI-powered experiences leveraging Cloud SQL's Langchain integrations.](/docs/integrations/memory/google_sql_mysql/)

[## 📄️ Google SQL for PostgreSQL

Google Cloud SQL is a fully managed relational database service that offers high performance, seamless integration, and impressive scalability. It offers MySQL, PostgreSQL, and SQL Server database engines. Extend your database application to build AI-powered experiences leveraging Cloud SQL's Langchain integrations.](/docs/integrations/memory/google_sql_pg/)

[## 📄️ Kafka

Kafka is a distributed messaging system that is used to publish and subscribe to streams of records.](/docs/integrations/memory/kafka_chat_message_history/)

[## 📄️ Momento Cache

Momento Cache is the world's first truly serverless caching service. It provides instant elasticity, scale-to-zero](/docs/integrations/memory/momento_chat_message_history/)

[## 📄️ MongoDB

MongoDB is a source-available cross-platform document-oriented database program. Classified as a NoSQL database program, MongoDB uses JSON-like documents with optional schemas.](/docs/integrations/memory/mongodb_chat_message_history/)

[## 📄️ Motörhead

Motörhead is a memory server implemented in Rust. It automatically handles incremental summarization in the background and allows for stateless applications.](/docs/integrations/memory/motorhead_memory/)

[## 📄️ Neo4j

Neo4j is an open-source graph database management system, renowned for its efficient management of highly connected data. Unlike traditional databases that store data in tables, Neo4j uses a graph structure with nodes, edges, and properties to represent and store data. This design allows for high-performance queries on complex data relationships.](/docs/integrations/memory/neo4j_chat_message_history/)

[## 📄️ Postgres

PostgreSQL also known as Postgres, is a free and open-source relational database management system (RDBMS) emphasizing extensibility and SQL compliance.](/docs/integrations/memory/postgres_chat_message_history/)

[## 📄️ Redis Chat Message History

Redis (Remote Dictionary Server) is an open-source in-memory storage, used as a distributed, in-memory key–value database, cache and message broker, with optional durability. Redis offers low-latency reads and writes. Redis is the most popular NoSQL database, and one of the most popular databases overall.](/docs/integrations/memory/redis_chat_message_history/)

[## 📄️ Remembrall

This page covers how to use the Remembrall ecosystem within LangChain.](/docs/integrations/memory/remembrall/)

[## 📄️ Rockset

Rockset is a real-time analytics database service for serving low latency, high concurrency analytical queries at scale. It builds a Converged Index™ on structured and semi-structured data with an efficient store for vector embeddings. Its support for running SQL on schemaless data makes it a perfect choice for running vector search with metadata filters.](/docs/integrations/memory/rockset_chat_message_history/)

[## 📄️ SingleStoreDB

This notebook goes over how to use SingleStoreDB to store chat message history.](/docs/integrations/memory/singlestoredb_chat_message_history/)

[## 📄️ SQL (SQLAlchemy)

Structured Query Language (SQL) is a domain-specific language used in programming and designed for managing data held in a relational database management system (RDBMS), or for stream processing in a relational data stream management system (RDSMS). It is particularly useful in handling structured data, i.e., data incorporating relations among entities and variables.](/docs/integrations/memory/sql_chat_message_history/)

[## 📄️ SQLite

SQLite is a database engine written in the C programming language. It is not a standalone app; rather, it is a library that software developers embed in their apps. As such, it belongs to the family of embedded databases. It is the most widely deployed database engine, as it is used by several of the top web browsers, operating systems, mobile phones, and other embedded systems.](/docs/integrations/memory/sqlite/)

[## 📄️ Streamlit

Streamlit is an open-source Python library that makes it easy to create and share beautiful,](/docs/integrations/memory/streamlit_chat_message_history/)

[## 📄️ TiDB

TiDB Cloud, is a comprehensive Database-as-a-Service (DBaaS) solution, that provides dedicated and serverless options. TiDB Serverless is now integrating a built-in vector search into the MySQL landscape. With this enhancement, you can seamlessly develop AI applications using TiDB Serverless without the need for a new database or additional technical stacks. Create a free TiDB Serverless cluster and start using the vector search feature at https://pingcap.com/ai.](/docs/integrations/memory/tidb_chat_message_history/)

[## 📄️ Upstash Redis

Upstash is a provider of the serverless Redis, Kafka, and QStash APIs.](/docs/integrations/memory/upstash_redis_chat_message_history/)

[## 📄️ Xata

Xata is a serverless data platform, based on PostgreSQL and Elasticsearch. It provides a Python SDK for interacting with your database, and a UI for managing your data. With the XataChatMessageHistory class, you can use Xata databases for longer-term persistence of chat sessions.](/docs/integrations/memory/xata_chat_message_history/)

[## 📄️ ZepCloudChatMessageHistory

Recall, understand, and extract data from chat histories. Power personalized AI experiences.](/docs/integrations/memory/zep_cloud_chat_message_history/)

[## 📄️ Zep Open Source Memory

Recall, understand, and extract data from chat histories. Power personalized AI experiences.](/docs/integrations/memory/zep_memory/)

[## 📄️ Zep Cloud Memory

Recall, understand, and extract data from chat histories. Power personalized AI experiences.](/docs/integrations/memory/zep_memory_cloud/)