# Source: https://python.langchain.com/docs/integrations/providers/deeplake/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Deeplake

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/deeplake.mdx)

# Deeplake

[Deeplake](https://www.deeplake.ai/) is a database optimized for AI and deep learning
applications.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

```
pip install langchain-deeplake  

```

## Vector stores[​](#vector-stores "Direct link to Vector stores")

See detail on available vector stores
[here](/docs/integrations/vectorstores/activeloop_deeplake/).

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/deeplake.mdx)