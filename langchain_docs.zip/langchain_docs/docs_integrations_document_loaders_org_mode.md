# Source: https://python.langchain.com/docs/integrations/document_loaders/org_mode/

* [Components](/docs/integrations/components/)
* [Document loaders](/docs/integrations/document_loaders/)
* Org-mode

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/org_mode.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/org_mode.ipynb)

# Org-mode

> A [Org Mode document](https://en.wikipedia.org/wiki/Org-mode) is a document editing, formatting, and organizing mode, designed for notes, planning, and authoring within the free software text editor Emacs.

## `UnstructuredOrgModeLoader`[​](#unstructuredorgmodeloader "Direct link to unstructuredorgmodeloader")

You can load data from Org-mode files with `UnstructuredOrgModeLoader` using the following workflow.

```
from langchain_community.document_loaders import UnstructuredOrgModeLoader  
  
loader = UnstructuredOrgModeLoader(  
    file_path="./example_data/README.org", mode="elements"  
)  
docs = loader.load()  
  
print(docs[0])  

```

**API Reference:**[UnstructuredOrgModeLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.org_mode.UnstructuredOrgModeLoader.html)

```
page_content='Example Docs' metadata={'source': './example_data/README.org', 'category_depth': 0, 'last_modified': '2023-12-19T13:42:18', 'languages': ['eng'], 'filetype': 'text/org', 'file_directory': './example_data', 'filename': 'README.org', 'category': 'Title'}  

```

## Related[​](#related "Direct link to Related")

* Document loader [conceptual guide](/docs/concepts/document_loaders/)
* Document loader [how-to guides](/docs/how_to/#document-loaders)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/org_mode.ipynb)