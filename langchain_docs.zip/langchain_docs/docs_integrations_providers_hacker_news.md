# Source: https://python.langchain.com/docs/integrations/providers/hacker_news/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Hacker News

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/hacker_news.mdx)

# Hacker News

> [Hacker News](https://en.wikipedia.org/wiki/Hacker_News) (sometimes abbreviated as `HN`) is a social news
> website focusing on computer science and entrepreneurship. It is run by the investment fund and startup
> incubator `Y Combinator`. In general, content that can be submitted is defined as "anything that gratifies
> one's intellectual curiosity."

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

There isn't any special setup for it.

## Document Loader[​](#document-loader "Direct link to Document Loader")

See a [usage example](/docs/integrations/document_loaders/hacker_news/).

```
from langchain_community.document_loaders import HNLoader  

```

**API Reference:**[HNLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.hn.HNLoader.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/hacker_news.mdx)