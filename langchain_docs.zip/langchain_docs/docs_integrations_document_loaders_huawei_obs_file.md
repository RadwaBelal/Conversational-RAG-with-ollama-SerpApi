# Source: https://python.langchain.com/docs/integrations/document_loaders/huawei_obs_file/

* [Components](/docs/integrations/components/)
* [Document loaders](/docs/integrations/document_loaders/)
* Huawei OBS File

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/huawei_obs_file.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/huawei_obs_file.ipynb)

# Huawei OBS File

The following code demonstrates how to load an object from the Huawei OBS (Object Storage Service) as document.

```
# Install the required package  
# pip install esdk-obs-python  

```

```
from langchain_community.document_loaders.obs_file import OBSFileLoader  

```

**API Reference:**[OBSFileLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.obs_file.OBSFileLoader.html)

```
endpoint = "your-endpoint"  

```

```
from obs import ObsClient  
  
obs_client = ObsClient(  
    access_key_id="your-access-key",  
    secret_access_key="your-secret-key",  
    server=endpoint,  
)  
loader = OBSFileLoader("your-bucket-name", "your-object-key", client=obs_client)  

```

```
loader.load()  

```

## Each Loader with Separate Authentication Information[​](#each-loader-with-separate-authentication-information "Direct link to Each Loader with Separate Authentication Information")

If you don't need to reuse OBS connections between different loaders, you can directly configure the `config`. The loader will use the config information to initialize its own OBS client.

```
# Configure your access credentials\n  
config = {"ak": "your-access-key", "sk": "your-secret-key"}  
loader = OBSFileLoader(  
    "your-bucket-name", "your-object-key", endpoint=endpoint, config=config  
)  

```

```
loader.load()  

```

## Get Authentication Information from ECS[​](#get-authentication-information-from-ecs "Direct link to Get Authentication Information from ECS")

If your langchain is deployed on Huawei Cloud ECS and [Agency is set up](https://support.huaweicloud.com/intl/en-us/usermanual-ecs/ecs_03_0166.html#section7), the loader can directly get the security token from ECS without needing access key and secret key.

```
config = {"get_token_from_ecs": True}  
loader = OBSFileLoader(  
    "your-bucket-name", "your-object-key", endpoint=endpoint, config=config  
)  

```

```
loader.load()  

```

## Access a Publicly Accessible Object[​](#access-a-publicly-accessible-object "Direct link to Access a Publicly Accessible Object")

If the object you want to access allows anonymous user access (anonymous users have `GetObject` permission), you can directly load the object without configuring the `config` parameter.

```
loader = OBSFileLoader("your-bucket-name", "your-object-key", endpoint=endpoint)  

```

```
loader.load()  

```

## Related[​](#related "Direct link to Related")

* Document loader [conceptual guide](/docs/concepts/document_loaders/)
* Document loader [how-to guides](/docs/how_to/#document-loaders)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/huawei_obs_file.ipynb)