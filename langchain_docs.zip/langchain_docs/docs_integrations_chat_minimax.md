# Source: https://python.langchain.com/docs/integrations/chat/minimax/

* [Components](/docs/integrations/components/)
* [Chat models](/docs/integrations/chat/)
* MiniMax

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/minimax.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/minimax.ipynb)

# MiniMaxChat

[Minimax](https://api.minimax.chat) is a Chinese startup that provides LLM service for companies and individuals.

This example goes over how to use LangChain to interact with MiniMax Inference for Chat.

```
import os  
  
os.environ["MINIMAX_GROUP_ID"] = "MINIMAX_GROUP_ID"  
os.environ["MINIMAX_API_KEY"] = "MINIMAX_API_KEY"  

```

```
from langchain_community.chat_models import MiniMaxChat  
from langchain_core.messages import HumanMessage  

```

**API Reference:**[MiniMaxChat](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.minimax.MiniMaxChat.html) | [HumanMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.human.HumanMessage.html)

```
chat = MiniMaxChat()  

```

```
chat(  
    [  
        HumanMessage(  
            content="Translate this sentence from English to French. I love programming."  
        )  
    ]  
)  

```

## Related[​](#related "Direct link to Related")

* Chat model [conceptual guide](/docs/concepts/chat_models/)
* Chat model [how-to guides](/docs/how_to/#chat-models)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/chat/minimax.ipynb)