# Source: https://python.langchain.com/docs/integrations/document_loaders/conll-u/

* [Components](/docs/integrations/components/)
* [Document loaders](/docs/integrations/document_loaders/)
* CoNLL-U

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/conll-u.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/conll-u.ipynb)

# CoNLL-U

> [CoNLL-U](https://universaldependencies.org/format.html) is revised version of the CoNLL-X format. Annotations are encoded in plain text files (UTF-8, normalized to NFC, using only the LF character as line break, including an LF character at the end of file) with three types of lines:
>
> * Word lines containing the annotation of a word/token in 10 fields separated by single tab characters; see below.
> * Blank lines marking sentence boundaries.
> * Comment lines starting with hash (#).

This is an example of how to load a file in [CoNLL-U](https://universaldependencies.org/format.html) format. The whole file is treated as one document. The example data (`conllu.conllu`) is based on one of the standard UD/CoNLL-U examples.

```
from langchain_community.document_loaders import CoNLLULoader  

```

**API Reference:**[CoNLLULoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.conllu.CoNLLULoader.html)

```
loader = CoNLLULoader("example_data/conllu.conllu")  

```

```
document = loader.load()  

```

```
document  

```

```
[Document(page_content='They buy and sell books.', metadata={'source': 'example_data/conllu.conllu'})]  

```

## Related[​](#related "Direct link to Related")

* Document loader [conceptual guide](/docs/concepts/document_loaders/)
* Document loader [how-to guides](/docs/how_to/#document-loaders)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/conll-u.ipynb)