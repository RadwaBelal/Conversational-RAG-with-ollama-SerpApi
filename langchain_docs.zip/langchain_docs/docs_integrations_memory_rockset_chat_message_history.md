# Source: https://python.langchain.com/docs/integrations/memory/rockset_chat_message_history/

* [Components](/docs/integrations/components/)
* Other
* [Message histories](/docs/integrations/memory/)
* Rockset

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/memory/rockset_chat_message_history.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/memory/rockset_chat_message_history.ipynb)

# Rockset

> [Rockset](https://rockset.com/product/) is a real-time analytics database service for serving low latency, high concurrency analytical queries at scale. It builds a Converged Index™ on structured and semi-structured data with an efficient store for vector embeddings. Its support for running SQL on schemaless data makes it a perfect choice for running vector search with metadata filters.

This notebook goes over how to use [Rockset](https://rockset.com/docs) to store chat message history.

## Setting up[​](#setting-up "Direct link to Setting up")

```
%pip install --upgrade --quiet  rockset langchain-community  

```

To begin, with get your API key from the [Rockset console](https://console.rockset.com/apikeys). Find your API region for the Rockset [API reference](https://rockset.com/docs/rest-api#introduction).

## Example[​](#example "Direct link to Example")

```
from langchain_community.chat_message_histories import (  
    RocksetChatMessageHistory,  
)  
from rockset import Regions, RocksetClient  
  
history = RocksetChatMessageHistory(  
    session_id="MySession",  
    client=RocksetClient(  
        api_key="YOUR API KEY",  
        host=Regions.usw2a1,  # us-west-2 Oregon  
    ),  
    collection="langchain_demo",  
    sync=True,  
)  
history.add_user_message("hi!")  
history.add_ai_message("whats up?")  
print(history.messages)  

```

**API Reference:**[RocksetChatMessageHistory](https://python.langchain.com/api_reference/community/chat_message_histories/langchain_community.chat_message_histories.rocksetdb.RocksetChatMessageHistory.html)

The output should be something like:

```
[  
    HumanMessage(content='hi!', additional_kwargs={'id': '2e62f1c2-e9f7-465e-b551-49bae07fe9f0'}, example=False),   
    AIMessage(content='whats up?', additional_kwargs={'id': 'b9be8eda-4c18-4cf8-81c3-e91e876927d0'}, example=False)  
]  
  

```

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/memory/rockset_chat_message_history.ipynb)