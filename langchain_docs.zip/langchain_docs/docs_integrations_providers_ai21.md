# Source: https://python.langchain.com/docs/integrations/providers/ai21/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* AI21 Labs

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/ai21.mdx)

# AI21 Labs

> [AI21 Labs](https://www.ai21.com/about) is a company specializing in Natural
> Language Processing (NLP), which develops AI systems
> that can understand and generate natural language.

This page covers how to use the `AI21` ecosystem within `LangChain`.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

* Get an AI21 api key and set it as an environment variable (`AI21_API_KEY`)
* Install the Python package:

```
pip install langchain-ai21  

```

## Chat models[​](#chat-models "Direct link to Chat models")

### AI21 Chat[​](#ai21-chat "Direct link to AI21 Chat")

See a [usage example](/docs/integrations/chat/ai21/).

```
from langchain_ai21 import ChatAI21  

```

**API Reference:**[ChatAI21](https://python.langchain.com/api_reference/ai21/chat_models/langchain_ai21.chat_models.ChatAI21.html)

## Deprecated features[​](#deprecated-features "Direct link to Deprecated features")

The following features are deprecated.

### AI21 LLM[​](#ai21-llm "Direct link to AI21 LLM")

```
from langchain_ai21 import AI21LLM  

```

### AI21 Contextual Answer[​](#ai21-contextual-answer "Direct link to AI21 Contextual Answer")

```
from langchain_ai21 import AI21ContextualAnswers  

```

### AI21 Embeddings[​](#ai21-embeddings "Direct link to AI21 Embeddings")

```
from langchain_ai21 import AI21Embeddings  

```

## Text splitters[​](#text-splitters "Direct link to Text splitters")

### AI21 Semantic Text Splitter[​](#ai21-semantic-text-splitter "Direct link to AI21 Semantic Text Splitter")

```
from langchain_ai21 import AI21SemanticTextSplitter  

```

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/ai21.mdx)