# Source: https://python.langchain.com/docs/integrations/chat/sparkllm/

* [Components](/docs/integrations/components/)
* [Chat models](/docs/integrations/chat/)
* SparkLLM Chat

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/sparkllm.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/sparkllm.ipynb)

# SparkLLM Chat

SparkLLM chat models API by iFlyTek. For more information, see [iFlyTek Open Platform](https://www.xfyun.cn/).

## Basic use[​](#basic-use "Direct link to Basic use")

```
"""For basic init and call"""  
from langchain_community.chat_models import ChatSparkLLM  
from langchain_core.messages import HumanMessage  
  
chat = ChatSparkLLM(  
    spark_app_id="<app_id>", spark_api_key="<api_key>", spark_api_secret="<api_secret>"  
)  
message = HumanMessage(content="Hello")  
chat([message])  

```

**API Reference:**[ChatSparkLLM](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.sparkllm.ChatSparkLLM.html) | [HumanMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.human.HumanMessage.html)

```
AIMessage(content='Hello! How can I help you today?')  

```

* Get SparkLLM's app\_id, api\_key and api\_secret from [iFlyTek SparkLLM API Console](https://console.xfyun.cn/services/bm3) (for more info, see [iFlyTek SparkLLM Intro](https://xinghuo.xfyun.cn/sparkapi) ), then set environment variables `IFLYTEK_SPARK_APP_ID`, `IFLYTEK_SPARK_API_KEY` and `IFLYTEK_SPARK_API_SECRET` or pass parameters when creating `ChatSparkLLM` as the demo above.

## For ChatSparkLLM with Streaming[​](#for-chatsparkllm-with-streaming "Direct link to For ChatSparkLLM with Streaming")

```
chat = ChatSparkLLM(  
    spark_app_id="<app_id>",  
    spark_api_key="<api_key>",  
    spark_api_secret="<api_secret>",  
    streaming=True,  
)  
for chunk in chat.stream("Hello!"):  
    print(chunk.content, end="")  

```

```
Hello! How can I help you today?  

```

## For v2[​](#for-v2 "Direct link to For v2")

```
"""For basic init and call"""  
from langchain_community.chat_models import ChatSparkLLM  
from langchain_core.messages import HumanMessage  
  
chat = ChatSparkLLM(  
    spark_app_id="<app_id>",  
    spark_api_key="<api_key>",  
    spark_api_secret="<api_secret>",  
    spark_api_url="wss://spark-api.xf-yun.com/v2.1/chat",  
    spark_llm_domain="generalv2",  
)  
message = HumanMessage(content="Hello")  
chat([message])  

```

**API Reference:**[ChatSparkLLM](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.sparkllm.ChatSparkLLM.html) | [HumanMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.human.HumanMessage.html)

## Related[​](#related "Direct link to Related")

* Chat model [conceptual guide](/docs/concepts/chat_models/)
* Chat model [how-to guides](/docs/how_to/#chat-models)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/chat/sparkllm.ipynb)