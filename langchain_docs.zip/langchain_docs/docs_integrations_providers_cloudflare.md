# Source: https://python.langchain.com/docs/integrations/providers/cloudflare/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Cloudflare

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/cloudflare.mdx)

# Cloudflare

> [Cloudflare, Inc. (Wikipedia)](https://en.wikipedia.org/wiki/Cloudflare) is an American company that provides
> content delivery network services, cloud cybersecurity, DDoS mitigation, and ICANN-accredited
> domain registration services.

> [Cloudflare Workers AI](https://developers.cloudflare.com/workers-ai/) allows you to run machine
> learning models, on the `Cloudflare` network, from your code via REST API.

## ChatModels[​](#chatmodels "Direct link to ChatModels")

See [installation instructions and usage example](/docs/integrations/chat/cloudflare_workersai/).

```
from langchain_cloudflare import ChatCloudflareWorkersAI  

```

## VectorStore[​](#vectorstore "Direct link to VectorStore")

See [installation instructions and usage example](/docs/integrations/vectorstores/cloudflare_vectorize/).

```
from langchain_cloudflare import CloudflareVectorize  

```

## Embeddings[​](#embeddings "Direct link to Embeddings")

See [installation instructions and usage example](/docs/integrations/text_embedding/cloudflare_workersai/).

```
from langchain_cloudflare import CloudflareWorkersAIEmbeddings  

```

## LLMs[​](#llms "Direct link to LLMs")

See [installation instructions and usage example](/docs/integrations/llms/cloudflare_workersai/).

```
from langchain_community.llms.cloudflare_workersai import CloudflareWorkersAI  

```

**API Reference:**[CloudflareWorkersAI](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.cloudflare_workersai.CloudflareWorkersAI.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/cloudflare.mdx)