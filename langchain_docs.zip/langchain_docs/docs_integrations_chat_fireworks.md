# Source: https://python.langchain.com/docs/integrations/chat/fireworks/

* [Components](/docs/integrations/components/)
* [Chat models](/docs/integrations/chat/)
* Fireworks

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/fireworks.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/fireworks.ipynb)

# ChatFireworks

This doc help you get started with Fireworks AI [chat models](/docs/concepts/chat_models/). For detailed documentation of all ChatFireworks features and configurations head to the [API reference](https://python.langchain.com/api_reference/fireworks/chat_models/langchain_fireworks.chat_models.ChatFireworks.html).

Fireworks AI is an AI inference platform to run and customize models. For a list of all models served by Fireworks see the [Fireworks docs](https://fireworks.ai/models).

## Overview[​](#overview "Direct link to Overview")

### Integration details[​](#integration-details "Direct link to Integration details")

| Class | Package | Local | Serializable | [JS support](https://js.langchain.com/docs/integrations/chat/fireworks) | Package downloads | Package latest |
| --- | --- | --- | --- | --- | --- | --- |
| [ChatFireworks](https://python.langchain.com/api_reference/fireworks/chat_models/langchain_fireworks.chat_models.ChatFireworks.html) | [langchain-fireworks](https://python.langchain.com/api_reference/fireworks/index.html) | ❌ | beta | ✅ | PyPI - Downloads | PyPI - Version |

### Model features[​](#model-features "Direct link to Model features")

| [Tool calling](/docs/how_to/tool_calling/) | [Structured output](/docs/how_to/structured_output/) | JSON mode | [Image input](/docs/how_to/multimodal_inputs/) | Audio input | Video input | [Token-level streaming](/docs/how_to/chat_streaming/) | Native async | [Token usage](/docs/how_to/chat_token_usage_tracking/) | [Logprobs](/docs/how_to/logprobs/) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ✅ | ✅ | ✅ | ✅ |

## Setup[​](#setup "Direct link to Setup")

To access Fireworks models you'll need to create a Fireworks account, get an API key, and install the `langchain-fireworks` integration package.

### Credentials[​](#credentials "Direct link to Credentials")

Head to (ttps://fireworks.ai/login to sign up to Fireworks and generate an API key. Once you've done this set the FIREWORKS\_API\_KEY environment variable:

```
import getpass  
import os  
  
if "FIREWORKS_API_KEY" not in os.environ:  
    os.environ["FIREWORKS_API_KEY"] = getpass.getpass("Enter your Fireworks API key: ")  

```

To enable automated tracing of your model calls, set your [LangSmith](https://docs.smith.langchain.com/) API key:

```
# os.environ["LANGSMITH_API_KEY"] = getpass.getpass("Enter your LangSmith API key: ")  
# os.environ["LANGSMITH_TRACING"] = "true"  

```

### Installation[​](#installation "Direct link to Installation")

The LangChain Fireworks integration lives in the `langchain-fireworks` package:

```
%pip install -qU langchain-fireworks  

```

## Instantiation[​](#instantiation "Direct link to Instantiation")

Now we can instantiate our model object and generate chat completions:

* TODO: Update model instantiation with relevant params.

```
from langchain_fireworks import ChatFireworks  
  
llm = ChatFireworks(  
    model="accounts/fireworks/models/llama-v3-70b-instruct",  
    temperature=0,  
    max_tokens=None,  
    timeout=None,  
    max_retries=2,  
    # other params...  
)  

```

**API Reference:**[ChatFireworks](https://python.langchain.com/api_reference/fireworks/chat_models/langchain_fireworks.chat_models.ChatFireworks.html)

## Invocation[​](#invocation "Direct link to Invocation")

```
messages = [  
    (  
        "system",  
        "You are a helpful assistant that translates English to French. Translate the user sentence.",  
    ),  
    ("human", "I love programming."),  
]  
ai_msg = llm.invoke(messages)  
ai_msg  

```

```
AIMessage(content="J'adore la programmation.", response_metadata={'token_usage': {'prompt_tokens': 35, 'total_tokens': 44, 'completion_tokens': 9}, 'model_name': 'accounts/fireworks/models/llama-v3-70b-instruct', 'system_fingerprint': '', 'finish_reason': 'stop', 'logprobs': None}, id='run-df28e69a-ff30-457e-a743-06eb14d01cb0-0', usage_metadata={'input_tokens': 35, 'output_tokens': 9, 'total_tokens': 44})  

```

```
print(ai_msg.content)  

```

```
J'adore la programmation.  

```

## Chaining[​](#chaining "Direct link to Chaining")

We can [chain](/docs/how_to/sequence/) our model with a prompt template like so:

```
from langchain_core.prompts import ChatPromptTemplate  
  
prompt = ChatPromptTemplate.from_messages(  
    [  
        (  
            "system",  
            "You are a helpful assistant that translates {input_language} to {output_language}.",  
        ),  
        ("human", "{input}"),  
    ]  
)  
  
chain = prompt | llm  
chain.invoke(  
    {  
        "input_language": "English",  
        "output_language": "German",  
        "input": "I love programming.",  
    }  
)  

```

**API Reference:**[ChatPromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.chat.ChatPromptTemplate.html)

```
AIMessage(content='Ich liebe das Programmieren.', response_metadata={'token_usage': {'prompt_tokens': 30, 'total_tokens': 37, 'completion_tokens': 7}, 'model_name': 'accounts/fireworks/models/llama-v3-70b-instruct', 'system_fingerprint': '', 'finish_reason': 'stop', 'logprobs': None}, id='run-ff3f91ad-ed81-4acf-9f59-7490dc8d8f48-0', usage_metadata={'input_tokens': 30, 'output_tokens': 7, 'total_tokens': 37})  

```

## API reference[​](#api-reference "Direct link to API reference")

For detailed documentation of all ChatFireworks features and configurations head to the API reference: <https://python.langchain.com/api_reference/fireworks/chat_models/langchain_fireworks.chat_models.ChatFireworks.html>

## Related[​](#related "Direct link to Related")

* Chat model [conceptual guide](/docs/concepts/chat_models/)
* Chat model [how-to guides](/docs/how_to/#chat-models)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/chat/fireworks.ipynb)