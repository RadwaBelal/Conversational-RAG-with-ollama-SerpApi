# Source: https://python.langchain.com/docs/integrations/chat/coze/

* [Components](/docs/integrations/components/)
* [Chat models](/docs/integrations/chat/)
* Coze Chat

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/coze.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/coze.ipynb)

# Chat with Coze Bot

ChatCoze chat models API by coze.com. For more information, see <https://www.coze.com/open/docs/chat>

```
from langchain_community.chat_models import ChatCoze  
from langchain_core.messages import HumanMessage  

```

**API Reference:**[ChatCoze](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.coze.ChatCoze.html) | [HumanMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.human.HumanMessage.html)

```
chat = ChatCoze(  
    coze_api_base="YOUR_API_BASE",  
    coze_api_key="YOUR_API_KEY",  
    bot_id="YOUR_BOT_ID",  
    user="YOUR_USER_ID",  
    conversation_id="YOUR_CONVERSATION_ID",  
    streaming=False,  
)  

```

Alternatively, you can set your API key and API base with:

```
import os  
  
os.environ["COZE_API_KEY"] = "YOUR_API_KEY"  
os.environ["COZE_API_BASE"] = "YOUR_API_BASE"  

```

```
chat([HumanMessage(content="什么是扣子(coze)")])  

```

```
AIMessage(content='为你找到关于coze的信息如下：  
  
Coze  是一个由字节跳动推出的AI聊天机器人和应用程序编辑开发平台。  
  
用户无论是否有编程经验，都可以通过该平台快速创建各种类型的聊天机器人、智能体、AI应用和插件，并将其部署在社交平台和即时聊天应用程序中。  
  
国际版使用的模型比国内版更强大。')  

```

## Chat with Coze Streaming[​](#chat-with-coze-streaming "Direct link to Chat with Coze Streaming")

```
chat = ChatCoze(  
    coze_api_base="YOUR_API_BASE",  
    coze_api_key="YOUR_API_KEY",  
    bot_id="YOUR_BOT_ID",  
    user="YOUR_USER_ID",  
    conversation_id="YOUR_CONVERSATION_ID",  
    streaming=True,  
)  

```

```
chat([HumanMessage(content="什么是扣子(coze)")])  

```

```
AIMessageChunk(content='为你查询到Coze是一个由字节跳动推出的AI聊天机器人和应用程序编辑开发平台。')  

```

## Related[​](#related "Direct link to Related")

* Chat model [conceptual guide](/docs/concepts/chat_models/)
* Chat model [how-to guides](/docs/how_to/#chat-models)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/chat/coze.ipynb)