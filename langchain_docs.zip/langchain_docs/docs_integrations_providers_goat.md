# Source: https://python.langchain.com/docs/integrations/providers/goat/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* GOAT

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/goat.mdx)

# GOAT

[GOAT](https://github.com/goat-sdk/goat) is the finance toolkit for AI agents.

Create agents that can:

* Send and receive payments
* Purchase physical and digital goods and services
* Engage in various investment strategies:
  + Earn yield
  + Bet on prediction markets
* Purchase crypto assets
* Tokenize any asset
* Get financial insights

### How it works[​](#how-it-works "Direct link to How it works")

GOAT leverages blockchains, cryptocurrencies (such as stablecoins), and wallets as the infrastructure to enable agents to become economic actors:

1. Give your agent a [wallet](https://github.com/goat-sdk/goat/tree/main#chains-and-wallets)
2. Allow it to transact [anywhere](https://github.com/goat-sdk/goat/tree/main#chains-and-wallets)
3. Use more than [+200 tools](https://github.com/goat-sdk/goat/tree/main#tools)

See everything GOAT supports [here](https://github.com/goat-sdk/goat/tree/main#chains-and-wallets).

**Lightweight and extendable**
Different from other toolkits, GOAT is designed to be lightweight and extendable by keeping its core minimal and allowing you to install only the tools you need.

If you don't find what you need on our more than 200 integrations you can easily:

* Create your own plugin
* Integrate a new chain
* Integrate a new wallet
* Integrate a new agent framework

See how to do it [here](https://github.com/goat-sdk/goat/tree/main#-contributing).

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

Check out our [quickstart](https://github.com/goat-sdk/goat/tree/main/python/examples/by-framework/langchain) to see how to set up and install GOAT.

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/goat.mdx)