# Source: https://python.langchain.com/docs/integrations/providers/infinity/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Infinity

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/infinity.mdx)

# Infinity

> [Infinity](https://github.com/michaelfeil/infinity) allows the creation of text embeddings.

## Text Embedding Model[​](#text-embedding-model "Direct link to Text Embedding Model")

There exists an infinity Embedding model, which you can access with

```
from langchain_community.embeddings import InfinityEmbeddings  

```

**API Reference:**[InfinityEmbeddings](https://python.langchain.com/api_reference/community/embeddings/langchain_community.embeddings.infinity.InfinityEmbeddings.html)

For a more detailed walkthrough of this, see [this notebook](/docs/integrations/text_embedding/infinity/)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/infinity.mdx)