# Source: https://python.langchain.com/docs/integrations/document_loaders/gutenberg/

* [Components](/docs/integrations/components/)
* [Document loaders](/docs/integrations/document_loaders/)
* Gutenberg

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/gutenberg.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/gutenberg.ipynb)

# Gutenberg

> [Project Gutenberg](https://www.gutenberg.org/about/) is an online library of free eBooks.

This notebook covers how to load links to `Gutenberg` e-books into a document format that we can use downstream.

```
from langchain_community.document_loaders import GutenbergLoader  

```

**API Reference:**[GutenbergLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.gutenberg.GutenbergLoader.html)

```
loader = GutenbergLoader("https://www.gutenberg.org/cache/epub/69972/pg69972.txt")  

```

```
data = loader.load()  

```

```
data[0].page_content[:300]  

```

```
'The Project Gutenberg eBook of The changed brides, by Emma Dorothy\r\n\n\nEliza Nevitte Southworth\r\n\n\n\r\n\n\nThis eBook is for the use of anyone anywhere in the United States and\r\n\n\nmost other parts of the world at no cost and with almost no restrictions\r\n\n\nwhatsoever. You may copy it, give it away or re-u'  

```

```
data[0].metadata  

```

```
{'source': 'https://www.gutenberg.org/cache/epub/69972/pg69972.txt'}  

```

## Related[​](#related "Direct link to Related")

* Document loader [conceptual guide](/docs/concepts/document_loaders/)
* Document loader [how-to guides](/docs/how_to/#document-loaders)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/gutenberg.ipynb)