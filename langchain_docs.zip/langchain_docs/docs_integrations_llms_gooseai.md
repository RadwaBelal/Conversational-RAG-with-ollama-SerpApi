# Source: https://python.langchain.com/docs/integrations/llms/gooseai/

* [Components](/docs/integrations/components/)
* Other
* [LLMs](/docs/integrations/llms/)
* GooseAI

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/llms/gooseai.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/llms/gooseai.ipynb)

# GooseAI

`GooseAI` is a fully managed NLP-as-a-Service, delivered via API. GooseAI provides access to [these models](https://goose.ai/docs/models).

This notebook goes over how to use Langchain with [GooseAI](https://goose.ai/).

## Install openai[​](#install-openai "Direct link to Install openai")

The `openai` package is required to use the GooseAI API. Install `openai` using `pip install openai`.

```
%pip install --upgrade --quiet  langchain-openai  

```

## Imports[​](#imports "Direct link to Imports")

```
import os  
  
from langchain.chains import LLMChain  
from langchain_community.llms import GooseAI  
from langchain_core.prompts import PromptTemplate  

```

**API Reference:**[LLMChain](https://python.langchain.com/api_reference/langchain/chains/langchain.chains.llm.LLMChain.html) | [GooseAI](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.gooseai.GooseAI.html) | [PromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.prompt.PromptTemplate.html)

## Set the Environment API Key[​](#set-the-environment-api-key "Direct link to Set the Environment API Key")

Make sure to get your API key from GooseAI. You are given $10 in free credits to test different models.

```
from getpass import getpass  
  
GOOSEAI_API_KEY = getpass()  

```

```
os.environ["GOOSEAI_API_KEY"] = GOOSEAI_API_KEY  

```

## Create the GooseAI instance[​](#create-the-gooseai-instance "Direct link to Create the GooseAI instance")

You can specify different parameters such as the model name, max tokens generated, temperature, etc.

```
llm = GooseAI()  

```

## Create a Prompt Template[​](#create-a-prompt-template "Direct link to Create a Prompt Template")

We will create a prompt template for Question and Answer.

```
template = """Question: {question}  
  
Answer: Let's think step by step."""  
  
prompt = PromptTemplate.from_template(template)  

```

## Initiate the LLMChain[​](#initiate-the-llmchain "Direct link to Initiate the LLMChain")

```
llm_chain = LLMChain(prompt=prompt, llm=llm)  

```

## Run the LLMChain[​](#run-the-llmchain "Direct link to Run the LLMChain")

Provide a question and run the LLMChain.

```
question = "What NFL team won the Super Bowl in the year Justin Beiber was born?"  
  
llm_chain.run(question)  

```

## Related[​](#related "Direct link to Related")

* LLM [conceptual guide](/docs/concepts/text_llms/)
* LLM [how-to guides](/docs/how_to/#llms)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/llms/gooseai.ipynb)