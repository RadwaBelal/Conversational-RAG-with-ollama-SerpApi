# Source: https://python.langchain.com/docs/integrations/chat/azureml_chat_endpoint/

* [Components](/docs/integrations/components/)
* [Chat models](/docs/integrations/chat/)
* Azure ML Endpoint

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/azureml_chat_endpoint.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/chat/azureml_chat_endpoint.ipynb)

# AzureMLChatOnlineEndpoint

> [Azure Machine Learning](https://azure.microsoft.com/en-us/products/machine-learning/) is a platform used to build, train, and deploy machine learning models. Users can explore the types of models to deploy in the Model Catalog, which provides foundational and general purpose models from different providers.
>
> In general, you need to deploy models in order to consume its predictions (inference). In `Azure Machine Learning`, [Online Endpoints](https://learn.microsoft.com/en-us/azure/machine-learning/concept-endpoints) are used to deploy these models with a real-time serving. They are based on the ideas of `Endpoints` and `Deployments` which allow you to decouple the interface of your production workload from the implementation that serves it.

This notebook goes over how to use a chat model hosted on an `Azure Machine Learning Endpoint`.

```
from langchain_community.chat_models.azureml_endpoint import AzureMLChatOnlineEndpoint  

```

**API Reference:**[AzureMLChatOnlineEndpoint](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.azureml_endpoint.AzureMLChatOnlineEndpoint.html)

## Set up[​](#set-up "Direct link to Set up")

You must [deploy a model on Azure ML](https://learn.microsoft.com/en-us/azure/machine-learning/how-to-use-foundation-models?view=azureml-api-2#deploying-foundation-models-to-endpoints-for-inferencing) or [to Azure AI studio](https://learn.microsoft.com/en-us/azure/ai-studio/how-to/deploy-models-open) and obtain the following parameters:

* `endpoint_url`: The REST endpoint url provided by the endpoint.
* `endpoint_api_type`: Use `endpoint_type='dedicated'` when deploying models to **Dedicated endpoints** (hosted managed infrastructure). Use `endpoint_type='serverless'` when deploying models using the **Pay-as-you-go** offering (model as a service).
* `endpoint_api_key`: The API key provided by the endpoint

## Content Formatter[​](#content-formatter "Direct link to Content Formatter")

The `content_formatter` parameter is a handler class for transforming the request and response of an AzureML endpoint to match with required schema. Since there are a wide range of models in the model catalog, each of which may process data differently from one another, a `ContentFormatterBase` class is provided to allow users to transform data to their liking. The following content formatters are provided:

* `CustomOpenAIChatContentFormatter`: Formats request and response data for models like LLaMa2-chat that follow the OpenAI API spec for request and response.

*Note: `langchain.chat_models.azureml_endpoint.LlamaChatContentFormatter` is being deprecated and replaced with `langchain.chat_models.azureml_endpoint.CustomOpenAIChatContentFormatter`.*

You can implement custom content formatters specific for your model deriving from the class `langchain_community.llms.azureml_endpoint.ContentFormatterBase`.

## Examples[​](#examples "Direct link to Examples")

The following section contains examples about how to use this class:

### Example: Chat completions with real-time endpoints[​](#example-chat-completions-with-real-time-endpoints "Direct link to Example: Chat completions with real-time endpoints")

```
from langchain_community.chat_models.azureml_endpoint import (  
    AzureMLEndpointApiType,  
    CustomOpenAIChatContentFormatter,  
)  
from langchain_core.messages import HumanMessage  
  
chat = AzureMLChatOnlineEndpoint(  
    endpoint_url="https://<your-endpoint>.<your_region>.inference.ml.azure.com/score",  
    endpoint_api_type=AzureMLEndpointApiType.dedicated,  
    endpoint_api_key="my-api-key",  
    content_formatter=CustomOpenAIChatContentFormatter(),  
)  
response = chat.invoke(  
    [HumanMessage(content="Will the Collatz conjecture ever be solved?")]  
)  
response  

```

**API Reference:**[AzureMLEndpointApiType](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.azureml_endpoint.AzureMLEndpointApiType.html) | [CustomOpenAIChatContentFormatter](https://python.langchain.com/api_reference/community/chat_models/langchain_community.chat_models.azureml_endpoint.CustomOpenAIChatContentFormatter.html) | [HumanMessage](https://python.langchain.com/api_reference/core/messages/langchain_core.messages.human.HumanMessage.html)

```
AIMessage(content='  The Collatz Conjecture is one of the most famous unsolved problems in mathematics, and it has been the subject of much study and research for many years. While it is impossible to predict with certainty whether the conjecture will ever be solved, there are several reasons why it is considered a challenging and important problem:\n\n1. Simple yet elusive: The Collatz Conjecture is a deceptively simple statement that has proven to be extraordinarily difficult to prove or disprove. Despite its simplicity, the conjecture has eluded some of the brightest minds in mathematics, and it remains one of the most famous open problems in the field.\n2. Wide-ranging implications: The Collatz Conjecture has far-reaching implications for many areas of mathematics, including number theory, algebra, and analysis. A solution to the conjecture could have significant impacts on these fields and potentially lead to new insights and discoveries.\n3. Computational evidence: While the conjecture remains unproven, extensive computational evidence supports its validity. In fact, no counterexample to the conjecture has been found for any starting value up to 2^64 (a number', additional_kwargs={}, example=False)  

```

### Example: Chat completions with pay-as-you-go deployments (model as a service)[​](#example-chat-completions-with-pay-as-you-go-deployments-model-as-a-service "Direct link to Example: Chat completions with pay-as-you-go deployments (model as a service)")

```
chat = AzureMLChatOnlineEndpoint(  
    endpoint_url="https://<your-endpoint>.<your_region>.inference.ml.azure.com/v1/chat/completions",  
    endpoint_api_type=AzureMLEndpointApiType.serverless,  
    endpoint_api_key="my-api-key",  
    content_formatter=CustomOpenAIChatContentFormatter,  
)  
response = chat.invoke(  
    [HumanMessage(content="Will the Collatz conjecture ever be solved?")]  
)  
response  

```

If you need to pass additional parameters to the model, use `model_kwargs` argument:

```
chat = AzureMLChatOnlineEndpoint(  
    endpoint_url="https://<your-endpoint>.<your_region>.inference.ml.azure.com/v1/chat/completions",  
    endpoint_api_type=AzureMLEndpointApiType.serverless,  
    endpoint_api_key="my-api-key",  
    content_formatter=CustomOpenAIChatContentFormatter,  
    model_kwargs={"temperature": 0.8},  
)  

```

Parameters can also be passed during invocation:

```
response = chat.invoke(  
    [HumanMessage(content="Will the Collatz conjecture ever be solved?")],  
    max_tokens=512,  
)  
response  

```

## Related[​](#related "Direct link to Related")

* Chat model [conceptual guide](/docs/concepts/chat_models/)
* Chat model [how-to guides](/docs/how_to/#chat-models)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/chat/azureml_chat_endpoint.ipynb)