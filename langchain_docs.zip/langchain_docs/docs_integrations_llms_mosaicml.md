# Source: https://python.langchain.com/docs/integrations/llms/mosaicml/

* [Components](/docs/integrations/components/)
* Other
* [LLMs](/docs/integrations/llms/)
* MosaicML

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/llms/mosaicml.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/llms/mosaicml.ipynb)

# MosaicML

[MosaicML](https://docs.mosaicml.com/en/latest/inference.html) offers a managed inference service. You can either use a variety of open-source models, or deploy your own.

This example goes over how to use LangChain to interact with MosaicML Inference for text completion.

```
# sign up for an account: https://forms.mosaicml.com/demo?utm_source=langchain  
  
from getpass import getpass  
  
MOSAICML_API_TOKEN = getpass()  

```

```
import os  
  
os.environ["MOSAICML_API_TOKEN"] = MOSAICML_API_TOKEN  

```

```
from langchain.chains import LLMChain  
from langchain_community.llms import MosaicML  
from langchain_core.prompts import PromptTemplate  

```

**API Reference:**[LLMChain](https://python.langchain.com/api_reference/langchain/chains/langchain.chains.llm.LLMChain.html) | [MosaicML](https://python.langchain.com/api_reference/community/llms/langchain_community.llms.mosaicml.MosaicML.html) | [PromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.prompt.PromptTemplate.html)

```
template = """Question: {question}"""  
  
prompt = PromptTemplate.from_template(template)  

```

```
llm = MosaicML(inject_instruction_format=True, model_kwargs={"max_new_tokens": 128})  

```

```
llm_chain = LLMChain(prompt=prompt, llm=llm)  

```

```
question = "What is one good reason why you should train a large language model on domain specific data?"  
  
llm_chain.run(question)  

```

## Related[​](#related "Direct link to Related")

* LLM [conceptual guide](/docs/concepts/text_llms/)
* LLM [how-to guides](/docs/how_to/#llms)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/llms/mosaicml.ipynb)