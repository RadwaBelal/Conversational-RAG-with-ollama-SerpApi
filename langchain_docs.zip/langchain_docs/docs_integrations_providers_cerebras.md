# Source: https://python.langchain.com/docs/integrations/providers/cerebras/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Cerebras

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/cerebras.mdx)

# Cerebras

At Cerebras, we've developed the world's largest and fastest AI processor, the Wafer-Scale Engine-3 (WSE-3). The Cerebras CS-3 system, powered by the WSE-3, represents a new class of AI supercomputer that sets the standard for generative AI training and inference with unparalleled performance and scalability.

With Cerebras as your inference provider, you can:

* Achieve unprecedented speed for AI inference workloads
* Build commercially with high throughput
* Effortlessly scale your AI workloads with our seamless clustering technology

Our CS-3 systems can be quickly and easily clustered to create the largest AI supercomputers in the world, making it simple to place and run the largest models. Leading corporations, research institutions, and governments are already using Cerebras solutions to develop proprietary models and train popular open-source models.

Want to experience the power of Cerebras? Check out our [website](https://cerebras.ai) for more resources and explore options for accessing our technology through the Cerebras Cloud or on-premise deployments!

For more information about Cerebras Cloud, visit [cloud.cerebras.ai](https://cloud.cerebras.ai/). Our API reference is available at [inference-docs.cerebras.ai](https://inference-docs.cerebras.ai/).

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

Install the integration package:

```
pip install langchain-cerebras  

```

## API Key[​](#api-key "Direct link to API Key")

Get an API Key from [cloud.cerebras.ai](https://cloud.cerebras.ai/) and add it to your environment variables:

```
export CEREBRAS_API_KEY="your-api-key-here"  

```

## Chat Model[​](#chat-model "Direct link to Chat Model")

See a [usage example](/docs/integrations/chat/cerebras/).

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/cerebras.mdx)