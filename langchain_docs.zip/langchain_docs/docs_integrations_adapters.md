# Source: https://python.langchain.com/docs/integrations/adapters/

[## 📄️ OpenAI Adapter(Old)

Please ensure OpenAI library is less than 1.0.0; otherwise, refer to the newer doc OpenAI Adapter.](/docs/integrations/adapters/openai-old/)

[## 📄️ OpenAI Adapter

Please ensure OpenAI library is version 1.0.0 or higher; otherwise, refer to the older doc OpenAI Adapter(Old).](/docs/integrations/adapters/openai/)