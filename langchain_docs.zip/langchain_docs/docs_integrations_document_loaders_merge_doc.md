# Source: https://python.langchain.com/docs/integrations/document_loaders/merge_doc/

* [Components](/docs/integrations/components/)
* [Document loaders](/docs/integrations/document_loaders/)
* Merge Documents Loader

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/merge_doc.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/merge_doc.ipynb)

# Merge Documents Loader

Merge the documents returned from a set of specified data loaders.

```
from langchain_community.document_loaders import WebBaseLoader  
  
loader_web = WebBaseLoader(  
    "https://github.com/basecamp/handbook/blob/master/37signals-is-you.md"  
)  

```

**API Reference:**[WebBaseLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.web_base.WebBaseLoader.html)

```
from langchain_community.document_loaders import PyPDFLoader  
  
loader_pdf = PyPDFLoader("../MachineLearning-Lecture01.pdf")  

```

**API Reference:**[PyPDFLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.pdf.PyPDFLoader.html)

```
from langchain_community.document_loaders.merge import MergedDataLoader  
  
loader_all = MergedDataLoader(loaders=[loader_web, loader_pdf])  

```

**API Reference:**[MergedDataLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.merge.MergedDataLoader.html)

```
docs_all = loader_all.load()  

```

```
len(docs_all)  

```

```
23  

```

## Related[​](#related "Direct link to Related")

* Document loader [conceptual guide](/docs/concepts/document_loaders/)
* Document loader [how-to guides](/docs/how_to/#document-loaders)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/merge_doc.ipynb)