# Source: https://python.langchain.com/docs/integrations/providers/exa_search/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Exa

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/exa_search.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/exa_search.ipynb)

# Exa

> [Exa](https://exa.ai/) is a knowledge API for AI and developers.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

`Exa` integration exists in its own [partner package](https://pypi.org/project/langchain-exa/). You can install it with:

```
%pip install -qU langchain-exa  

```

In order to use the package, you will also need to set the `EXA_API_KEY` environment variable to your Exa API key.

## Retriever[​](#retriever "Direct link to Retriever")

You can use the [`ExaSearchRetriever`](/docs/integrations/tools/exa_search/#using-exasearchretriever) in a standard retrieval pipeline. You can import it as follows.

See a [usage example](/docs/integrations/tools/exa_search/).

```
from langchain_exa import ExaSearchRetriever  

```

**API Reference:**[ExaSearchRetriever](https://python.langchain.com/api_reference/exa/retrievers/langchain_exa.retrievers.ExaSearchRetriever.html)

## Tools[​](#tools "Direct link to Tools")

You can use Exa as an agent tool as described in the [Exa tool calling docs](/docs/integrations/tools/exa_search/#using-the-exa-sdk-as-langchain-agent-tools).

See a [usage example](/docs/integrations/tools/exa_search/).

### ExaFindSimilarResults[​](#exafindsimilarresults "Direct link to ExaFindSimilarResults")

A tool that queries the Metaphor Search API and gets back JSON.

```
from langchain_exa.tools import ExaFindSimilarResults  

```

**API Reference:**[ExaFindSimilarResults](https://python.langchain.com/api_reference/exa/tools/langchain_exa.tools.ExaFindSimilarResults.html)

### ExaSearchResults[​](#exasearchresults "Direct link to ExaSearchResults")

Exa Search tool.

```
from langchain_exa.tools import ExaSearchResults  

```

**API Reference:**[ExaSearchResults](https://python.langchain.com/api_reference/exa/tools/langchain_exa.tools.ExaSearchResults.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/exa_search.ipynb)