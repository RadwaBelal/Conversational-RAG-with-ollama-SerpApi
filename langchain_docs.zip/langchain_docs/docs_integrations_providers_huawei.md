# Source: https://python.langchain.com/docs/integrations/providers/huawei/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Huawei

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/huawei.mdx)

# Huawei

> [Huawei Technologies Co., Ltd.](https://www.huawei.com/) is a Chinese multinational
> digital communications technology corporation.
>
> [Huawei Cloud](https://www.huaweicloud.com/intl/en-us/product/) provides a comprehensive suite of
> global cloud computing services.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

To access the `Huawei Cloud`, you need an access token.

You also have to install a python library:

```
pip install -U esdk-obs-python  

```

## Document Loader[​](#document-loader "Direct link to Document Loader")

### Huawei OBS Directory[​](#huawei-obs-directory "Direct link to Huawei OBS Directory")

See a [usage example](/docs/integrations/document_loaders/huawei_obs_directory/).

```
from langchain_community.document_loaders import OBSDirectoryLoader  

```

**API Reference:**[OBSDirectoryLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.obs_directory.OBSDirectoryLoader.html)

### Huawei OBS File[​](#huawei-obs-file "Direct link to Huawei OBS File")

See a [usage example](/docs/integrations/document_loaders/huawei_obs_file/).

```
from langchain_community.document_loaders.obs_file import OBSFileLoader  

```

**API Reference:**[OBSFileLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.obs_file.OBSFileLoader.html)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/huawei.mdx)