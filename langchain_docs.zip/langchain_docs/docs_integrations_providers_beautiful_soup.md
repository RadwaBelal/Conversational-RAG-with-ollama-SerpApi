# Source: https://python.langchain.com/docs/integrations/providers/beautiful_soup/

* [Providers](/docs/integrations/providers/)
* [More](/docs/integrations/providers/all/)
* Beautiful Soup

On this page

[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/providers/beautiful_soup.mdx)

# Beautiful Soup

> [Beautiful Soup](https://www.crummy.com/software/BeautifulSoup/) is a Python package for parsing
> HTML and XML documents (including having malformed markup, i.e. non-closed tags, so named after tag soup).
> It creates a parse tree for parsed pages that can be used to extract data from HTML,[3] which
> is useful for web scraping.

## Installation and Setup[​](#installation-and-setup "Direct link to Installation and Setup")

```
pip install beautifulsoup4  

```

## Document Transformer[​](#document-transformer "Direct link to Document Transformer")

See a [usage example](/docs/integrations/document_transformers/beautiful_soup/).

```
from langchain_community.document_loaders import BeautifulSoupTransformer  

```

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/providers/beautiful_soup.mdx)