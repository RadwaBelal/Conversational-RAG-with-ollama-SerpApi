# Source: https://python.langchain.com/docs/integrations/document_loaders/json/

* [Components](/docs/integrations/components/)
* [Document loaders](/docs/integrations/document_loaders/)
* JSONLoader

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/json.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/json.ipynb)

# JSONLoader

This notebook provides a quick overview for getting started with JSON [document loader](https://python.langchain.com/docs/concepts/document_loaders). For detailed documentation of all JSONLoader features and configurations head to the [API reference](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.json_loader.JSONLoader.html).

* TODO: Add any other relevant links, like information about underlying API, etc.

## Overview[​](#overview "Direct link to Overview")

### Integration details[​](#integration-details "Direct link to Integration details")

| Class | Package | Local | Serializable | [JS support](https://js.langchain.com/docs/integrations/document_loaders/file_loaders/json/) |
| --- | --- | --- | --- | --- |
| [JSONLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.json_loader.JSONLoader.html) | [langchain\_community](https://python.langchain.com/api_reference/community/index.html) | ✅ | ❌ | ✅ |

### Loader features[​](#loader-features "Direct link to Loader features")

| Source | Document Lazy Loading | Native Async Support |
| --- | --- | --- |
| JSONLoader | ✅ | ❌ |

## Setup[​](#setup "Direct link to Setup")

To access JSON document loader you'll need to install the `langchain-community` integration package as well as the `jq` python package.

### Credentials[​](#credentials "Direct link to Credentials")

No credentials are required to use the `JSONLoader` class.

To enable automated tracing of your model calls, set your [LangSmith](https://docs.smith.langchain.com/) API key:

```
# os.environ["LANGSMITH_API_KEY"] = getpass.getpass("Enter your LangSmith API key: ")  
# os.environ["LANGSMITH_TRACING"] = "true"  

```

### Installation[​](#installation "Direct link to Installation")

Install **langchain\_community** and **jq**:

```
%pip install -qU langchain_community jq   

```

## Initialization[​](#initialization "Direct link to Initialization")

Now we can instantiate our model object and load documents:

* TODO: Update model instantiation with relevant params.

```
from langchain_community.document_loaders import JSONLoader  
  
loader = JSONLoader(  
    file_path="./example_data/facebook_chat.json",  
    jq_schema=".messages[].content",  
    text_content=False,  
)  

```

**API Reference:**[JSONLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.json_loader.JSONLoader.html)

## Load[​](#load "Direct link to Load")

```
docs = loader.load()  
docs[0]  

```

```
Document(metadata={'source': '/Users/isaachershenson/Documents/langchain/docs/docs/integrations/document_loaders/example_data/facebook_chat.json', 'seq_num': 1}, page_content='Bye!')  

```

```
print(docs[0].metadata)  

```

```
{'source': '/Users/isaachershenson/Documents/langchain/docs/docs/integrations/document_loaders/example_data/facebook_chat.json', 'seq_num': 1}  

```

## Lazy Load[​](#lazy-load "Direct link to Lazy Load")

```
pages = []  
for doc in loader.lazy_load():  
    pages.append(doc)  
    if len(pages) >= 10:  
        # do some paged operation, e.g.  
        # index.upsert(pages)  
  
        pages = []  

```

## Read from JSON Lines file[​](#read-from-json-lines-file "Direct link to Read from JSON Lines file")

If you want to load documents from a JSON Lines file, you pass `json_lines=True`
and specify `jq_schema` to extract `page_content` from a single JSON object.

```
loader = JSONLoader(  
    file_path="./example_data/facebook_chat_messages.jsonl",  
    jq_schema=".content",  
    text_content=False,  
    json_lines=True,  
)  
  
docs = loader.load()  
print(docs[0])  

```

```
page_content='Bye!' metadata={'source': '/Users/isaachershenson/Documents/langchain/docs/docs/integrations/document_loaders/example_data/facebook_chat_messages.jsonl', 'seq_num': 1}  

```

## Read specific content keys[​](#read-specific-content-keys "Direct link to Read specific content keys")

Another option is to set `jq_schema='.'` and provide a `content_key` in order to only load specific content:

```
loader = JSONLoader(  
    file_path="./example_data/facebook_chat_messages.jsonl",  
    jq_schema=".",  
    content_key="sender_name",  
    json_lines=True,  
)  
  
docs = loader.load()  
print(docs[0])  

```

```
page_content='User 2' metadata={'source': '/Users/isaachershenson/Documents/langchain/docs/docs/integrations/document_loaders/example_data/facebook_chat_messages.jsonl', 'seq_num': 1}  

```

## JSON file with jq schema `content_key`[​](#json-file-with-jq-schema-content_key "Direct link to json-file-with-jq-schema-content_key")

To load documents from a JSON file using the `content_key` within the jq schema, set `is_content_key_jq_parsable=True`. Ensure that `content_key` is compatible and can be parsed using the jq schema.

```
loader = JSONLoader(  
    file_path="./example_data/facebook_chat.json",  
    jq_schema=".messages[]",  
    content_key=".content",  
    is_content_key_jq_parsable=True,  
)  
  
docs = loader.load()  
print(docs[0])  

```

```
page_content='Bye!' metadata={'source': '/Users/isaachershenson/Documents/langchain/docs/docs/integrations/document_loaders/example_data/facebook_chat.json', 'seq_num': 1}  

```

## Extracting metadata[​](#extracting-metadata "Direct link to Extracting metadata")

Generally, we want to include metadata available in the JSON file into the documents that we create from the content.

The following demonstrates how metadata can be extracted using the `JSONLoader`.

There are some key changes to be noted. In the previous example where we didn't collect the metadata, we managed to directly specify in the schema where the value for the `page_content` can be extracted from.

In this example, we have to tell the loader to iterate over the records in the `messages` field. The jq\_schema then has to be `.messages[]`

This allows us to pass the records (dict) into the `metadata_func` that has to be implemented. The `metadata_func` is responsible for identifying which pieces of information in the record should be included in the metadata stored in the final `Document` object.

Additionally, we now have to explicitly specify in the loader, via the `content_key` argument, the key from the record where the value for the `page_content` needs to be extracted from.

```
# Define the metadata extraction function.  
def metadata_func(record: dict, metadata: dict) -> dict:  
    metadata["sender_name"] = record.get("sender_name")  
    metadata["timestamp_ms"] = record.get("timestamp_ms")  
  
    return metadata  
  
  
loader = JSONLoader(  
    file_path="./example_data/facebook_chat.json",  
    jq_schema=".messages[]",  
    content_key="content",  
    metadata_func=metadata_func,  
)  
  
docs = loader.load()  
print(docs[0].metadata)  

```

```
{'source': '/Users/isaachershenson/Documents/langchain/docs/docs/integrations/document_loaders/example_data/facebook_chat.json', 'seq_num': 1, 'sender_name': 'User 2', 'timestamp_ms': 1675597571851}  

```

## API reference[​](#api-reference "Direct link to API reference")

For detailed documentation of all JSONLoader features and configurations head to the API reference: <https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.json_loader.JSONLoader.html>

## Related[​](#related "Direct link to Related")

* Document loader [conceptual guide](/docs/concepts/document_loaders/)
* Document loader [how-to guides](/docs/how_to/#document-loaders)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/json.ipynb)