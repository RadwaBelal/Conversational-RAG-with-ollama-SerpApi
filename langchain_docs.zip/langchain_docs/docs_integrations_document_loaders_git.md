# Source: https://python.langchain.com/docs/integrations/document_loaders/git/

* [Components](/docs/integrations/components/)
* [Document loaders](/docs/integrations/document_loaders/)
* Git

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/git.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/document_loaders/git.ipynb)

# Git

> [Git](https://en.wikipedia.org/wiki/Git) is a distributed version control system that tracks changes in any set of computer files, usually used for coordinating work among programmers collaboratively developing source code during software development.

This notebook shows how to load text files from `Git` repository.

## Load existing repository from disk[​](#load-existing-repository-from-disk "Direct link to Load existing repository from disk")

```
%pip install --upgrade --quiet  GitPython  

```

```
from git import Repo  
  
repo = Repo.clone_from(  
    "https://github.com/langchain-ai/langchain", to_path="./example_data/test_repo1"  
)  
branch = repo.head.reference  

```

```
from langchain_community.document_loaders import GitLoader  

```

**API Reference:**[GitLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.git.GitLoader.html)

```
loader = GitLoader(repo_path="./example_data/test_repo1/", branch=branch)  

```

```
data = loader.load()  

```

```
len(data)  

```

```
print(data[0])  

```

```
page_content='.venv\n.github\n.git\n.mypy_cache\n.pytest_cache\nDockerfile' metadata={'file_path': '.dockerignore', 'file_name': '.dockerignore', 'file_type': ''}  

```

## Clone repository from url[​](#clone-repository-from-url "Direct link to Clone repository from url")

```
from langchain_community.document_loaders import GitLoader  

```

**API Reference:**[GitLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.git.GitLoader.html)

```
loader = GitLoader(  
    clone_url="https://github.com/langchain-ai/langchain",  
    repo_path="./example_data/test_repo2/",  
    branch="master",  
)  

```

```
data = loader.load()  

```

```
len(data)  

```

```
1074  

```

## Filtering files to load[​](#filtering-files-to-load "Direct link to Filtering files to load")

```
from langchain_community.document_loaders import GitLoader  
  
# e.g. loading only python files  
loader = GitLoader(  
    repo_path="./example_data/test_repo1/",  
    file_filter=lambda file_path: file_path.endswith(".py"),  
)  

```

**API Reference:**[GitLoader](https://python.langchain.com/api_reference/community/document_loaders/langchain_community.document_loaders.git.GitLoader.html)

## Related[​](#related "Direct link to Related")

* Document loader [conceptual guide](/docs/concepts/document_loaders/)
* Document loader [how-to guides](/docs/how_to/#document-loaders)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/document_loaders/git.ipynb)