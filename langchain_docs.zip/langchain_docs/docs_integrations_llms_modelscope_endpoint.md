# Source: https://python.langchain.com/docs/integrations/llms/modelscope_endpoint/

* [Components](/docs/integrations/components/)
* Other
* [LLMs](/docs/integrations/llms/)
* ModelScope

On this page

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/langchain-ai/langchain/blob/master/docs/docs/integrations/llms/modelscope_endpoint.ipynb)[![Open on GitHub](https://img.shields.io/badge/Open%20on%20GitHub-grey?logo=github&logoColor=white)](https://github.com/langchain-ai/langchain/blob/master/docs/docs/integrations/llms/modelscope_endpoint.ipynb)

# ModelScopeEndpoint

ModelScope ([Home](https://www.modelscope.cn/) | [GitHub](https://github.com/modelscope/modelscope)) is built upon the notion of “Model-as-a-Service” (MaaS). It seeks to bring together most advanced machine learning models from the AI community, and streamlines the process of leveraging AI models in real-world applications. The core ModelScope library open-sourced in this repository provides the interfaces and implementations that allow developers to perform model inference, training and evaluation. This will help you get started with ModelScope completion models (LLMs) using LangChain.

## Overview[​](#overview "Direct link to Overview")

### Integration details[​](#integration-details "Direct link to Integration details")

| Provider | Class | Package | Local | Serializable | Package downloads | Package latest |
| --- | --- | --- | --- | --- | --- | --- |
| [ModelScope](/docs/integrations/providers/modelscope/) | ModelScopeEndpoint | [langchain-modelscope-integration](https://pypi.org/project/langchain-modelscope-integration/) | ❌ | ❌ | PyPI - Downloads | PyPI - Version |

## Setup[​](#setup "Direct link to Setup")

To access ModelScope models you'll need to create a ModelScope account, get an SDK token, and install the `langchain-modelscope-integration` integration package.

### Credentials[​](#credentials "Direct link to Credentials")

Head to [ModelScope](https://modelscope.cn/) to sign up to ModelScope and generate an [SDK token](https://modelscope.cn/my/myaccesstoken). Once you've done this set the `MODELSCOPE_SDK_TOKEN` environment variable:

```
import getpass  
import os  
  
if not os.getenv("MODELSCOPE_SDK_TOKEN"):  
    os.environ["MODELSCOPE_SDK_TOKEN"] = getpass.getpass(  
        "Enter your ModelScope SDK token: "  
    )  

```

### Installation[​](#installation "Direct link to Installation")

The LangChain ModelScope integration lives in the `langchain-modelscope-integration` package:

```
%pip install -qU langchain-modelscope-integration  

```

## Instantiation[​](#instantiation "Direct link to Instantiation")

Now we can instantiate our model object and generate chat completions:

```
from langchain_modelscope import ModelScopeEndpoint  
  
llm = ModelScopeEndpoint(  
    model="Qwen/Qwen2.5-Coder-32B-Instruct",  
    temperature=0,  
    max_tokens=1024,  
    timeout=60,  
)  

```

## Invocation[​](#invocation "Direct link to Invocation")

```
input_text = "Write a quick sort algorithm in python"  
  
completion = llm.invoke(input_text)  
completion  

```

```
'Certainly! Quick sort is a popular and efficient sorting algorithm that uses a divide-and-conquer approach to sort elements. Below is a simple implementation of the Quick Sort algorithm in Python:\n\n\`\`\`python\ndef quick_sort(arr):\n    # Base case: if the array is empty or has one element, it\'s already sorted\n    if len(arr) <= 1:\n        return arr\n    else:\n        # Choose a pivot element from the array\n        pivot = arr[len(arr) // 2]\n        \n        # Partition the array into three parts:\n        # - elements less than the pivot\n        # - elements equal to the pivot\n        # - elements greater than the pivot\n        less_than_pivot = [x for x in arr if x < pivot]\n        equal_to_pivot = [x for x in arr if x == pivot]\n        greater_than_pivot = [x for x in arr if x > pivot]\n        \n        # Recursively apply quick_sort to the less_than_pivot and greater_than_pivot subarrays\n        return quick_sort(less_than_pivot) + equal_to_pivot + quick_sort(greater_than_pivot)\n\n# Example usage:\narr = [3, 6, 8, 10, 1, 2, 1]\nsorted_arr = quick_sort(arr)\nprint("Sorted array:", sorted_arr)\n\`\`\`\n\n### Explanation:\n1. **Base Case**: If the array has one or zero elements, it is already sorted, so we return it as is.\n2. **Pivot Selection**: We choose the middle element of the array as the pivot. This is a simple strategy, but there are other strategies for choosing a pivot.\n3. **Partitioning**: We partition the array into three lists:\n   - `less_than_pivot`: Elements less than the pivot.\n   - `equal_to_pivot`: Elements equal to the pivot.\n   - `greater_than_pivot`: Elements greater than the pivot.\n4. **Recursive Sorting**: We recursively sort the `less_than_pivot` and `greater_than_pivot` lists and concatenate them with the `equal_to_pivot` list to get the final sorted array.\n\nThis implementation is straightforward and easy to understand, but it may not be the most efficient in terms of space complexity due to the use of additional lists. For an in-place version of Quick Sort, you can modify the algorithm to sort the array within its own memory space.'  

```

```
for chunk in llm.stream("write a python program to sort an array"):  
    print(chunk, end="", flush=True)  

```

```
Certainly! Sorting an array is a common task in programming, and Python provides several ways to do it. Below is a simple example using Python's built-in sorting functions. We'll use the `sorted()` function and the `sort()` method of a list.  
  
### Using `sorted()` Function  
  
The `sorted()` function returns a new sorted list from the elements of any iterable.  
  
\`\`\`python  
def sort_array(arr):  
    return sorted(arr)  
  
# Example usage  
array = [5, 2, 9, 1, 5, 6]  
sorted_array = sort_array(array)  
print("Original array:", array)  
print("Sorted array:", sorted_array)  
\`\`\`  
  
### Using `sort()` Method  
  
The `sort()` method sorts the list in place and returns `None`.  
  
\`\`\`python  
def sort_array_in_place(arr):  
    arr.sort()  
  
# Example usage  
array = [5, 2, 9, 1, 5, 6]  
sort_array_in_place(array)  
print("Sorted array:", array)  
\`\`\`  
  
### Custom Sorting  
  
If you need to sort the array based on a custom key or in descending order, you can use the `key` and `reverse` parameters.  
  
\`\`\`python  
def custom_sort_array(arr):  
    # Sort in descending order  
    return sorted(arr, reverse=True)  
  
# Example usage  
array = [5, 2, 9, 1, 5, 6]  
sorted_array_desc = custom_sort_array(array)  
print("Sorted array in descending order:", sorted_array_desc)  
\`\`\`  
  
### Sorting with a Custom Key  
  
Suppose you have a list of tuples and you want to sort them based on the second element of each tuple:  
  
\`\`\`python  
def sort_tuples_by_second_element(arr):  
    return sorted(arr, key=lambda x: x[1])  
  
# Example usage  
tuples = [(1, 3), (4, 1), (5, 2), (2, 4)]  
sorted_tuples = sort_tuples_by_second_element(tuples)  
print("Sorted tuples by second element:", sorted_tuples)  
\`\`\`  
  
These examples demonstrate how to sort arrays in Python using different methods and options. Choose the one that best fits your needs!  

```

## Chaining[​](#chaining "Direct link to Chaining")

We can [chain](/docs/how_to/sequence/) our completion model with a prompt template like so:

```
from langchain_core.prompts import PromptTemplate  
  
prompt = PromptTemplate(template="How to say {input} in {output_language}:\n")  
  
chain = prompt | llm  
chain.invoke(  
    {  
        "output_language": "Chinese",  
        "input": "I love programming.",  
    }  
)  

```

**API Reference:**[PromptTemplate](https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.prompt.PromptTemplate.html)

```
'In Chinese, you can say "我喜欢编程" (Wǒ xǐ huān biān chéng) to express "I love programming." Here\'s a breakdown of the sentence:\n\n- 我 (Wǒ) means "I"\n- 喜欢 (xǐ huān) means "love" or "like"\n- 编程 (biān chéng) means "programming"\n\nSo, when you put it all together, it translates to "I love programming."'  

```

## API reference[​](#api-reference "Direct link to API reference")

Refer to <https://modelscope.cn/docs/model-service/API-Inference/intro> for more details.

## Related[​](#related "Direct link to Related")

* LLM [conceptual guide](/docs/concepts/text_llms/)
* LLM [how-to guides](/docs/how_to/#llms)

[Edit this page](https://github.com/langchain-ai/langchain/edit/master/docs/docs/integrations/llms/modelscope_endpoint.ipynb)